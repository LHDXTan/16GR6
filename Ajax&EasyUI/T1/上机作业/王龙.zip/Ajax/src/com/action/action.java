package com.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

public class action {

public String jiaoyan() throws IOException{
	//对jsp界面传来的参数 进行判断
	HttpServletRequest request=ServletActionContext.getRequest();
	HttpServletResponse response =ServletActionContext.getResponse();
	PrintWriter out = response.getWriter();
	String username = request.getParameter("username");
	if(username.equals("001")){
		out.print("1");
		System.out.println("输入正确");
	}else{
		out.print("2");
		System.out.println("输入错误");
	}
	 
	return null;	 
 }
public String liandong() throws IOException{
	System.out.println("000000000000000000001");
	HttpServletRequest request=ServletActionContext.getRequest();
	HttpServletResponse response =ServletActionContext.getResponse();
	PrintWriter out = response.getWriter();
	//获取当前切换的省份
	String proNo = request.getParameter("proNo");
	List list = this.getAllCity(proNo);
	/************补充代码***********/
	StringBuffer sb = new StringBuffer();
	sb.append(" \n");
	sb.append("[ \n");
	sb.append(" {\"pid\":\"1\",\"pcity\":[\"东城区\",\"西城区\",\"朝阳区\",\"海淀区\",\"昌平区\"]} \n");
	sb.append(",{\"pid\":\"2\",\"pcity\":[\"襄阳市\",\"十堰市\",\"枣阳市\",\"武汉市\"]} \n");
	sb.append(",{\"pid\":\"3\",\"pcity\":[\"石家庄\",\"保定市\",\"邯郸市\",\"邢台市\"]} \n");
	sb.append("] \n");
	out.println(sb.toString());
   return null; 
}


public boolean checkuser(String uname) {
	// TODO Auto-generated method stub
	return false;
}

public List getAllCity(String proNo) {
	// TODO Auto-generated method stub
	return null;
}
}