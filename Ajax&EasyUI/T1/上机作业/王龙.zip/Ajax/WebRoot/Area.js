function Area(selector){  
    if (!Area.ALL_AREAS) {  
        throw new Error('areas not init！');  
    }  
      
    this.selector = selector;  
    $(this.selector).html('');  
      
    var $province = this._getElement(Area.code.PROVINCE);  
    var $city = this._getElement(Area.code.CITY);  
    var $county = this._getElement(Area.code.COUNTY);  
      
    var self = this;  
    $province.change(function(){  
        var province = this.value;  
        $city.html(self._getOptions([province]));  
        var city = $city.val();  
        $county.html(self._getOptions([province, city]));  
    });  
    $city.change(function(){  
        var province = $province.val();  
        var city = this.value;  
        $county.html(self._getOptions([province, city]));  
    });  
    $province.html(self._getOptions());  
    this.select();  
}  
  
$.extend(Area, {  
    ALL_AREAS: null,  
    code: {  
        PROVINCE: 0,  
        CITY: 1,  
        COUNTY: 2  
    },  
    init: function(url){  
        if (Area.ALL_AREAS)   
            return;  
        Area.ALL_AREAS = $.parseJSON($.ajax({  
            url: url,  
            async: false  
        }).responseText);  
    }  
});  
  
Area.prototype = {  
  
    _getElement: function(code){  
        return $(this.selector).find('select').eq(code);  
    },  
      
    select: function(address){  
        var address = address || [];  
          
        var $province = this._getElement(Area.code.PROVINCE);  
        var $city = this._getElement(Area.code.CITY);  
        var $county = this._getElement(Area.code.COUNTY);  
          
        var province = address.length < 1 ? '' : address[0];  
        $province.val(province);  
        $city.html(this._getOptions([province]));  
          
        var city = address.length < 2 ? '' : address[1];  
        $city.val(city);  
        $county.html(this._getOptions([province, city]));  
          
        var county = address.length < 3 ? '' : address[2];  
        $county.val(county);  
    },  
      
    getAddress: function(){  
        var $province = this._getElement(Area.code.PROVINCE);  
        var $city = this._getElement(Area.code.CITY);  
        var $county = this._getElement(Area.code.COUNTY);  
        return [$province.val(), $city.val(), $county.val()];  
    },  
      
    _getAreaName: function(area){  
        if (typeof(area) == 'string')   
            return area;  
        for (var o in area) {  
            return o;  
        }  
    },  
      
    _getAreas: function(areaName, superAreas){  
        for (var i = 0; i < superAreas.length; i++) {  
            if (this._getAreaName(superAreas[i]) == areaName)   
                return superAreas[i][areaName] || [];  
        }  
        return [];  
    },  
      
    _getAreasByAddress: function(address){  
        var areas = Area.ALL_AREAS;  
        for (var i = 0; i < address.length; i++) {  
            areas = this._getAreas(address[i], areas);  
        }  
        return areas;  
    },  
      
    _getAreaNames: function(address){  
        var areas = this._getAreasByAddress(address);  
        var areaNames = [];  
        for (var i = 0; i < areas.length; i++) {  
            areaNames.push(this._getAreaName(areas[i]));  
        }  
        return areaNames;  
    },  
      
    _getOption: function(optionName){  
        return '' + optionName + '';  
    },  
      
    _getOptions: function(address){  
        var address = address || [];  
        var areaNames = this._getAreaNames(address);  
        var options = '请选择';  
        for (var i = 0; i < areaNames.length; i++) {  
            options += this._getOption(areaNames[i]);  
        }  
        return options;  
    }  
};  