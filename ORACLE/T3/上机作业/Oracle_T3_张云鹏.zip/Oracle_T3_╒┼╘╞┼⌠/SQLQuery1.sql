--1�����������ڰ༶�İ༶����
select classid from class where classid= (select classid from student where studentname='����')
--2
select classid,COUNT(classid) cnt from student group by classid order by classid , cnt desc
--3
select studentname from student where studentid in (select studentid from result where testdata='2013-08-23' and subject='����')
--4
select a.studentname,b.subject  from  (select studentid,studentname from student where classid = (select classid from class where classname='һ��' ))a, (select *  from  result )b where a.studentid=b.studentid and b.achievement<60
--5
select c.classname,d.cnt from (select * from  class) c ,(select a.classid ,AVG(b.achievement) cnt from  (select * from student) a,(select  * from result  where subject='��ѧ'and testdata='2013-08-23' ) b where a.studentid=b.studentid group by a.classid) d where c.classid=d.classid and cnt>60
--6
   select b.classname,a.studentname from 
   (select * from class) b ,
  (select * from student s where studentid not in
   (select studentid from   result r 
   where achievement<60 or achievement=0)  ) a where a.classid=b.classid 
   
   