select c.classname from student s,class c where s.Classid=c.Classid and s.Studentname='����'

select c.Classid,c.classname,COUNT(s.Studentname) from class c,student s where c.Classid=s.Classid group by c.classname,c.Classid order by c.Classid ASC

select distinct s.Studentname from student s,result r,class c where s.Studentid=r.Studentid and r.Testdata='2013-08-23' and r.Subject='����' 
 
select distinct s.Studentname,r.Subject from student s,class c,result r where s.Classid=c.Classid and s.Studentid=r.Studentid and  r.Achievement<60 and c.classname='G1'

select c.classname,AVG(r.Achievement) as avg from student s,class c,result r where s.Classid=c.Classid and s.Studentid=r.Studentid 
and r.Subject='��ѧ' and r.Testdata='2013-08-23' group by c.classname having AVG(r.Achievement)>60

select distinct s.Studentname,c.classname from student s,class c,result r where
 s.Classid=c.Classid and s.Studentid=r.Studentid and s.Studentid not in ( select distinct  Studentid from result where Achievement<60)
 




