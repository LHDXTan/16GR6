create user shenzhen identified by beijing;
grant connect,resource,dba to shenzhen;
