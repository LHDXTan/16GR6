package com.jdba;

import java.sql.Connection;
import java.sql.DriverManager;




	public class jdbc {

	
		static String url ="jdbc:oracle:thin:@127.0.0.1:1521:ORCL";
		static String userName ="sys as sysdba";
		static String pwd ="123456";
	
	
		
		
		public static Connection getConnection() {
			Connection con = null;
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
			    con = DriverManager.getConnection(url, userName, pwd);
			    System.out.println(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
	
			
			return con;
		   
		
		
			
		}

public static void main(String[] args) {
	jdbc j=new jdbc();
	System.out.println(j.getConnection());
}

}
