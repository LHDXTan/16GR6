package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBManager {
    
	//链接
	public Connection getConnection() {
		String url="jdbc:oracle:thin:@localhost:1521:orcl";
		String user="sys as sysdba";
		String password="123456";
		Connection con=null;
		try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con=DriverManager.getConnection(url,user,password);
				  
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	return con;
	}
	//输出测试
	public static void main(String[] args) {
		DBManager dd=new DBManager();
		System.out.println("DBManager.main()"+dd.getConnection());
	}
}
