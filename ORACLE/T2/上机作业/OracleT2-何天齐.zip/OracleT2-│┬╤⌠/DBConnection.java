package com.oracle;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static String url  = "jdbc:oracle:thin:@localhost:1521:orcl";
    private static String user="scott";
    private static String password="tiger";
    static {
		try {
			String driver = null;
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
    }
    public static Connection getConnection(Connection con) {
        try {
	 con = DriverManager.getConnection(url, user, password); 
        } catch (SQLException e) {
            e.printStackTrace();
     }
		return con;   
}

}
