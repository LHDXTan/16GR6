public class Test {
	public static void main(String[] args) {
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@localhost:1521:orcl";
			String nam="sys as sysdba";
			String pwd="sys";
			Connection con=DriverManager.getConnection(url,nam,pwd);
			Statement st=con.createStatement();
			String sql="select * from dept";
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				System.out.print(rs.getInt("did")+"\t");
				System.out.print(rs.getString("dname")+"\t");
				System.out.print(rs.getString("tel")+"\t");
				System.out.println(rs.getString("ress"));
			}
			con.close();
		}catch(Exception e){e.printStackTrace();}
	}
}
