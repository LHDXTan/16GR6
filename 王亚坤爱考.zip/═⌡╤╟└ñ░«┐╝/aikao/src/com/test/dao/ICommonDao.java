package com.test.dao;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;

import com.test.bean.Exam;
import com.test.vo.OnlineExamPaper;
import com.test.vo.PageBean;

public interface ICommonDao {

	public List getObjectList(DetachedCriteria dc);		
	
	public PageBean getPageInfo(int p,String hql);	
	
	public void addObject(Object obj);						
	
	public Object getobObjectById(Class class1,int id);
	
	public PageBean queryPageInfo(int p,DetachedCriteria dc,int pagesize); 	
	
	public void updateObject(Object obj);			

	public void deleteObject(Object obj);				

	public List getObjectByHql(String hql);
	
	public OnlineExamPaper getOnlineExamPaper(Exam exam);		
	

}
