package com.test.dao;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;

import com.test.bean.Exam;
import com.test.bean.Student;
import com.test.vo.ExamScoreInfo;
import com.test.vo.PageBean;


public interface IExamDao {

	public PageBean getGradeNames(PageBean pagebean);
	
	public List examshitiList(Exam exam);
	
	public List getmyScoreInfo(int scid);
	
	public ExamScoreInfo getExamScore(int examid,Student student);
	
	
	
}
