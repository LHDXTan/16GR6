package com.test.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;


import com.test.bean.Exam;
import com.test.bean.Fangxiang;
import com.test.bean.Grade;
import com.test.bean.Jieduan;
import com.test.bean.Professional;
import com.test.bean.Teacher;
import com.test.gongju.HibernateSessionFactory;
import com.test.vo.OnlineExamPaper;
import com.test.vo.PageBean;

public class CommonDaoImpl implements ICommonDao {

	@Override
	public List getObjectList(DetachedCriteria dc) {
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tr = session.beginTransaction();
		
		Criteria cri = dc.getExecutableCriteria(session);
		List list = cri.list();
		
		tr.commit();
		HibernateSessionFactory.closeSession();
		return list;
	}

	public PageBean getPageInfo(int p,String hql){
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tr = session.beginTransaction();
		
		PageBean pageBean = new PageBean();
		pageBean.setPageSize(4);
		Query query = session.createQuery(hql);
		pageBean.setCount(query.list().size());
		if(p!=0){
			pageBean.setP(p);
		}
		query.setFirstResult((pageBean.getP()-1)*pageBean.getPageSize()).setMaxResults(pageBean.getPageSize());
		pageBean.setData(query.list());
		
		tr.commit();
		HibernateSessionFactory.closeSession();
		return pageBean;
	}

	public PageBean queryPageInfo(int p,DetachedCriteria dc,int pagesize){
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tr = session.beginTransaction();
		
		PageBean pageBean = new PageBean();
		if(pagesize==0){
			pageBean.setPageSize(4);
		}else{
			pageBean.setPageSize(pagesize);		
		}
		pageBean.setCount(dc.getExecutableCriteria(session).list().size());
		pageBean.setP(p);
		
		Criteria criteria = dc.getExecutableCriteria(session);
		if(pageBean.getCount()==0){
			criteria.setFirstResult(0);
		}else{
			criteria.setFirstResult((pageBean.getP()-1)*pageBean.getPageSize()).setMaxResults(pageBean.getPageSize());
		}
		pageBean.setData(criteria.list());
		
		tr.commit();
		HibernateSessionFactory.closeSession();
		return pageBean;
	}
	
	@Override
	public void addObject(Object obj) {
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tr = session.beginTransaction();
		
		session.save(obj);
		
		tr.commit();
		HibernateSessionFactory.closeSession();
	}

	@Override
	public Object getobObjectById(Class class1, int id) {
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tr = session.beginTransaction();
		
		Object obj = session.get(class1, id);
		
		tr.commit();
		HibernateSessionFactory.closeSession();
		return obj;
	}

	@Override
	public void updateObject(Object obj) {
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tr = session.beginTransaction();
		
		session.update(obj);
		
		tr.commit();
		HibernateSessionFactory.closeSession();
	}
	
	@Override
	public void deleteObject(Object obj) {
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tr = session.beginTransaction();
		
		session.delete(obj);
		
		tr.commit();
		HibernateSessionFactory.closeSession();
	}

	@Override
	public List getObjectByHql(String hql) {

		Session session = HibernateSessionFactory.getSession();
		Transaction tr = session.beginTransaction();
		
		List obj = session.createQuery(hql).list();
		
		tr.commit();
		HibernateSessionFactory.closeSession();
		return obj;
	}
	@Override
	public OnlineExamPaper getOnlineExamPaper(Exam exam) {
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tr = session.beginTransaction();
		
		OnlineExamPaper exampaper = new OnlineExamPaper();
		if(exam!=null){
			exampaper.setExamid(exam.getExamid());
			if(exam.getEtype()==1){
				exampaper.setQbs("单选 ");	
			}else{
				exampaper.setQbs("多选");	
			}
			String kemu = "[";
			Fangxiang fangxiang = (Fangxiang) session.get(Fangxiang.class, exam.getFid());
			Jieduan jieduan = (Jieduan) session.get(Jieduan.class, exam.getJid());
			Professional professional = (Professional) session.get(Professional.class, exam.getFid());
			kemu += fangxiang.getFname()+" "+jieduan.getJname()+"] "+professional.getPname();
			exampaper.setKemu(kemu);
			exampaper.setTitle(exam.getEtitle());
			
			String gnames = "";
			String[] gids = exam.getGid().split(",");
			for(int i=0;i<gids.length;i++){
				Grade grade = (Grade) session.get(Grade.class, Integer.parseInt(gids[i]));
				if(gnames.equals("")){
					gnames += grade.getGname();
				}else{
					gnames += ","+grade.getGname();
				}
			}
			exampaper.setGnames(gnames);
			exampaper.setBegintime(exam.getEstartime());
			exampaper.setExamtime(exam.getEtime());
		}
		
		tr.commit();
		HibernateSessionFactory.closeSession();
		return exampaper;
	}
	
	
	
	

}
