package com.test.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.test.bean.Exam;
import com.test.bean.Fangxiang;
import com.test.bean.Grade;
import com.test.bean.Jieduan;
import com.test.bean.Professional;
import com.test.bean.Question;
import com.test.bean.Score;
import com.test.bean.Student;
import com.test.gongju.HibernateSessionFactory;
import com.test.service.CommonServiceImpl;
import com.test.service.ICommonService;
import com.test.vo.ExamScoreInfo;
import com.test.vo.ExamVo;
import com.test.vo.PageBean;
import com.test.vo.QuesAndAnwser;
import com.test.vo.StudentScoreInfo;


public class ExamDaoImpl implements IExamDao {

	ICommonService commonservice = new CommonServiceImpl();

	public PageBean getGradeNames(PageBean pagebean) {
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tr = session.beginTransaction();
		
		List examVoList = new ArrayList();
		
		for(Object o:pagebean.getData()){	
			Exam e = (Exam) o ;
			ExamVo examvo = new ExamVo();
			examvo.setExam(e);
			String voNames = "";	
			if(e.getGid()!=null&&!e.getGid().equals("")){
				String[] gname = e.getGid().split(",");		
				for(int i=0;i<gname.length;i++){
					if(!gname[i].equals("")){
						int gid = Integer.parseInt(gname[i]);
						String hql = "select g.gname from Grade g ";	
						List list = session.createQuery(hql).list();
						String name = (String) list.get(0);
						if(!name.equals("")&&i==gname.length-1){
							voNames += name ;
						}else{
							voNames += name+",";
						}
					}
				}
			}
			examvo.setGradeNames(voNames);
			String kemu = "";	
			if(e.getFid()!=0){
				Fangxiang fangxiang = (Fangxiang) session.get(Fangxiang.class, e.getFid());
				kemu += "["+fangxiang.getFname();
			}
			if(e.getJid()!=0){
				Jieduan jieduan = (Jieduan) session.get(Jieduan.class, e.getJid());
				kemu += " "+jieduan.getJname()+"]";
			}
			if(e.getPid()!=0){
				Professional professional = (Professional) session.get(Professional.class, e.getPid());
				kemu += professional.getPname();
			}
			examvo.setKemu(kemu);
			examVoList.add(examvo);
		}
		pagebean.setData(examVoList);
		tr.commit();
		HibernateSessionFactory.closeSession();
		return pagebean;
	}

	public List examshitiList(Exam exam) {
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tr = session.beginTransaction();
		
		List<Question> questionlist = new ArrayList<Question>();
		if(exam!=null&&exam.getShiti()!=null&&!exam.getShiti().equals("")){
			String[] idlist = exam.getShiti().split(",");
			for(int i=0;i<idlist.length;i++){
				Question question = (Question) session.get(Question.class,Integer.parseInt(idlist[i]));
				if(question!=null&&question.getQid()!=0){	
					questionlist.add(question);
				}
			}
		}
		tr.commit();
		HibernateSessionFactory.closeSession();
		return questionlist;
	}

	public static void main(String[] args){
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tr = session.beginTransaction();
		
		String hql = "select g.gname from Grade g ";
		List list = session.createQuery(hql).list();
		String gname = (String) list.get(0);
		tr.commit();
		HibernateSessionFactory.closeSession();
	}

	public List getmyScoreInfo(int scid) {
		
		List quesAnwserList = new ArrayList();
		Session session = HibernateSessionFactory.getSession();
		Transaction tr = session.beginTransaction();
		
		Score score = (Score) session.get(Score.class, scid);
		Exam exam = (Exam)session.get(Exam.class, score.getExamid());
		ServletActionContext.getRequest().getSession().setAttribute("score", score);
		ServletActionContext.getRequest().getSession().setAttribute("exam", exam);
		
		String[] anwsers = score.getAnwser().split(",");		
		String[] questions = exam.getShiti().split(",");		
		for(int i = 0;i<questions.length;i++){
			Question ques = (Question) session.get(Question.class, Integer.parseInt(questions[i]));
			QuesAndAnwser quesVo = new QuesAndAnwser();
			if(score.getAnwser().equals("")){
				quesVo.setQues(ques);
				quesVo.setIstrue(0);
				quesVo.setStudentAnwser("未作答");
				quesVo.setAnwserLength("选"+ques.getAnswer().length()+"项");
				quesVo.setAnwser(ques.getAnswer());
				quesAnwserList.add(quesVo);
				continue ;	
			}
			quesVo.setQues(ques);
			int count = 0 ;
			for(int j =0;j<anwsers.length;j++){
				String[] per = anwsers[j].split("_");
				if(Integer.parseInt(per[0])-1==i){		
					if(per[1].equals(ques.getAnswer())){
						quesVo.setIstrue(1);			
					}else{
						quesVo.setIstrue(0);
					}
					quesVo.setStudentAnwser(per[1]);
				}
				quesVo.setAnwserLength("选"+ques.getAnswer().length()+"项");
				quesVo.setAnwser(ques.getAnswer());
			}
			quesAnwserList.add(quesVo);
		}
		tr.commit();
		HibernateSessionFactory.closeSession();
		return quesAnwserList;
	}

	public ExamScoreInfo getExamScore(int examid,Student student) {
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tr = session.beginTransaction();
		ExamScoreInfo examscoreinfo = new ExamScoreInfo();
		Criteria dc = session.createCriteria(Score.class);
		dc.add(Restrictions.eq("examid", examid));
		List ExamScoreVolist = new ArrayList<StudentScoreInfo>();
		Exam exam = (Exam) session.get(Exam.class, examid);
		float passScore = (float) (exam.getTotalscore()*0.6);
		int passCount = 0;
		for(Object o:dc.list()){
			Score score = (Score) o;
			StudentScoreInfo es = new StudentScoreInfo();
			es.setScore(score);
			Student stu = (Student) session.get(Student.class, score.getSid());
			es.setGrade(stu.getGrade().getGname());
			int flag = 0;		
			if(student!=null){
				if(student.getGid()!=0){
					if(stu.getGid() != student.getGid()){
						flag = 1;
					}
				}
				if(stu.getSname()!=null && !stu.getSname().equals("")){
					if(!stu.getSname().equals(student.getSname())){
						flag = 1;
					}
				}
				if(flag==0){
					ExamScoreVolist.add(es);
				}
			}else{
				ExamScoreVolist.add(es);
			}
			if(score.getTatalScore()>=passScore){
				passCount ++;
			}
		}
		examscoreinfo.setExamid(examid);
		examscoreinfo.setKemu(exam.getEtitle());
		examscoreinfo.setStudentScorelist(ExamScoreVolist);
		examscoreinfo.setTotal(dc.list().size());		
		examscoreinfo.setPassNumber(passCount);			
		float passRate = 0;
		if(passCount>0  && dc.list().size()>0){
			passRate = passCount/dc.list().size();
		}
		examscoreinfo.setPassRate(passRate);
		
		tr.commit();
		HibernateSessionFactory.closeSession();
		return examscoreinfo;
	}



	
	
	
}
