package com.test.action;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;


import com.opensymphony.xwork2.ActionSupport;
import com.test.bean.Roles;
import com.test.bean.Teacher;
import com.test.service.CommonServiceImpl;
import com.test.service.ICommonService;
import com.test.vo.PageBean;

public class TeacherAction extends ActionSupport {

	ICommonService commonservice = new CommonServiceImpl();
	private List teacherList ;
	private PageBean pagebean ;
	private int p ;	
	private Teacher teacher ;
	private String cmd ;

	public String teacherIndex(){
		
		String hql = "from Teacher";
		if(p==0){
			p=1;
		}
		pagebean = commonservice.getPageInfo(p, hql);
		return "index" ;
	}

	public String addTeacher(){
		
		Roles roles = (Roles) commonservice.getobObjectById(Roles.class, 2);
		teacher.setRole(roles);
		commonservice.addObject(teacher);
		cmd = "close" ;
		teacher = null;
		return "input";
	}

	public String queryTeacherByLike(){
		
		DetachedCriteria detachedCriteria = DetachedCriteria.forClass(Teacher.class);
		if(teacher!=null){
			if(teacher.getTname()!=null&&!teacher.getTname().equals("")){
				detachedCriteria.add(Restrictions.like("tname", teacher.getTname(),MatchMode.ANYWHERE));
			}
			if(teacher.getTno()!=null&&!teacher.getTno().equals("")){
				detachedCriteria.add(Restrictions.like("tno", teacher.getTno(),MatchMode.ANYWHERE));
			}
			if(teacher.getTjob()!=null&&!teacher.getTjob().equals("")){
				detachedCriteria.add(Restrictions.like("tjob", teacher.getTjob(),MatchMode.ANYWHERE));
			}
			pagebean = commonservice.queryPageInfo(p,detachedCriteria,4);
		}
		return "index";
	}
	
	public String toUpdate(){
		
		if(teacher!=null&&teacher.getTid()!=0){
			teacher = (Teacher) commonservice.getobObjectById(Teacher.class, teacher.getTid());
			return "updatepage";
		}
		return teacherIndex();
		
	}

	public String update(){
		
		cmd = "close";
		if(teacher!=null&&teacher.getTid()!=0){
			commonservice.updateObject(teacher);
			pagebean = commonservice.getPageInfo(1,"from Teacher");	
		
			teacher = null;
			return "updatepage";
		}
		return "updatepage";
	}

	public String resetPassword(){
		
		if(teacher!=null&&teacher.getTid()!=0){
			teacher = (Teacher) commonservice.getobObjectById(Teacher.class, teacher.getTid());
			teacher.setTpwd("123456");
			commonservice.updateObject(teacher);
		}
		return teacherIndex();
	}

	public String deleteTeacher(){
		
		if(teacher!=null&&teacher.getTid()!=0){
			teacher = (Teacher) commonservice.getobObjectById(Teacher.class, teacher.getTid());
			commonservice.deleteObject(teacher);
			teacher = null;
		}
		return teacherIndex();
	}
	
	public List getTeacherList() {
		return teacherList;
	}

	public void setTeacherList(List teacherList) {
		this.teacherList = teacherList;
	}


	public PageBean getPagebean() {
		return pagebean;
	}


	public void setPagebean(PageBean pagebean) {
		this.pagebean = pagebean;
	}

	public int getP() {
		return p;
	}

	public void setP(int p) {
		this.p = p;
	}

	public Teacher getTeacher() {
		return teacher;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}

	public String getCmd() {
		return cmd;
	}

	public void setCmd(String cmd) {
		this.cmd = cmd;
	}
	
	
	
	
}
