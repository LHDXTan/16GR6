package com.test.action;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;


import com.opensymphony.xwork2.ActionSupport;
import com.test.bean.Fangxiang;
import com.test.bean.Grade;
import com.test.bean.Teacher;
import com.test.service.CommonServiceImpl;
import com.test.service.ICommonService;
import com.test.vo.PageBean;

public class GradeAction extends ActionSupport {
	ICommonService commonservice = new CommonServiceImpl();
	private PageBean gradepagebean ;
	private Grade grade ;
	private List fangxiangList ;
	private List advisorList ;		
	private List teacherList ;		
	private List dateList ;	
	private String queryYear ;
	private int p ;
	private String cmd ;

	public String gradeList(){
		
		getListinfo();
		DetachedCriteria dc  = DetachedCriteria.forClass(Grade.class);
		if(queryYear!=null&&!queryYear.equals("")&&!queryYear.equals("0")){
			dc.add(Restrictions.like("gtime", queryYear, MatchMode.ANYWHERE));
		}
		if(grade!=null){
			if(grade.getFid()!=0){
				dc.add(Restrictions.eq("fid", grade.getFid()));
			}
			if(grade.getGbid()!=0){
				dc.add(Restrictions.eq("gbid", grade.getGbid()));
			}
			if(grade.getGjid()!=0){
				dc.add(Restrictions.eq("gjid", grade.getGjid()));
			}
		}
		gradepagebean = commonservice.queryPageInfo(p, dc,4);
		return "gradeindex";
	}

	public void getListinfo(){
		
		Date date = new Date();
		int year = 1900 +date.getYear();
		dateList = new ArrayList();
		for(int i=0;i<=10;i++){
			dateList.add(year);
			year--;
		}
		DetachedCriteria dc1 = DetachedCriteria.forClass(Fangxiang.class);
		fangxiangList = commonservice.getObjectList(dc1);
		DetachedCriteria dc2 = DetachedCriteria.forClass(Teacher.class).add(Restrictions.eq("tjob", "��ʦ"));
		advisorList = commonservice.getObjectList(dc2);
		DetachedCriteria dc3 = DetachedCriteria.forClass(Teacher.class).add(Restrictions.eq("tjob", "��ʦ"));
		teacherList = commonservice.getObjectList(dc3);
	}

	public String addNeedPrepare(){
		
		DetachedCriteria dc1 = DetachedCriteria.forClass(Fangxiang.class);
		fangxiangList = commonservice.getObjectList(dc1);
		DetachedCriteria dc2 = DetachedCriteria.forClass(Teacher.class).add(Restrictions.eq("tjob", "��ʦ"));
		advisorList = commonservice.getObjectList(dc2);
		DetachedCriteria dc3 = DetachedCriteria.forClass(Teacher.class).add(Restrictions.eq("tjob", "��ʦ"));
		teacherList = commonservice.getObjectList(dc3);
		
		return "add";
	}
	
	public String addGrade(){
		
		getListinfo();
		cmd = "close";
		if(grade!=null){
			Teacher t1 = (Teacher) commonservice.getobObjectById(Teacher.class, grade.getGbid());
			Teacher t2 = (Teacher) commonservice.getobObjectById(Teacher.class, grade.getGjid());
			Fangxiang fx = (Fangxiang) commonservice.getobObjectById(Fangxiang.class, grade.getFid());
			grade.setDaoshi(t1);
			grade.setJiangshi(t2);
			grade.setFangxiang(fx);
			commonservice.addObject(grade);
			gradepagebean = commonservice.getPageInfo(1,"from Grade");
		}
		return "add";
	}

	public String toUpdate(){
		
		if(grade!=null&&grade.getGid()!=0){
			grade = (Grade) commonservice.getobObjectById(Grade.class, grade.getGid());
			DetachedCriteria dc1 = DetachedCriteria.forClass(Fangxiang.class);
			fangxiangList = commonservice.getObjectList(dc1);
			DetachedCriteria dc2 = DetachedCriteria.forClass(Teacher.class).add(Restrictions.eq("tjob", "��ʦ"));
			advisorList = commonservice.getObjectList(dc2);
			DetachedCriteria dc3 = DetachedCriteria.forClass(Teacher.class).add(Restrictions.eq("tjob", "��ʦ"));
			teacherList = commonservice.getObjectList(dc3);
		}
		return "updatePage";
	}

	public String update(){
		
		getListinfo();
		cmd = "close";
		if(grade!=null){
			Teacher t1 = (Teacher) commonservice.getobObjectById(Teacher.class, grade.getGbid());
			Teacher t2 = (Teacher) commonservice.getobObjectById(Teacher.class, grade.getGjid());
			Fangxiang fx = (Fangxiang) commonservice.getobObjectById(Fangxiang.class, grade.getFid());
			grade.setDaoshi(t1);
			grade.setJiangshi(t2);
			grade.setFangxiang(fx);
			commonservice.updateObject(grade);
			gradepagebean = commonservice.getPageInfo(1,"from Grade");
		}
		return "updatePage";
	}

	public String changeStatus(){
		
		if(grade!=null&&grade.getGid()!=0){
			grade = (Grade) commonservice.getobObjectById(Grade.class, grade.getGid());
			if(grade.getGstate()==0){
				grade.setGstate(1);
			}else{
				grade.setGstate(0);
			}
			commonservice.updateObject(grade);
			grade = new Grade();		
			DetachedCriteria dc  = DetachedCriteria.forClass(Grade.class);
			gradepagebean = commonservice.queryPageInfo(p, dc,4);
			getListinfo();
		}
		return "gradeindex";
	}
	
	public PageBean getGradepagebean() {
		return gradepagebean;
	}

	public void setGradepagebean(PageBean gradepagebean) {
		this.gradepagebean = gradepagebean;
	}

	public List getFangxiangList() {
		return fangxiangList;
	}

	public void setFangxiangList(List fangxiangList) {
		this.fangxiangList = fangxiangList;
	}

	public List getAdvisorList() {
		return advisorList;
	}

	public void setAdvisorList(List advisorList) {
		this.advisorList = advisorList;
	}

	public List getTeacherList() {
		return teacherList;
	}

	public void setTeacherList(List teacherList) {
		this.teacherList = teacherList;
	}

	public Grade getGrade() {
		return grade;
	}

	public void setGrade(Grade grade) {
		this.grade = grade;
	}

	public List getDateList() {
		return dateList;
	}

	public void setDateList(List dateList) {
		this.dateList = dateList;
	}


	public int getP() {
		return p;
	}


	public void setP(int p) {
		this.p = p;
	}

	public String getQueryYear() {
		return queryYear;
	}

	public void setQueryYear(String queryYear) {
		this.queryYear = queryYear;
	}

	public String getCmd() {
		return cmd;
	}

	public void setCmd(String cmd) {
		this.cmd = cmd;
	}


	
	
}
