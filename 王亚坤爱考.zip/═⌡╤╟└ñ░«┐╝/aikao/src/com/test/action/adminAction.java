package com.test.action;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.test.bean.Manager;
import com.test.bean.Student;
import com.test.service.CommonServiceImpl;
import com.test.service.ICommonService;

public class adminAction extends ActionSupport {
	ICommonService commonservice = new CommonServiceImpl();
	private String cmd ;
	private String[] password ;	
	private Manager manager ;
	
	public String updateAdminPwd(){
		
		if(password!=null){
			if(password.length<2){
				super.addActionError("请将信息补充完整");
				return "updatepwd";
			}else{
				if(password[0]==null||password[0].equals("")&&password[1]==null||password[1].equals("")&&password[2]==null||password[2].equals("")){
					super.addActionError("信息不能为空");
					return "updatepwd";
				}else{
					manager = (Manager) ServletActionContext.getRequest().getSession().getAttribute("loginUser");
					if(password[0].equals(manager.getMpwd())&&password[1].equals(password[2])){
						manager.setMpwd(password[1]);
						commonservice.updateObject(manager);
						cmd = "updateOk";
						return "updatepwd";
					}else{
						super.addActionError("密码错误");
						return "updatepwd";
					}
				}
			}
		}
		super.addActionError("无数据");
		return "updatepwd";
		
	}


	public String getCmd() {
		return cmd;
	}
	public void setCmd(String cmd) {
		this.cmd = cmd;
	}
	public String[] getPassword() {
		return password;
	}
	public void setPassword(String[] password) {
		this.password = password;
	}


	public Manager getManager() {
		return manager;
	}


	public void setManager(Manager manager) {
		this.manager = manager;
	}
	
	
}
