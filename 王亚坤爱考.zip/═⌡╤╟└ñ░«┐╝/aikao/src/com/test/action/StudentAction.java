package com.test.action;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.apache.xmlbeans.impl.xb.xsdschema.RestrictionDocument.Restriction;
import org.hibernate.FetchMode;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;


import com.opensymphony.xwork2.ActionSupport;
import com.test.bean.Exam;
import com.test.bean.Fangxiang;
import com.test.bean.Grade;
import com.test.bean.Question;
import com.test.bean.Roles;
import com.test.bean.Score;
import com.test.bean.Student;
import com.test.bean.Teacher;
import com.test.service.CommonServiceImpl;
import com.test.service.ExamServiceImpl;
import com.test.service.ICommonService;
import com.test.service.IExamService;
import com.test.vo.OnlineExamPaper;
import com.test.vo.PageBean;

public class StudentAction extends ActionSupport {

	IExamService examservice = new ExamServiceImpl();
	ICommonService commonservice = new CommonServiceImpl();
	private PageBean studentPagebean ;
	private Student student ;
	private List gradeList ;		
	private List dateList ;			
	private List fangxiangList ;	
	private int p ;
	private List allStudent ;
	private String[] password ;		
	private String cmd ;
	private List examList ;			
	private Exam exam  ;
	private String studentAnwser ;
	private int qbs ;
	private int scid ;

	public String studentList(){
		
		getListinfo();
		DetachedCriteria dc = DetachedCriteria.forClass(Student.class);
		if(student!=null){
			if(student.getSno()!=null&&!student.getSno().equals("")){
				dc.add(Restrictions.like("sno", student.getSno(),MatchMode.ANYWHERE));
			}
			if(student.getSname()!=null&&!student.getSname().equals("")){
				dc.add(Restrictions.like("sname", student.getSname(),MatchMode.ANYWHERE));
			}
			if(student.getGid()!=0){
				dc.add(Restrictions.eq("gid", student.getGid()));
			}
			if(student.getSyear()!=null&&!student.getSyear().equals("")&&!student.getSyear().equals("0")){
				dc.add(Restrictions.eq("syear", student.getSyear()));
			}
			if(student.getFid()!=0){
				dc.add(Restrictions.eq("fid", student.getFid()));
			}
		}
		studentPagebean = commonservice.queryPageInfo(p,dc,4);
		return "studentList";
	}

	public void getListinfo(){
		
		Date date = new Date();
		int year = 1900 +date.getYear();
		dateList = new ArrayList();
		for(int i=0;i<=10;i++){
			dateList.add(year);
			year--;
		}
		DetachedCriteria dc1 = DetachedCriteria.forClass(Fangxiang.class);
		fangxiangList = commonservice.getObjectList(dc1);
		DetachedCriteria dc2 = DetachedCriteria.forClass(Grade.class);
		gradeList = commonservice.getObjectList(dc2);
	}

	public String addStudentPage(){
		
		getListinfo();
		return "toAddstudent";
	}

	public String addStudent(){
		
		getListinfo();
		cmd = "close";
		if(student!=null){
			student.setSpwd("123");
			Roles role = (Roles) commonservice.getobObjectById(Roles.class, 3);
			student.setRole(role);
			commonservice.addObject(student);
			DetachedCriteria dc = DetachedCriteria.forClass(Student.class);
			studentPagebean = commonservice.queryPageInfo(p, dc,4);
		}
		return "toAddstudent";
	}

	public String toUpdate(){
		
		getListinfo();
		if(student!=null&&student.getSid()!=0){
			student = (Student)commonservice.getobObjectById(Student.class,student.getSid());
		}
		return "toUpdate";
	}

	public String updateStudent(){
		
		getListinfo();
		cmd = "close";
		if(student!=null){
			
			Roles role = (Roles) commonservice.getobObjectById(Roles.class, 3);
			student.setRole(role);
			Grade grade = (Grade) commonservice.getobObjectById(Grade.class, student.getGid());
			student.setGrade(grade);
			commonservice.updateObject(student);
			DetachedCriteria dc = DetachedCriteria.forClass(Student.class);
			studentPagebean = commonservice.queryPageInfo(p, dc,4);
		}
		return "toUpdate";
	}

	public String deleteStudent(){
		
		Student s = (Student) commonservice.getobObjectById(Student.class, student.getSid());
		commonservice.deleteObject(s);
		student = null ;	
		return studentList();
	}

	public String exportStudentInfo(){
		
		DetachedCriteria dc = DetachedCriteria.forClass(Student.class);
		allStudent = commonservice.getObjectList(dc);
		return "exportStudent";
	}

	public String selfIformation(){

		student = (Student) ServletActionContext.getRequest().getSession().getAttribute("loginUser");
		Fangxiang fangxiang = new Fangxiang();
		if(student!=null&&student.getFid()!=0){
			fangxiang = (Fangxiang) commonservice.getobObjectById(Fangxiang.class, student.getFid());
			ServletActionContext.getRequest().getSession().setAttribute("fangxiang", fangxiang);
		}
		return "selfInfo";
	}

	public String updatePwd(){
		
		if(password!=null){
			if(password.length<2){
				super.addActionError("完整信息");
				return "updatepwd";
			}else{
				if(password[0]==null||password[0].equals("")&&password[1]==null||password[1].equals("")&&password[2]==null||password[2].equals("")){
					super.addActionError("不为空");
					return "updatepwd";
				}else{
					student = (Student) ServletActionContext.getRequest().getSession().getAttribute("loginUser");
					if(password[0].equals(student.getSpwd())&&password[1].equals(password[2])){
						student.setSpwd(password[1]);
						commonservice.updateObject(student);
						cmd = "updateOk";
						return "updatepwd";
					}else{
						super.addActionError("密码不一致");
						return "updatepwd";
					}
				}
			}
		}
		super.addActionError("无数据");
		return "updatepwd";
	}
	
	public String selectExam(){
		
		examList = new ArrayList() ;
		student = (Student) ServletActionContext.getRequest().getSession().getAttribute("loginUser");
		List<Exam> examInfoList = commonservice.getObjectByHql("from Exam");
		for(Exam exam:examInfoList){		
			if(exam.getGid()!=null&&!exam.getGid().equals("")){
				String[] gids = exam.getGid().split(",");
				for(int i=0;i<gids.length;i++){
					if(Integer.parseInt(gids[i])==student.getGid()){
						OnlineExamPaper onlineExamPaper = (OnlineExamPaper) commonservice.getOnlineExamPaper(exam);
						examList.add(onlineExamPaper);
					}
				}
			}
		}
		return "selectExam";
	}

	public String testStart(){
		
		student = (Student) ServletActionContext.getRequest().getSession().getAttribute("loginUser");
		if(exam.getExamid()!=0){
			exam = (Exam) commonservice.getobObjectById(Exam.class, exam.getExamid());
			ServletActionContext.getRequest().getSession().setAttribute("exam", exam);
		}
		List shitiList = examservice.examshitiList(exam);			
		ServletActionContext.getRequest().getSession().setAttribute("shitiList", shitiList);
		if(exam.getGid().split(",").length==1){
			String tim = exam.getEstartime().replace("-", "/");
			Date examdate =	new Date(tim);
			Date now = new Date();
			if(now.getTime()<examdate.getTime()){
				cmd = "cantExam";		
				ServletActionContext.getRequest().getSession().setAttribute("shitiList", null);
			}
			return "testStart";
		}
		if(student.getGid()!=0){
			int index = 0 ;
			String[] gids = exam.getGid().split(",");
			for(int i=0;i<gids.length;i++){
				if(Integer.parseInt(gids[i])==student.getGid()){
					index = i ;
				}
			}
			String[] dates = exam.getEstartime().split(",");
			exam.setEstartime(dates[index]);
		}
		String tim = exam.getEstartime().replace("-", "/");
		Date examdate =	new Date(tim);
		Date now = new Date();
		if(now.getTime()<examdate.getTime()){
			cmd = "cantExam";		
			ServletActionContext.getRequest().getSession().setAttribute("shitiList", null);
		}
		return "testStart";
	}
	
	public String examFinish(){
		
		int totalScore = 0; 
		Exam myexam = (Exam) ServletActionContext.getRequest().getSession().getAttribute("exam");
		System.out.println("myexam="+myexam+"  "+myexam.getExamid());
		List shitiList =  (List) ServletActionContext.getRequest().getSession().getAttribute("shitiList");
		if(studentAnwser.equals("")){
			Score thisScoreInfo = new Score();
			thisScoreInfo.setExamid(myexam.getExamid());	
			thisScoreInfo.setExam(myexam);		
			student = (Student) ServletActionContext.getRequest().getSession().getAttribute("loginUser");
			thisScoreInfo.setSid(student.getSid());
			thisScoreInfo.setSname(student.getSname());
			thisScoreInfo.setStartTime(myexam.getEstartime());
			Date now = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			thisScoreInfo.setEndTime(sdf.format(now));
			thisScoreInfo.setAnwser(studentAnwser);
			thisScoreInfo.setTatalScore(totalScore);
			commonservice.addObject(thisScoreInfo);
			cmd = "examFinish";		
			return "testStart";
		}
		if(shitiList!=null&&studentAnwser!=null){
			String[] anwsers = studentAnwser.split(","); 
			for(int i=0;i<anwsers.length;i++){
				String[] per = anwsers[i].split("_");
				int index = Integer.parseInt(per[0])-1;  
				if(shitiList.get(index)!=null){
					Question ques = (Question) shitiList.get(index);
					if(per[1]!=null&&per[1].equals(ques.getAnswer())){
						totalScore += myexam.getScore() ;
					}else if(per[1]!=null&&ques.getAnswer().contains(per[1])){
						totalScore += Math.floor(myexam.getScore()*0.6) ; 
					}
				}
			}
		}
		Score thisScoreInfo = new Score();
		thisScoreInfo.setExamid(myexam.getExamid());
		thisScoreInfo.setExam(myexam);
		student = (Student) ServletActionContext.getRequest().getSession().getAttribute("loginUser");
		thisScoreInfo.setSid(student.getSid());
		thisScoreInfo.setSname(student.getSname());
		thisScoreInfo.setStartTime(myexam.getEstartime());
		Date now = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		thisScoreInfo.setEndTime(sdf.format(now));
		thisScoreInfo.setAnwser(studentAnwser);
		thisScoreInfo.setTatalScore(totalScore);
		commonservice.addObject(thisScoreInfo);
		
		cmd = "examFinish";		
		return "testStart";
	}
	public String getScoreInfo(){
		
		if(p==0){
			p = 1 ;
		}
		if(qbs==0){
			qbs = (Integer) ServletActionContext.getRequest().getSession().getAttribute("qbs");
		}
		if(qbs!=0){
			student = (Student) ServletActionContext.getRequest().getSession().getAttribute("loginUser");
			DetachedCriteria dctest = DetachedCriteria.forClass(Score.class)
					.add(Restrictions.eq("sid", student.getSid()))
					.setFetchMode("exam", FetchMode.JOIN)
					.createAlias("exam", "exam")
					.add(Restrictions.eq("exam.etype", qbs));
			PageBean scorePagebean = commonservice.queryPageInfo(p, dctest, 4);
			ServletActionContext.getRequest().getSession().setAttribute("scorePagebean", scorePagebean);
			ServletActionContext.getRequest().getSession().setAttribute("qbs", qbs);
		}
		return "scoreList";
	}
	
	public String lookScoreInfo(){
		
		if(scid!=0){
			List scoreInfo = examservice.getmyScoreInfo(scid);
			ServletActionContext.getRequest().getSession().setAttribute("scoreInfo", scoreInfo);
		}
		return "scoreInfo";
	}
	
	public PageBean getStudentPagebean() {
		return studentPagebean;
	}


	public void setStudentPagebean(PageBean studentPagebean) {
		this.studentPagebean = studentPagebean;
	}


	public int getP() {
		return p;
	}


	public void setP(int p) {
		this.p = p;
	}


	public Student getStudent() {
		return student;
	}



	public String[] getPassword() {
		return password;
	}


	public void setPassword(String[] password) {
		this.password = password;
	}


	public void setStudent(Student student) {
		this.student = student;
	}


	public List getGradeList() {
		return gradeList;
	}


	public void setGradeList(List gradeList) {
		this.gradeList = gradeList;
	}


	public List getDateList() {
		return dateList;
	}


	public void setDateList(List dateList) {
		this.dateList = dateList;
	}


	public List getFangxiangList() {
		return fangxiangList;
	}


	public String getCmd() {
		return cmd;
	}


	public void setCmd(String cmd) {
		this.cmd = cmd;
	}


	public void setFangxiangList(List fangxiangList) {
		this.fangxiangList = fangxiangList;
	}


	public List getAllStudent() {
		return allStudent;
	}


	public void setAllStudent(List allStudent) {
		this.allStudent = allStudent;
	}


	public List getExamList() {
		return examList;
	}


	public void setExamList(List examList) {
		this.examList = examList;
	}


	public Exam getExam() {
		return exam;
	}


	public void setExam(Exam exam) {
		this.exam = exam;
	}


	public String getStudentAnwser() {
		return studentAnwser;
	}


	public void setStudentAnwser(String studentAnwser) {
		this.studentAnwser = studentAnwser;
	}


	public int getQbs() {
		return qbs;
	}


	public void setQbs(int qbs) {
		this.qbs = qbs;
	}


	public int getScid() {
		return scid;
	}


	public void setScid(int scid) {
		this.scid = scid;
	}







}