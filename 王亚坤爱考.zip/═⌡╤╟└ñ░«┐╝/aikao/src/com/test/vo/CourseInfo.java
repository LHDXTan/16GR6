package com.test.vo;

import com.test.bean.Professional;

public class CourseInfo {
	private int pid ;
	private String proname ;
	private String jname ;
	private int jishiCount ;
	private int bishiCount ;
	
	
	public CourseInfo() {
		
	}
	
	
	public int getJishiCount() {
		return jishiCount;
	}
	public void setJishiCount(int jishiCount) {
		this.jishiCount = jishiCount;
	}
	public int getBishiCount() {
		return bishiCount;
	}
	public void setBishiCount(int bishiCount) {
		this.bishiCount = bishiCount;
	}


	public int getPid() {
		return pid;
	}


	public void setPid(int pid) {
		this.pid = pid;
	}


	public String getProname() {
		return proname;
	}


	public void setProname(String proname) {
		this.proname = proname;
	}


	public String getJname() {
		return jname;
	}


	public void setJname(String jname) {
		this.jname = jname;
	}
	
	
}
