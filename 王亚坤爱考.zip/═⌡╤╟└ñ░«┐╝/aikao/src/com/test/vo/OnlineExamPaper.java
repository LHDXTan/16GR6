package com.test.vo;

public class OnlineExamPaper {

	
	private Integer examid ;
	private String qbs ;
	private String kemu ;
	private String title;
	private String gnames ;
	private String begintime ;
	private String examtime ;
	
	
	
	
	public OnlineExamPaper() {
		
	}
	
	
	public Integer getExamid() {
		return examid;
	}
	public void setExamid(Integer examid) {
		this.examid = examid;
	}
	public String getQbs() {
		return qbs;
	}
	public void setQbs(String qbs) {
		this.qbs = qbs;
	}
	public String getKemu() {
		return kemu;
	}
	public void setKemu(String kemu) {
		this.kemu = kemu;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getGnames() {
		return gnames;
	}
	public void setGnames(String gnames) {
		this.gnames = gnames;
	}
	public String getBegintime() {
		return begintime;
	}
	public void setBegintime(String begintime) {
		this.begintime = begintime;
	}
	public String getExamtime() {
		return examtime;
	}
	public void setExamtime(String examtime) {
		this.examtime = examtime;
	}
	
	
}
