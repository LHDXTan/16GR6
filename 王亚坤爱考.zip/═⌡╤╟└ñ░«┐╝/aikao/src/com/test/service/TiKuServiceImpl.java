package com.test.service;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;

import com.test.dao.ITiKuDao;
import com.test.dao.TiKuDaoImpl;

public class TiKuServiceImpl implements ITiKuService {

	ITiKuDao tikudao = new TiKuDaoImpl();
	
	@Override
	public List getProfessionalList(DetachedCriteria dc) {
		return tikudao.getProfessionalList(dc);
	}

	
	
}
