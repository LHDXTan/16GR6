package com.test.service;

import java.util.List;

import com.test.bean.Exam;
import com.test.bean.Student;
import com.test.vo.ExamScoreInfo;
import com.test.vo.PageBean;


public interface IExamService {

	public PageBean getGradeNames(PageBean pagebean);
	
	public List examshitiList(Exam exam);
	
	public List getmyScoreInfo(int scid);
	
	public ExamScoreInfo getExamScore(int examid,Student student);
	
	
}
