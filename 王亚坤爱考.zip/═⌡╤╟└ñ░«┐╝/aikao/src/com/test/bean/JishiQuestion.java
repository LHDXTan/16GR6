package com.test.bean;

public class JishiQuestion implements java.io.Serializable {

	private Integer jishiId;
	private String title;
	private String context ;
	private String memo;
	private String attachment;
	private Integer did;
	private Integer pid;
	
	private Diffcult diffcult ;		
	private Professional professional ;	
	
	public JishiQuestion() {
	}

	public JishiQuestion(Integer jishiId) {
		this.jishiId = jishiId;
	}

	public JishiQuestion(Integer jishiId, String title, String memo,
			String attachment, Integer did, Integer pid) {
		this.jishiId = jishiId;
		this.title = title;
		this.memo = memo;
		this.attachment = attachment;
		this.did = did;
		this.pid = pid;
	}

	public Integer getJishiId() {
		return this.jishiId;
	}

	public void setJishiId(Integer jishiId) {
		this.jishiId = jishiId;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getMemo() {
		return this.memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public String getAttachment() {
		return this.attachment;
	}

	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}

	public Integer getDid() {
		return this.did;
	}

	public void setDid(Integer did) {
		this.did = did;
	}

	public Integer getPid() {
		return this.pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public Diffcult getDiffcult() {
		return diffcult;
	}

	public void setDiffcult(Diffcult diffcult) {
		this.diffcult = diffcult;
	}

	public Professional getProfessional() {
		return professional;
	}

	public void setProfessional(Professional professional) {
		this.professional = professional;
	}

	public String getContext() {
		return context;
	}

	public void setContext(String context) {
		this.context = context;
	}
	
	

}