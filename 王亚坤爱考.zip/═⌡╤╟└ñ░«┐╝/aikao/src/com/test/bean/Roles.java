package com.test.bean;

public class Roles implements java.io.Serializable {

	private Integer rid;
	private String rname;

	public Roles() {
	}

	public Roles(Integer rid) {
		this.rid = rid;
	}

	public Roles(Integer rid, String rname) {
		this.rid = rid;
		this.rname = rname;
	}

	public Integer getRid() {
		return this.rid;
	}

	public void setRid(Integer rid) {
		this.rid = rid;
	}

	public String getRname() {
		return this.rname;
	}

	public void setRname(String rname) {
		this.rname = rname;
	}

}