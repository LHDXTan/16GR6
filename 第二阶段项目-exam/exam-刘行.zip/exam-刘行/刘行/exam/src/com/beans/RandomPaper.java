package com.beans;

public class RandomPaper {
	private String fangxiang;	//方向
	private String jieduan;		//阶段
	private String kemu;		//科目
	private int oeasy;			//单选简单 题数
	private int onormal;		//单选中等
	private int ohard;			//单选困难
	private int teasy;			//多选简单
	private int tnormal;		//多选中等
	private int thard;			//多选困难
	
	private int type;			//忘了是啥了
	private int state;			//试卷状态
	

	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public String getFangxiang() {
		return fangxiang;
	}
	public void setFangxiang(String fangxiang) {
		this.fangxiang = fangxiang;
	}
	public String getJieduan() {
		return jieduan;
	}
	public void setJieduan(String jieduan) {
		this.jieduan = jieduan;
	}
	public String getKemu() {
		return kemu;
	}
	public void setKemu(String kemu) {
		this.kemu = kemu;
	}
	public int getOeasy() {
		return oeasy;
	}
	public void setOeasy(int oeasy) {
		this.oeasy = oeasy;
	}
	public int getOnormal() {
		return onormal;
	}
	public void setOnormal(int onormal) {
		this.onormal = onormal;
	}
	public int getOhard() {
		return ohard;
	}
	public void setOhard(int ohard) {
		this.ohard = ohard;
	}
	public int getTeasy() {
		return teasy;
	}
	public void setTeasy(int teasy) {
		this.teasy = teasy;
	}
	public int getThard() {
		return thard;
	}
	public void setThard(int thard) {
		this.thard = thard;
	}
	public int getTnormal() {
		return tnormal;
	}
	public void setTnormal(int tnormal) {
		this.tnormal = tnormal;
	}
	
	

}
