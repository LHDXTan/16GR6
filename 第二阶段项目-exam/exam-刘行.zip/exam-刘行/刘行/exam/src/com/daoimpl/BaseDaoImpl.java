package com.daoimpl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;




import com.beandao.HibernateSessionFactory;
import com.beans.PageBean;
import com.beans.RandomPaper;
import com.dao.BaseDao;
import com.google.gson.Gson;
import com.pojo.Adminuser;
import com.pojo.Question;
import com.pojo.Student;
import com.pojo.Subject;
import com.pojo.Teacher;

public class BaseDaoImpl implements BaseDao {
	
	//通过suid获取到全部的难度的题（笔试题）
	public List getPenQuestions(int suid) {
		String sql1 = "select qid from question where qtype=1 and type='单选' and suid="+suid+" and hard='简单'";
		String sql2 = "select qid from question where qtype=1 and type='单选' and suid="+suid+" and hard='中等'";
		String sql3 = "select qid from question where qtype=1 and type='单选' and suid="+suid+" and hard='困难'";
		
		String sql4 = "select qid from question where qtype=1 and type='多选' and suid="+suid+" and hard='简单'";
		String sql5 = "select qid from question where qtype=1 and type='多选' and suid="+suid+" and hard='中等'";
		String sql6 = "select qid from question where qtype=1 and type='多选' and suid="+suid+" and hard='困难'";
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		List alllist = new ArrayList();
		List list = new ArrayList();
		try{
			list = session.createSQLQuery(sql1).list();
			alllist.add(list);   
			list = session.createSQLQuery(sql2).list();
			alllist.add(list);
			list = session.createSQLQuery(sql3).list();
			alllist.add(list);
			list = session.createSQLQuery(sql4).list();
			alllist.add(list);
			list = session.createSQLQuery(sql5).list();
			alllist.add(list);
			list = session.createSQLQuery(sql6).list();
			alllist.add(list);
		    tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
			
		}
		HibernateSessionFactory.closeSession();
		return alllist;
	}
	
	//获取科目表的suid
	public int getSuid(RandomPaper ran) {
		String sql = "select suid from subject " +
				"where sudirec='"+ran.getFangxiang()+"' " +
				"AND sustage='"+ran.getJieduan()+"' " +
				"AND suName = '"+ran.getKemu()+"'";
		int suid = 0;
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		List list = new ArrayList();
		try{
		    list = session.createSQLQuery(sql).list();
		    if(list.size()!=0){
		    	suid = Integer.parseInt(list.get(0).toString());
		    }
		    tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
			
		}
		HibernateSessionFactory.closeSession();
		return suid;
	}
	
	//下拉框获取方向
	public String fangXiang() {
		String str = "";
		StringBuffer sb = new StringBuffer("");
		String sql = "select distinct sudirec from subject";
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		List list = new ArrayList();
		List list2 = new ArrayList();
		List list3 = new ArrayList();
		SQLQuery query =null;
		try{
			list=session.createSQLQuery(sql).list();
			for(int i =0;i<list.size();i++){
				sb.append(list.get(i).toString()+":{");
				sql = "select distinct sustage from subject where sudirec = '"+list.get(i).toString()+"'";
				list2 = session.createSQLQuery(sql).list();
				for(int j =0;j<list2.size();j++){
					sb.append(list2.get(j).toString()+":");
					sql = "select distinct suName from subject where sudirec = '"+list.get(i).toString()+"' and sustage='"+list2.get(j).toString()+"'";
					list3 = session.createSQLQuery(sql).list();
					sb.append("'");
					for(int x = 0;x<list3.size();x++){
						sb.append(list3.get(x).toString()+",");
					}
					sb.deleteCharAt(sb.length()-1);  
					sb.append("',");
				}
				sb.append("},");
			}
			str = sb.toString();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
		HibernateSessionFactory.closeSession();
		return str;
	}
	
	//机试分页
	public PageBean getComputerQuestion(Subject sub,int p) {
		String hql = "from Question where suid ='"+sub.getSuid()+"' and qtype = 0";
		String sql = "select count(*) nub from Question where suid ='"+sub.getSuid()+"' and qtype = 0";
		int cnt = 0;
		if(p!=0)cnt = (p-1)*10;
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		List result =new ArrayList();
		PageBean pb = new PageBean();
		try{
			List list = session.createSQLQuery(sql).list();
			pb.setCount(Integer.parseInt(list.get(0).toString()));
			pb.setP(p);
		    Query q = session.createQuery(hql);
		    q.setFirstResult(cnt);//设置起始行
			q.setMaxResults(10);//每页条数
			result = q.list(); //得到每页的数据
			pb.setQuestionlist(result);
		    tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
			
		}
		HibernateSessionFactory.closeSession();
		return pb;
	}
	
	
	//笔试分页
		public PageBean getPentQuestion(Subject sub,int p) {
			String hql = "from Question where suid ='"+sub.getSuid()+"' and qtype = 1";
			String sql = "select count(*) nub from Question where suid ='"+sub.getSuid()+"' and qtype = 1";
			int cnt = 0;
			if(p!=0)cnt = (p-1)*10;
			Session session = HibernateSessionFactory.getSession();
			Transaction tx=session.beginTransaction();
			List result =new ArrayList();
			PageBean pb = new PageBean();
			try{
				List list = session.createSQLQuery(sql).list();
				pb.setCount(Integer.parseInt(list.get(0).toString()));
				pb.setP(p);
			    Query q = session.createQuery(hql);
			    q.setFirstResult(cnt);//设置起始行
				q.setMaxResults(10);//每页条数
				result = q.list(); //得到每页的数据
				pb.setQuestionlist(result);
			    tx.commit();
			}catch(Exception e){
				tx.rollback();
				e.printStackTrace();
				
			}
			HibernateSessionFactory.closeSession();
			return pb;
		}
	
	//科目查询下拉框，阶段
	@Override
	public List<Subject> getSudSelect() {
		String sql = "select distinct sustage from subject";
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		List<Subject> list = new ArrayList();
		List<Subject> sublist = new ArrayList();
		SQLQuery query =null;
		try{
			query=session.createSQLQuery(sql);
			list = query.list();
			for(int i=0;i<list.size();i++){
				Subject sub = new Subject();
				sub.setSustage(String.valueOf(list.get(i)));
				sublist.add(sub);
			}
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
		HibernateSessionFactory.closeSession();
		return sublist;
	}
	
	//科目查询下拉框，方向
	@Override
	public List<Subject> getSusSelect() {
		String sql = "select distinct sudirec from subject";
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		List<Subject> list = new ArrayList();
		List<Subject> sublist = new ArrayList();
		SQLQuery query =null;
		try{
			query=session.createSQLQuery(sql);
			list = query.list();
			for(int i=0;i<list.size();i++){
				Subject sub = new Subject();
				sub.setSudirec(String.valueOf(list.get(i)));
				sublist.add(sub);
			}
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
		HibernateSessionFactory.closeSession();
		return sublist;
	}
	
	//题数哈哈哈哈
	public List<Subject> getQuestionNub() {
		String hql = "from Subject";
		String sql = " select  s.suId,c.num ,c.qtype " +
				" from subject s ,(select DISTINCT  COUNT(q.qtype) num,q.suid,q.qtype " +
				" from question q group  by q.qtype,q.suid,q.qtype) c " +
				" where s.suId=c.suid";
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		List<Object[]> list = new ArrayList();
		List<Subject> subjectlist =new ArrayList();
		SQLQuery sqlquery =null;
		List<Subject> sublist =new ArrayList();
		List<Subject> subject = new ArrayList();
		Subject sub = null;
		try{
			subjectlist=session.createQuery(hql).list();
			sqlquery=session.createSQLQuery(sql);
			list = sqlquery.list();
			for(int j=0;j<list.size();j++){
				Object[] a = list.get(j);
				int suid =	(Integer) a[0];
				int num = (Integer) a[1];
				int qtype = (Integer) a[2];
				for(int i=0;i<subjectlist.size();i++){
					sub	= subjectlist.get(i);
					if(suid == sub.getSuid()){
						if(qtype==0){
							sub.setComputernub(num);
						} else if(qtype==1){
							sub.setPennub(num);
						}
					}
					subject.add(sub);
				}
			}
			subjectlist=session.createQuery(hql).list();
		    tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
		HibernateSessionFactory.closeSession();
		return subjectlist;
	}

	//查询试卷里的题
	public List getQuestion(String hql) {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		List result =new ArrayList();
		try{
		    result=session.createQuery(hql).list();
		    tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
			
		}
		HibernateSessionFactory.closeSession();
		return result;
	}
	
	//登录校验
	@Override
	public List login(String nam,String pwd,int role) {
		String sql = "select * from ";
		if(role==1){
			sql += " student ";
		} else if(role==2){
			sql += " teacher ";
		} else {
			sql += " adminuser ";
		}
		sql += "where loginuser='"+nam+"' and password='"+pwd+"'";
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		List list = new ArrayList();
		SQLQuery query =null;
		try{
			query=session.createSQLQuery(sql);
			if(role==1){
				query.addEntity(Student.class);
			} else if(role==2){
				query.addEntity(Teacher.class);
			} else {
				query.addEntity(Adminuser.class);
			}
			list = query.list();
			if(list.size()!=0){
				if(1==role){
					list.add("student");
				} else if(2==role) {
					list.add("teacher");
				} else if(3==role){
					list.add("admin");
				}
			}
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
		HibernateSessionFactory.closeSession();
		return list;
	}
	
	@Override
	public int add(Object obj) {
		int flag = 0;
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		try{
		    session.save(obj);
		    tx.commit();
		    flag = 1;
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
		HibernateSessionFactory.closeSession();
		return flag;
	}

	@Override
	public int update(Object obj) {
		int flag = 0;
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		
		try{
		    session.update(obj);
		    tx.commit();
		    flag = 1;
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
			
		}
		HibernateSessionFactory.closeSession();
		return flag;
	}

	@Override
	public int delete(Object obj) {
		int flag = 0;
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		
		try{
		    session.delete(obj);
		    tx.commit();
		    flag = 1;
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
			
		}
		HibernateSessionFactory.closeSession();
		return flag;
	}

	@Override
	public Object getObjectById(Class clazz, Serializable id) {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		Object obj=null;
		try{
		    obj=session.get(clazz, id);
		    tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
		HibernateSessionFactory.closeSession();
		return obj;
	}

	@Override
	public List getObjects(String hql) {
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		List result =new ArrayList();
		try{
		    result=session.createQuery(hql).list();
		    tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
		HibernateSessionFactory.closeSession();
		return result;
	}
	
	
	

}
