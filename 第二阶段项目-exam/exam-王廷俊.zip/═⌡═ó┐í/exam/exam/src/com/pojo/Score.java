package com.pojo;

/**
 * Score entity. @author MyEclipse Persistence Tools
 */

public class Score implements java.io.Serializable {

	// Fields

	private Integer scid;
	private Integer pid;
	private Integer sid;
	private String sname;
	private String examtime;
	private String endtime;
	private String answer;
	private Integer totalScore;
	private String classes;
	//many-to-one
	private Paper paper ;

	// Constructors

	/** default constructor */
	public Score() {
	}

	/** minimal constructor */
	public Score(Integer scid) {
		this.scid = scid;
	}

	/** full constructor */
	public Score(Integer scid, Integer pid, Integer sid, String sname,
			String examtime, String endtime, String answer, Integer totalScore,String classes) {
		this.scid = scid;
		this.pid = pid;
		this.sid = sid;
		this.sname = sname;
		this.examtime = examtime;
		this.endtime = endtime;
		this.answer = answer;
		this.totalScore = totalScore;
		this.classes = classes;
	}

	// Property accessors

	public Integer getScid() {
		return this.scid;
	}

	public void setScid(Integer scid) {
		this.scid = scid;
	}

	public Integer getPid() {
		return this.pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public Integer getSid() {
		return this.sid;
	}

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	public String getSname() {
		return this.sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getExamtime() {
		return this.examtime;
	}

	public void setExamtime(String examtime) {
		this.examtime = examtime;
	}

	public String getEndtime() {
		return this.endtime;
	}

	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}

	public String getAnswer() {
		return this.answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public Integer getTotalScore() {
		return this.totalScore;
	}

	public void setTotalScore(Integer totalScore) {
		this.totalScore = totalScore;
	}

	public Paper getPaper() {
		return paper;
	}

	public void setPaper(Paper paper) {
		this.paper = paper;
	}

	public String getClasses() {
		return classes;
	}

	public void setClasses(String classes) {
		this.classes = classes;
	}

}