﻿package com.action;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.daoimpl.BaseDaoImpl;
import com.daoimpl.ExamDaoImpl;
import com.daoimpl.PaperDaoImpl;
import com.opensymphony.xwork2.ActionSupport;
import com.pojo.Classes;
import com.pojo.Paper;
import com.pojo.Paperinfo;
import com.pojo.Question;
import com.pojo.Score;
import com.pojo.Student;

public class ExamAction extends ActionSupport {
	private List<Paper> paperlist;
	private Student stu;
	private Classes cla;
	private Paper paper;
	private String studentAnwser;
	private List<Question> questionlist;
	private List<Paperinfo> infolist;
	BaseDaoImpl base = new BaseDaoImpl();
	PaperDaoImpl pdi = new PaperDaoImpl();
	ExamDaoImpl edi = new ExamDaoImpl();
	HttpServletRequest request = ServletActionContext.getRequest();
	HttpServletResponse response = ServletActionContext.getResponse();
	
	//完成考试 交卷 结束考试
	public String examFinish(){
		int totalScore = 0;//记录总分数
		paper = (Paper)request.getSession().getAttribute("paper");
		System.out.println("myexam="+paper+"  "+paper.getPid());
		List shitilist = (List)request.getSession().getAttribute("questionlist");
		if(studentAnwser!=null && shitilist!=null){
			String[] anwser = studentAnwser.split(",");
			for(int i=0;i<anwser.length;i++){
				String[] per = anwser[i].split("_");
				int index = Integer.parseInt(per[0])-1;
				if(shitilist.get(index)!=null){
					Question que = (Question)shitilist.get(index);
					if(per[1]!=null && per[1].equals(que.getAnswer())){
						totalScore += paper.getPone();
					} else if(per[1]!=null && que.getAnswer().contains(per[1])){
						totalScore += Math.floor(paper.getPone()*0.6) ; //给60%的分数 向下取整
					}
				}
			}
		}
		stu = (Student)request.getSession().getAttribute("student");
		Score score = new Score();
		score.setPid(paper.getPid());
		score.setPaper(paper);
		score.setSid(stu.getSid());
		score.setSname(stu.getSname());
		score.setExamtime(paper.getExamtime());
		Date now = new Date();
		System.out.println(now);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		score.setEndtime(sdf.format(now));
		score.setAnswer(studentAnwser);
		score.setTotalScore(totalScore);
		score.setClasses(paper.getClassname());
		int flag = base.add(score);
		try {
			response.getWriter().print(flag);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	//点击开始
	public String questionList(){
		Student stu = (Student)request.getSession().getAttribute("student");
		paper = (Paper)base.getObjectById(Paper.class, paper.getPid());
		request.getSession().setAttribute("paper", paper);
		questionlist = edi.examshitiList(paper);	//获取考试的题
		request.getSession().setAttribute("questionlist", questionlist);
		return "examIng";
	}
	
	public String allExamPaper(){
		Student stu = (Student)request.getSession().getAttribute("student");
		cla = (Classes)base.getObjectById(Classes.class, stu.getSclass());
		paperlist = base.getObjects("from Paper where classname = '"+cla.getClassname()+"' and pstate != 3");
		return "toAllExamPaper";
	}
	public List<Paper> getPaperlist() {
		return paperlist;
	}
	public void setPaperlist(List<Paper> paperlist) {
		this.paperlist = paperlist;
	}
	public Student getStu() {
		return stu;
	}
	public void setStu(Student stu) {
		this.stu = stu;
	}
	public Classes getCla() {
		return cla;
	}
	public void setCla(Classes cla) {
		this.cla = cla;
	}
	public Paper getPaper() {
		return paper;
	}
	public void setPaper(Paper paper) {
		this.paper = paper;
	}

	public List<Question> getQuestionlist() {
		return questionlist;
	}

	public void setQuestionlist(List<Question> questionlist) {
		this.questionlist = questionlist;
	}

	public List<Paperinfo> getInfolist() {
		return infolist;
	}

	public void setInfolist(List<Paperinfo> infolist) {
		this.infolist = infolist;
	}

	public String getStudentAnwser() {
		return studentAnwser;
	}

	public void setStudentAnwser(String studentAnwser) {
		this.studentAnwser = studentAnwser;
	}


	
}
