package com.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.daoimpl.BaseDaoImpl;
import com.opensymphony.xwork2.Action;
import com.pojo.Teacher;


public class jsgl implements Action {
    private Teacher tea;
	private List<Teacher> tealist;
	private String loginuser;
	private String tname ;
	private String tgangwei;
	
	
	public String getLoginuser() {
		return loginuser;
	}

	public void setLoginuser(String loginuser) {
		this.loginuser = loginuser;
	}

	public String getTname() {
		return tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	public String getTgangwei() {
		return tgangwei;
	}

	public void setTgangwei(String tgangwei) {
		this.tgangwei = tgangwei;
	}

	public Teacher getTea() {
		return tea;
	}

	public void setTea(Teacher tea) {
		this.tea = tea;
	}

	public List<Teacher> getTealist() {
		return tealist;
	}

	public void setTealist(List<Teacher> tealist) {
		this.tealist = tealist;
	}

	BaseDaoImpl dao = new BaseDaoImpl();
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	//查询所有教师信息
	public String selJsxx(){
		tealist = dao.getObjects("from Teacher");
		System.out.println("查询所有教师信息");
		return "jsxx";
		
	}
	
	//根据账号或姓名查询该教师的信息
	public String seljs(){
//
//			String hql = "select  t.tid,t.loginuser,t.tname,t.tgangwei  " +
//			                        
//			                           "from  Teacher  t  group by t.tid,t.loginuser,t.tname,t.tgangwei";
//			tealist = dao.getObjects(hql);
//		tealist = dao.getObjects("from Teacher");	
//		
//		String hql = "from Teacher  t  where 1=1 ";
//			if(tea!=null){
//				if(tea.getLoginuser()!=null && !tea.getLoginuser().equals("") &&tea.getTname()!=null&& !tea.getTname().equals("")){
//					 hql += " and  t.tname like '%" + tea.getTname() + "%' and t.Loginuser like '%" + tea.getLoginuser() + "%' ";
//				}
//			}
//				tealist = dao.getObjects(hql);
		//tealist = dao.getObjects("from Teacher where loginuser='"+tea.getLoginuser()+"' ");
		
		
//		String sql = null;
//		if(!("0").equals(tea.getLoginuser()) && !("0").equals(tea.getTname())&& !("0").equals(tea.getTgangwei())){
//			sql = "from Teacher where loginuser ='"+tea.getLoginuser()+"' and tname = '"+tea.getTname()+"'and tgangwei = '"+tea.getTgangwei()+"'   ";
//		} else if(!("0").equals(tea.getLoginuser())){
//			sql = "from Teacher where loginuser='"+tea.getLoginuser()+"'";
//		} else if(!("0").equals(tea.getTname())){
//			sql = "from Teacher where tname ='"+tea.getTname()+"'";
//		} else if(!("0").equals(tea.getTgangwei())){
//			sql = "from Teacher where tgangwei ='"+tea.getTgangwei()+"'";
//		} else if(("0").equals(tea.getLoginuser()) || ("0").equals(tea.getTname())|| ("0").equals(tea.getTgangwei())){
//			return "tolist";
//		}
//		tealist = dao.getObjects(sql);
		
		tealist =  dao.seltea(loginuser, tname, tgangwei);
         System.out.println("根据账号或姓名查询该教师的信息");
		return "jsxx";
	}
	//进入添加教师页面
	public String toaddjsxx(){
				
//				 if(tea.getTid()!=null){
//					 
//					 tea=  (Teacher) dao.getObjectById(Teacher.class, tea.getTid());
//					  return "addjsxx";
//				 }
		
		System.out.println("进入添加教师页面");
				return "addjsxx";
				
			}
			
	//添加教师
	public String addjs(){
		HttpServletRequest re=ServletActionContext.getRequest();
		tea.setPassword("123456");
		tea.setJid(2);
		dao.add(tea);
		System.out.println("添加教师");
		re.setAttribute("ok", "ok");
		return "addjsxx";
	}		
	
	//进入修改教师信息页面
	public String toxgjsxx(){
			
				 tea = (Teacher) dao.getObjectById(Teacher.class, tea.getTid());
				System.out.println("进入修改教师信息页面");
				return "toxgjsxx";
			}
			
    //修改教师信息
    public String xgjsxx(){
    	HttpServletRequest re=ServletActionContext.getRequest();
    	Teacher tid = (Teacher) dao.getObjectById(Teacher.class, tea.getTid());

        tid.setTname(tea.getTname());
        tid.setTsex(tea.getTsex());
        tid.setTbirthday(tea.getTbirthday());
        tid.setTeducation(tea.getTeducation());
        tid.setTphone(tea.getTphone());
        tid.setTgangwei(tea.getTgangwei());
        tid.setTbeizhu(tea.getTbeizhu());
        dao.update(tid);
    	System.out.println("修改教师信息");
    	re.setAttribute("ok", "ok");
        return "toxgjsxx";
			}
	
	//删除教师
	public String deljsxx(){
		Teacher tid =  (Teacher) dao.getObjectById(Teacher.class, tea.getTid());
		dao.delete(tid);
		System.out.println("删除教师");
		return "tolist";
	}
	
	
	//重置密码
	public String czmm(){
		
		Teacher teach =  (Teacher) dao.getObjectById(Teacher.class, tea.getTid());
		teach.setPassword("123456");
		dao.update(teach);
		System.out.println("重置密码");
		return "tolist";
	}

}
