package com.test.service;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;


import com.test.bean.Exam;
import com.test.dao.CommonDaoImpl;
import com.test.dao.ICommonDao;
import com.test.vo.OnlineExamPaper;
import com.test.vo.PageBean;

public class CommonServiceImpl implements ICommonService {

	ICommonDao commonDao = new CommonDaoImpl();
	
	
	@Override
	public List getObjectList(DetachedCriteria dc) {
		return commonDao.getObjectList(dc);
	}


	@Override
	public PageBean getPageInfo(int p, String hql) {
		return commonDao.getPageInfo(p, hql);
	}


	@Override
	public void addObject(Object obj) {
		commonDao.addObject(obj);
	}

	@Override
	public Object getobObjectById(Class class1, int id) {
		return commonDao.getobObjectById(class1, id);
	}
	
	public PageBean queryPageInfo(int p,DetachedCriteria dc,int pagesize){
		return commonDao.queryPageInfo(p, dc,pagesize);
	}


	@Override
	public void updateObject(Object obj) {
		commonDao.updateObject(obj);
	}


	@Override
	public void deleteObject(Object obj) {
		commonDao.deleteObject(obj);
	}


	@Override
	public List getObjectByHql(String hql) {
		return commonDao.getObjectByHql(hql);
	}


	@Override
	public OnlineExamPaper getOnlineExamPaper(Exam exam) {
		return commonDao.getOnlineExamPaper(exam);
	}
	
	
	
}
