package com.test.vo;

import com.test.bean.Score;

public class StudentScoreInfo {

	private Score score;		
	private String grade;		
	
	
	public StudentScoreInfo(){
		
	}
	
	
	public Score getScore() {
		return score;
	}
	public void setScore(Score score) {
		this.score = score;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	
	
}
