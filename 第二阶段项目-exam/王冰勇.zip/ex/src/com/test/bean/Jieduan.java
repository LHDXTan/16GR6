package com.test.bean;

public class Jieduan implements java.io.Serializable {

	private Integer jid;
	private String jname;

	public Jieduan() {
	}

	public Jieduan(Integer jid) {
		this.jid = jid;
	}

	public Jieduan(Integer jid, String jname) {
		this.jid = jid;
		this.jname = jname;
	}

	public Integer getJid() {
		return this.jid;
	}

	public void setJid(Integer jid) {
		this.jid = jid;
	}

	public String getJname() {
		return this.jname;
	}

	public void setJname(String jname) {
		this.jname = jname;
	}

}