package com.test.bean;


public class Manager implements java.io.Serializable {

	private Integer mid;
	private String mname;
	private String mpwd;
	private Integer rid;

	private Roles role ;
	
	public Manager() {
	}

	
	public Manager(Integer mid) {
		this.mid = mid;
	}

	
	public Manager(Integer mid, String mname, String mpwd, Integer rid) {
		this.mid = mid;
		this.mname = mname;
		this.mpwd = mpwd;
		this.rid = rid;
	}

	

	public Integer getMid() {
		return this.mid;
	}

	public void setMid(Integer mid) {
		this.mid = mid;
	}

	public String getMname() {
		return this.mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getMpwd() {
		return this.mpwd;
	}

	public void setMpwd(String mpwd) {
		this.mpwd = mpwd;
	}

	public Integer getRid() {
		return this.rid;
	}

	public void setRid(Integer rid) {
		this.rid = rid;
	}

	public Roles getRole() {
		return role;
	}

	public void setRole(Roles role) {
		this.role = role;
	}

	
	
}