package com.test.bean;

public class QType implements java.io.Serializable {

	private Integer qtid;
	private String qtname;

	public QType() {
	}

	public QType(Integer qtid) {
		this.qtid = qtid;
	}

	public QType(Integer qtid, String qtname) {
		this.qtid = qtid;
		this.qtname = qtname;
	}

	public Integer getQtid() {
		return this.qtid;
	}

	public void setQtid(Integer qtid) {
		this.qtid = qtid;
	}

	public String getQtname() {
		return this.qtname;
	}

	public void setQtname(String qtname) {
		this.qtname = qtname;
	}

}