package com.test.bean;

public class Question implements java.io.Serializable {

	private Integer qid;
	private Integer qtype;
	private String qtitle;
	private String optionA;
	private String optionB;
	private String optionC;
	private String optionD;
	private String answer;
	private Integer did;
	private String qutil;
	private Integer pid;
	
	
	private QType type ;			
	private Diffcult diffcult ;		
	private Professional professional ;	

	public Question() {
	}

	public Question(Integer qid) {
		this.qid = qid;
	}

	public Question(Integer qid, Integer qtype, String qtitle, String optionA,
			String optionB, String optionC, String optionD, String answer,
			Integer did, String qutil, Integer pid) {
		this.qid = qid;
		this.qtype = qtype;
		this.qtitle = qtitle;
		this.optionA = optionA;
		this.optionB = optionB;
		this.optionC = optionC;
		this.optionD = optionD;
		this.answer = answer;
		this.did = did;
		this.qutil = qutil;
		this.pid = pid;
	}

	public Integer getQid() {
		return this.qid;
	}

	public void setQid(Integer qid) {
		this.qid = qid;
	}

	public Integer getQtype() {
		return this.qtype;
	}

	public void setQtype(Integer qtype) {
		this.qtype = qtype;
	}

	public String getQtitle() {
		return this.qtitle;
	}

	public void setQtitle(String qtitle) {
		this.qtitle = qtitle;
	}

	public String getOptionA() {
		return this.optionA;
	}

	public void setOptionA(String optionA) {
		this.optionA = optionA;
	}

	public String getOptionB() {
		return this.optionB;
	}

	public void setOptionB(String optionB) {
		this.optionB = optionB;
	}

	public String getOptionC() {
		return this.optionC;
	}

	public void setOptionC(String optionC) {
		this.optionC = optionC;
	}

	public String getOptionD() {
		return this.optionD;
	}

	public void setOptionD(String optionD) {
		this.optionD = optionD;
	}

	public String getAnswer() {
		return this.answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public Integer getDid() {
		return this.did;
	}

	public void setDid(Integer did) {
		this.did = did;
	}

	public String getQutil() {
		return this.qutil;
	}

	public void setQutil(String qutil) {
		this.qutil = qutil;
	}

	public Integer getPid() {
		return this.pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public QType getType() {
		return type;
	}

	public void setType(QType type) {
		this.type = type;
	}

	public Diffcult getDiffcult() {
		return diffcult;
	}

	public void setDiffcult(Diffcult diffcult) {
		this.diffcult = diffcult;
	}

	public Professional getProfessional() {
		return professional;
	}

	public void setProfessional(Professional professional) {
		this.professional = professional;
	}

}