package com.test.bean;

public class Score implements java.io.Serializable {
	
	private Integer scid;
	private Integer examid;
	private Integer sid;
	private String sname;
	private String startTime;
	private String endTime;
	private String anwser;
	private Integer tatalScore;

	private Exam exam ;

	public Score() {
	}

	public Score(Integer scid) {
		this.scid = scid;
	}

	public Score(Integer scid, Integer examid, Integer sid, String sname,
			String startTime, String endTime, String anwser, Integer tatalScore) {
		this.scid = scid;
		this.examid = examid;
		this.sid = sid;
		this.sname = sname;
		this.startTime = startTime;
		this.endTime = endTime;
		this.anwser = anwser;
		this.tatalScore = tatalScore;
	}

	public Integer getScid() {
		return this.scid;
	}

	public void setScid(Integer scid) {
		this.scid = scid;
	}

	public Integer getExamid() {
		return this.examid;
	}

	public void setExamid(Integer examid) {
		this.examid = examid;
	}

	public Integer getSid() {
		return this.sid;
	}

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	public String getSname() {
		return this.sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getStartTime() {
		return this.startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return this.endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getAnwser() {
		return this.anwser;
	}

	public void setAnwser(String anwser) {
		this.anwser = anwser;
	}

	public Integer getTatalScore() {
		return this.tatalScore;
	}

	public void setTatalScore(Integer tatalScore) {
		this.tatalScore = tatalScore;
	}

	public Exam getExam() {
		return exam;
	}

	public void setExam(Exam exam) {
		this.exam = exam;
	}

	
	
}