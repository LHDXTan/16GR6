package com.test.bean;

public class Teacher implements java.io.Serializable {

	private Integer tid;
	private String tno;
	private String tname;
	private String tpwd;
	private String tsex;
	private String tbirthday;
	private String tstudy;
	private String tphone;
	private String tjob;
	private String tmiaoshu;
	private Integer rid;

	
	private Roles role ;

	public Teacher() {
	}

	public Teacher(Integer tid) {
		this.tid = tid;
	}

	public Teacher(Integer tid, String tno, String tname, String tpwd,
			String tsex, String tbirthday, String tstudy, String tphone,
			String tjob, String tmiaoshu, Integer rid) {
		this.tid = tid;
		this.tno = tno;
		this.tname = tname;
		this.tpwd = tpwd;
		this.tsex = tsex;
		this.tbirthday = tbirthday;
		this.tstudy = tstudy;
		this.tphone = tphone;
		this.tjob = tjob;
		this.tmiaoshu = tmiaoshu;
		this.rid = rid;
	}

	public Integer getTid() {
		return this.tid;
	}

	public void setTid(Integer tid) {
		this.tid = tid;
	}

	public String getTno() {
		return this.tno;
	}

	public void setTno(String tno) {
		this.tno = tno;
	}

	public String getTname() {
		return this.tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	public String getTpwd() {
		return this.tpwd;
	}

	public void setTpwd(String tpwd) {
		this.tpwd = tpwd;
	}

	public String getTsex() {
		return this.tsex;
	}

	public void setTsex(String tsex) {
		this.tsex = tsex;
	}

	public String getTbirthday() {
		return this.tbirthday;
	}

	public void setTbirthday(String tbirthday) {
		this.tbirthday = tbirthday;
	}

	public String getTstudy() {
		return this.tstudy;
	}

	public void setTstudy(String tstudy) {
		this.tstudy = tstudy;
	}

	public String getTphone() {
		return this.tphone;
	}

	public void setTphone(String tphone) {
		this.tphone = tphone;
	}

	public String getTjob() {
		return this.tjob;
	}

	public void setTjob(String tjob) {
		this.tjob = tjob;
	}

	public String getTmiaoshu() {
		return this.tmiaoshu;
	}

	public void setTmiaoshu(String tmiaoshu) {
		this.tmiaoshu = tmiaoshu;
	}

	public Integer getRid() {
		return this.rid;
	}

	public void setRid(Integer rid) {
		this.rid = rid;
	}

	public Roles getRole() {
		return role;
	}

	public void setRole(Roles role) {
		this.role = role;
	}
	
	
	

}