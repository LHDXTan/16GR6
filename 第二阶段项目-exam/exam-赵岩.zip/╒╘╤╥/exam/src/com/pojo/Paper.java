package com.pojo;

import java.util.HashSet;
import java.util.Set;

/**
 * Paper entity. @author MyEclipse Persistence Tools
 */

public class Paper implements java.io.Serializable {

	// Fields
	//试卷表
	private Integer pid;		//主键
	private String ptype;		//试题类别，笔试或者机试
	private String suname;		//科目名称
	private String ptitle;		//标题
	private Double ptotal;		//总分
	private Integer ptime;		//考试时长
	private Integer ptotalNum;	//题数
	private Integer pone;		//每题分数
	private Integer pstate;		//状态	
	private String classname;	//考试班级
	private String examtime;	//开始时间
	
	private Set<Question> question = new HashSet();
	

	// Constructors

	public Set<Question> getQuestion() {
		return question;
	}

	public void setQuestion(Set<Question> question) {
		this.question = question;
	}

	/** default constructor */
	public Paper() {
	}

	/** full constructor */
	public Paper(Integer pid, String ptype, String suname, String ptitle,
			Double ptotal, Integer ptime, Integer ptotalNum, Integer pone) {
		this.pid = pid;
		this.ptype = ptype;
		this.suname = suname;
		this.ptitle = ptitle;
		this.ptotal = ptotal;
		this.ptime = ptime;
		this.ptotalNum = ptotalNum;
		this.pone = pone;
	}

	// Property accessors

	public Integer getPid() {
		return this.pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public String getPtype() {
		return this.ptype;
	}

	public void setPtype(String ptype) {
		this.ptype = ptype;
	}

	public String getSuname() {
		return this.suname;
	}

	public void setSuname(String suname) {
		this.suname = suname;
	}

	public String getPtitle() {
		return this.ptitle;
	}

	public void setPtitle(String ptitle) {
		this.ptitle = ptitle;
	}

	public Double getPtotal() {
		return this.ptotal;
	}

	public void setPtotal(Double ptotal) {
		this.ptotal = ptotal;
	}

	public Integer getPtime() {
		return this.ptime;
	}

	public void setPtime(Integer ptime) {
		this.ptime = ptime;
	}

	public Integer getPtotalNum() {
		return this.ptotalNum;
	}

	public void setPtotalNum(Integer ptotalNum) {
		this.ptotalNum = ptotalNum;
	}

	public Integer getPone() {
		return this.pone;
	}

	public void setPone(Integer pone) {
		this.pone = pone;
	}

	public Integer getPstate() {
		return pstate;
	}

	public void setPstate(Integer pstate) {
		this.pstate = pstate;
	}

	public String getExamtime() {
		return examtime;
	}

	public void setExamtime(String examtime) {
		this.examtime = examtime;
	}

	public String getClassname() {
		return classname;
	}

	public void setClassname(String classname) {
		this.classname = classname;
	}


}