package com.action;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.daoimpl.BaseDaoImpl;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.pojo.Adminuser;
import com.pojo.Student;

public class LoginAction extends ActionSupport {
	private String nam;
	private String pwd;
	private int role;
	HttpServletRequest request = ServletActionContext.getRequest();
	BaseDaoImpl base = new BaseDaoImpl();
	
	//退出系统
	public String logout(){
		request.getSession().invalidate();
		return "out";
	}
	
	public String userLogin(){
		//HttpServletRequest request = ServletActionContext.getRequest();
		if(!"".equals(nam) && !"".equals(pwd)){
			List list = base.login(nam, pwd, role);
			if(list.size()==0){
				request.setAttribute("error", "账号或密码错误");
				return "error";
			} else {
				request.getSession().setAttribute("role", role);
					
				return "success";
			}
		}
		return null;
	}
	/**
	 * @return the nam
	 */
	public String getNam() {
		return nam;
	}
	/**
	 * @return the pwd
	 */
	public String getPwd() {
		return pwd;
	}
	/**
	 * @return the role
	 */
	public int getRole() {
		return role;
	}
	/**
	 * @param nam the nam to set
	 */
	public void setNam(String nam) {
		this.nam = nam;
	}
	/**
	 * @param pwd the pwd to set
	 */
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	/**
	 * @param role the role to set
	 */
	public void setRole(int role) {
		this.role = role;
	}
}
