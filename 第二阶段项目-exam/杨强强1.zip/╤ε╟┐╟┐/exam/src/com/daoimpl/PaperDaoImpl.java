package com.daoimpl;

import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.beandao.HibernateSessionFactory;
import com.beans.PageBean;
import com.beans.RandomPaper;
import com.dao.PaperDao;
import com.pojo.Paper;
import com.pojo.Question;
import com.pojo.Subject;

public class PaperDaoImpl implements PaperDao {
	HttpServletRequest request = ServletActionContext.getRequest();
	HttpServletResponse response = ServletActionContext.getResponse();
	
	//把页面获取到的题号存入List
	public List choicePaper(String[] box){
		List alllist = new ArrayList();		
		List list = new ArrayList();
		if(box!=null && box.length!=0){
			if(request.getSession().getAttribute("addChoicePaperQid")!=null){
				alllist= (List) request.getSession().getAttribute("addChoicePaperQid");
				list = alllist;
				for(int i=0;i<box.length;i++){
					int xm = 0;
					for(int j=0;j<alllist.size();j++){		
						if(Integer.parseInt(alllist.get(j).toString())!=Integer.parseInt(box[i].toString())){
							xm+=1;
						}
						if(xm==alllist.size()){
							list.add(box[i]);
						}	
					}				
				}
				request.getSession().setAttribute("addChoicePaperQid", list);
			} else {
				for(int i=0;i<box.length;i++){
					alllist.add(box[i]);
				}
				request.getSession().setAttribute("addChoicePaperQid", alllist);
			}		
		} else {
			if(request.getSession().getAttribute("addChoicePaperQid")!=null){
				alllist= (List) request.getSession().getAttribute("addChoicePaperQid");
			}
		}
		return alllist;
	}
	
	//判断日期
    public int compare_date(String DATE1, String DATE2) {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        int flag = 0;
        try {
            Date dt1 = df.parse(DATE1);
            Date dt2 = df.parse(DATE2);
            if (dt1.getTime() > dt2.getTime()) {
                System.out.println("dt1 在dt2前");
                flag = 1;
                System.out.println(flag);
            } else if (dt1.getTime() < dt2.getTime()) {
                System.out.println("dt1在dt2后");
                flag = 2;
                System.out.println(flag);
            } else {
                flag = 3;
                System.out.println(flag);
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return flag;
    }
	
	//条件查询试卷
	public PageBean selectPaper(RandomPaper ran,int p){
		String hql="from Paper where suname='"+ran.getKemu()+"' ";
		String sql="select count(*) nub from paper where suname='"+ran.getKemu()+"' ";
		if(ran!=null){
			if(ran.getType()==1){
				hql = hql+" and ptype = '笔试题'";
				sql = sql+" and ptype = '笔试题'";
			} else if(ran.getType()==2) {
				hql = hql+" and ptype = '机试题'";
				sql = sql+" and ptype = '机试题'";
			}
			if(ran.getState()!=0){
				hql = hql+" and pstate = "+ran.getState();
				sql = sql+" and pstate = "+ran.getState();
			}
		}
		int cnt = 0;
		if(p!=0)cnt = (p-1)*10;
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		List result =new ArrayList();
		PageBean pb = new PageBean();
		try{
			List list = session.createSQLQuery(sql).list();
			pb.setCount(Integer.parseInt(list.get(0).toString()));
			pb.setP(p);
		    Query q = session.createQuery(hql);
		    q.setFirstResult(cnt);//设置起始行
			q.setMaxResults(10);//每页条数
			result = q.list(); //得到每页的数据
			pb.setPaperlist(result);
		    tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();	
		}
		HibernateSessionFactory.closeSession();
		return pb;
	}
	
	//试卷分页
	public PageBean getAllPaper(int p) {
		String hql="from Paper";
		String sql="select count(*) nub from paper";
		int cnt = 0;
		if(p!=0)cnt = (p-1)*10;
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		List result =new ArrayList();
		PageBean pb = new PageBean();
		try{
			List list = session.createSQLQuery(sql).list();
			pb.setCount(Integer.parseInt(list.get(0).toString()));
			pb.setP(p);
		    Query q = session.createQuery(hql);
		    q.setFirstResult(cnt);//设置起始行
			q.setMaxResults(10);//每页条数
			result = q.list(); //得到每页的数据
			pb.setPaperlist(result);
		    tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();	
		}
		HibernateSessionFactory.closeSession();
		return pb;
	}
	
	//拼装json（选题组卷）
	public JSONArray choicePaperJson(List<Question> questionlist){
		JSONArray json = new JSONArray();
		int i=1;
		 for(Question que : questionlist){
	            JSONObject jo = new JSONObject();
	            jo.put("qid", que.getQid());
	            jo.put("nub", i);
	            jo.put("type", que.getType());
	            jo.put("hard", que.getHard());
	            jo.put("charpter", que.getCharpter());
	            jo.put("content", que.getContent());
	            json.add(jo);
	            i++;
	        }
		return json;
	}


	//获取全部笔试题
	public PageBean getAllPentQuestion(int suid,int p) {
		String hql="";
		String sql="";
		if(suid==0){
			hql = "from Question where qtype = '笔试题'";
			sql = "select count(*) nub from Question where qtype = '笔试题'";
		} else {
			hql = "from Question where suid ="+suid+" and qtype = '笔试题'";
			sql = "select count(*) nub from Question where suid ="+suid+" and qtype = '笔试题'";
		}
		int cnt = 0;
		if(p!=0)cnt = (p-1)*10;
		Session session = HibernateSessionFactory.getSession();
		Transaction tx=session.beginTransaction();
		List result =new ArrayList();
		PageBean pb = new PageBean();
		try{
			List list = session.createSQLQuery(sql).list();
			pb.setCount(Integer.parseInt(list.get(0).toString()));
			pb.setP(p);
		    Query q = session.createQuery(hql);
		    q.setFirstResult(cnt);//设置起始行
			q.setMaxResults(10);//每页条数
			result = q.list(); //得到每页的数据
			pb.setQuestionlist(result);
		    tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();	
		}
		HibernateSessionFactory.closeSession();
		return pb;
	}
	
	/*
	 * 随机获取List里的题
	 * alllist存放的是所有难度的题
	 * */
	public List getRandomListQuestion(List alllist,RandomPaper rp){
		List allnublist = new ArrayList();
		List nublist = new ArrayList();
		List list = new ArrayList();
		int nub = 0;
		if(alllist.size()!=0 && alllist!=null){
			//单选简单难度
			list = (List)alllist.get(0);
			//调用本类方法a();把简单难度的题list和题数传递过去
			nublist = this.a(list, rp.getOeasy());
			allnublist.add(nublist);
			//单选中等难度
			list = (List)alllist.get(1);
			nublist = this.a(list, rp.getOnormal());
			allnublist.add(nublist);
			//单选困难难度
			list = (List)alllist.get(2);
			nublist = this.a(list, rp.getOhard());
			allnublist.add(nublist);
			//双选简单难度
			list = (List)alllist.get(3);
			nublist = this.a(list, rp.getTeasy());
			allnublist.add(nublist);
			//双选中等难度
			list = (List)alllist.get(4);
			nublist = this.a(list, rp.getTnormal());
			allnublist.add(nublist);
			//双选困难难度
			list = (List)alllist.get(5);
			nublist = this.a(list, rp.getThard());
			allnublist.add(nublist);
		}
		return allnublist;
	}
	
	/*
	 * 题库list,题数nub
	 * */
	public List a(List list,int nub){
		int i = 0;
		List nublist = new ArrayList();
		if(list.size()!=0 && list!=null){
			//题库List的长度，用来规定随机数的范围
			i = list.size();
			//调用本类方法，得到随机获取的题目，返回nublist
			nublist = this.getNublist(i, list, nub);
		}
		return nublist;
	}
	
	/*
	 * 随机数范围0~i,这个难度的所有题list,题数nub，
	 * 返回nublist
	 * */
	public List getNublist(int i,List list,int nub){
		List nublist = new ArrayList();
		int rand = 0;
		/*
		 * 循环nub次
		 * */
		for(int j=0; j<nub;j++){
			//获取随机数rand（范围0~i）
			rand = new Random().nextInt(i);
			//将下标为rand的数值，存放入nublist里
			nublist.add(list.get(rand));
			//再删除掉下标为rand的值
			list.remove(rand);
			//list中少一个题，随机数范围缩小1位   范围0~(i-1)
			i = i-1;
		}
		return nublist;
	}

}
