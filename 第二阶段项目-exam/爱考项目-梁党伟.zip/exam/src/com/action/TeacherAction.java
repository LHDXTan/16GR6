package com.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;


import com.daoimpl.BaseDaoImpl;
import com.opensymphony.xwork2.Action;
import com.pojo.Teacher;

public class TeacherAction implements Action {
	
	private Teacher teacher;
	private List<Teacher> teacherlist;
	private String zhanghao;
	private String name;
	private String gangwei;
	
	BaseDaoImpl bdi = new BaseDaoImpl();
	
	HttpServletRequest request = ServletActionContext.getRequest();
	HttpServletResponse response = ServletActionContext.getResponse();

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	//教师列表
	public String teacherxs(){
		
		teacherlist =bdi.getObjects("from Teacher");
		
		return "teacherxs";
	}
	//去教师添加页面
	public String toAdd(){
		if(teacher.getTid()!=null){
			teacher = (Teacher)bdi.getObjectById(Teacher.class, teacher.getTid());
			
		}
		
		return "addteacher";
	}
	//添加教师
	public String addteacher() throws IOException{
		int flag = 0;
		PrintWriter out = ServletActionContext.getResponse().getWriter();
		teacher.setJid(2);
		flag=bdi.add(teacher);
		out.print(flag);
		return null;
	}
	//去教师修改页面
	public String toUpdate(){
		System.out.println("转教师修改页面");
		teacher =( Teacher) bdi.getObjectById(Teacher.class, teacher.getTid());
		return "updateteacher";
	}
	//修改教师
	public String updateteacher() throws IOException{
		PrintWriter out = ServletActionContext.getResponse().getWriter();
		System.out.println(teacher.getTid());
		Teacher tea =(Teacher)bdi.getObjectById(Teacher.class, teacher.getTid());
		tea.setLoginuser(teacher.getLoginuser());
		tea.setPassword(teacher.getPassword());
		tea.setTname(teacher.getTname());
		tea.setTbirthday(teacher.getTbirthday());
		tea.setTeducation(teacher.getTeducation());
		tea.setTphone(teacher.getTbirthday());
		tea.setTgangwei(teacher.getTgangwei());
		tea.setTsex(teacher.getTsex());
		tea.setTbeizhu(teacher.getTbeizhu());
		int flag=bdi.update(tea);
		if(flag==1){
			out.print(1);
		} else {
			out.print(0);
		}				
		return null;
	}
	//删除教师
	public String deleteteacher() throws IOException{
		System.out.println("删除教师");
		PrintWriter out = ServletActionContext.getResponse().getWriter();
		teacher = (Teacher)bdi.getObjectById(Teacher.class, teacher.getTid());
		System.out.println(teacher.getTid());
		int flag=bdi.delete(teacher);
		out.print(flag);
		return null;
	}
	//重置密码
	public String czmm() throws IOException{
		System.out.println("重置密码");
		PrintWriter out = ServletActionContext.getResponse().getWriter();
		Teacher te = (Teacher)bdi.getObjectById(Teacher.class, teacher.getTid());
		te.setPassword("123456");
		int flag=bdi.update(te);
		if(flag==1){
			out.print(1);
		} else {
			out.print(0);
		}	
		
		return null;
	} 
	
	//条件查询教师
	public String tjfond(){
		System.out.println("进入条件查询");
		teacherlist=bdi.teacherfenye(zhanghao, name, gangwei);

		return "teacherxs";
		
	}

	public Teacher getTeacher() {
		return teacher;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}

	public List<Teacher> getTeacherlist() {
		return teacherlist;
	}

	public void setTeacherlist(List<Teacher> teacherlist) {
		this.teacherlist = teacherlist;
	}

	public String getZhanghao() {
		return zhanghao;
	}

	public void setZhanghao(String zhanghao) {
		this.zhanghao = zhanghao;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGangwei() {
		return gangwei;
	}

	public void setGangwei(String gangwei) {
		this.gangwei = gangwei;
	}
	
	

}
