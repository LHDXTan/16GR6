package com.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.daoimpl.BaseDaoImpl;
import com.opensymphony.xwork2.Action;
import com.pojo.Student;
import com.pojo.Teacher;


public class StudentAction implements Action {
	private Student s;
	private List<Student> studentlist;
	private int c;
	
	BaseDaoImpl bdi = new BaseDaoImpl();
	
	HttpServletRequest request = ServletActionContext.getRequest();
	HttpServletResponse response = ServletActionContext.getResponse();
	
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	//显示所有学生
	public String list(){
	
		studentlist=bdi.getObjects("from Student");
		return "tolist";
	}
	//去学生添加页面
	public String toAdd(){
		if(s.getSid()!=null){
			s = (Student)bdi.getObjectById(Student.class, s.getSid());
			
		}
		
		return "addstudent";
		
	}
	//添加学生
	public String addstudent() throws IOException{
		int flag = 0;
		System.out.println(s.getSclass());
		PrintWriter out = ServletActionContext.getResponse().getWriter();
		System.out.println(c);
		s.setSclass(c);
		s.setJid(1);
		flag=bdi.add(s);
		out.print(flag);
		return null;
	}
	
	//去学生修改页面
	public String toUpdate(){
		System.out.println("转教师修改页面");
		s = (Student)bdi.getObjectById(Student.class, s.getSid());
		return "updatestudent";
	}
	
	//修改试题
	public String updatestudent() throws IOException{
		PrintWriter out = ServletActionContext.getResponse().getWriter();
		System.out.println(s.getSid());
		Student st =(Student)bdi.getObjectById(Student.class, s.getSid());
		st.setLoginuser(s.getLoginuser());
		st.setPassword(s.getPassword());
		st.setSname(s.getSname());
		st.setSbirthday(s.getSbirthday());
		st.setSphone(s.getSphone());
		st.setSsex(s.getSsex());
		st.setSyear(s.getSyear());
		st.setSclass(s.getSclass());
		st.setSidcard(s.getSidcard());
		int flag=bdi.update(st);
		if(flag==1){
			out.print(1);
		} else {
			out.print(0);
		}		
		return null;
	}
	
	
	public Student getS() {
		return s;
	}

	public void setS(Student s) {
		this.s = s;
	}

	public List<Student> getStudentlist() {
		return studentlist;
	}

	public void setStudentlist(List<Student> studentlist) {
		this.studentlist = studentlist;
	}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}
	


	
	

}
