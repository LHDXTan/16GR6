package com.test.bean;

public class Exam implements java.io.Serializable {

	private Integer examid;
	private String etitle;
	private Integer etype;
	private String shiti;
	private Integer score;
	private Integer number;
	private Integer totalscore;
	private Integer estatus;
	private String etime;		
	private String estartime ;  
	private Integer jid;
	private Integer fid;
	private String gid;
	private Integer pid;
	

	public Exam() {
	}

	public Exam(Integer examid) {
		this.examid = examid;
	}

	public Integer getExamid() {
		return this.examid;
	}

	public void setExamid(Integer examid) {
		this.examid = examid;
	}

	public String getEtitle() {
		return this.etitle;
	}

	public void setEtitle(String etitle) {
		this.etitle = etitle;
	}

	public Integer getEtype() {
		return this.etype;
	}

	public void setEtype(Integer etype) {
		this.etype = etype;
	}

	public String getShiti() {
		return this.shiti;
	}

	public void setShiti(String shiti) {
		this.shiti = shiti;
	}

	public Integer getScore() {
		return this.score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}

	public Integer getNumber() {
		return this.number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

	public Integer getTotalscore() {
		return this.totalscore;
	}

	public void setTotalscore(Integer totalscore) {
		this.totalscore = totalscore;
	}

	public Integer getEstatus() {
		return this.estatus;
	}

	public void setEstatus(Integer estatus) {
		this.estatus = estatus;
	}

	public String getEtime() {
		return this.etime;
	}

	public void setEtime(String etime) {
		this.etime = etime;
	}

	public Integer getJid() {
		return this.jid;
	}

	public void setJid(Integer jid) {
		this.jid = jid;
	}

	public Integer getFid() {
		return this.fid;
	}

	public void setFid(Integer fid) {
		this.fid = fid;
	}
	public String getGid() {
		return gid;
	}

	public void setGid(String gid) {
		this.gid = gid;
	}

	public Integer getPid() {
		return this.pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public String getEstartime() {
		return estartime;
	}

	public void setEstartime(String estartime) {
		this.estartime = estartime;
	}

	
	

}