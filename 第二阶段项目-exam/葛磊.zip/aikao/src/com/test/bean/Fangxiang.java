package com.test.bean;

public class Fangxiang implements java.io.Serializable {

	private Integer fid;
	private String fname;

	public Fangxiang() {
	}

	public Fangxiang(Integer fid) {
		this.fid = fid;
	}

	public Fangxiang(Integer fid, String fname) {
		this.fid = fid;
		this.fname = fname;
	}

	public Integer getFid() {
		return this.fid;
	}

	public void setFid(Integer fid) {
		this.fid = fid;
	}

	public String getFname() {
		return this.fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

}