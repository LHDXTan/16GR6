package com.test.bean;

public class Grade  implements java.io.Serializable {

     private Integer gid;
     private String gno;
     private String gname;
     private Integer fid;
     private Integer gbid;
     private Integer gjid;
     private String gtime;
     private Integer gnum1;
     private Integer gnum2;
     private Integer gnum3;
     private Integer gstate;
     private String gmiaoshu;

     private Teacher daoshi ;
     private Teacher jiangshi ;
     private Fangxiang fangxiang ;
     

    public Grade() {
    }

    public Grade(Integer gid) {
        this.gid = gid;
    }

    public Grade(Integer gid, String gno, String gname, Integer fid, Integer gbid, Integer gjid, String gtime, Integer gnum1, Integer gnum2, Integer gnum3, Integer gstate, String gmiaoshu) {
        this.gid = gid;
        this.gno = gno;
        this.gname = gname;
        this.fid = fid;
        this.gbid = gbid;
        this.gjid = gjid;
        this.gtime = gtime;
        this.gnum1 = gnum1;
        this.gnum2 = gnum2;
        this.gnum3 = gnum3;
        this.gstate = gstate;
        this.gmiaoshu = gmiaoshu;
    }

    public Integer getGid() {
        return this.gid;
    }
    
    public void setGid(Integer gid) {
        this.gid = gid;
    }

    public String getGno() {
        return this.gno;
    }
    
    public void setGno(String gno) {
        this.gno = gno;
    }

    public String getGname() {
        return this.gname;
    }
    
    public void setGname(String gname) {
        this.gname = gname;
    }

    public Integer getFid() {
        return this.fid;
    }
    
    public void setFid(Integer fid) {
        this.fid = fid;
    }

    public Integer getGbid() {
        return this.gbid;
    }
    
    public void setGbid(Integer gbid) {
        this.gbid = gbid;
    }

    public Integer getGjid() {
        return this.gjid;
    }
    
    public void setGjid(Integer gjid) {
        this.gjid = gjid;
    }

    public String getGtime() {
        return this.gtime;
    }
    
    public void setGtime(String gtime) {
        this.gtime = gtime;
    }

    public Integer getGnum1() {
        return this.gnum1;
    }
    
    public void setGnum1(Integer gnum1) {
        this.gnum1 = gnum1;
    }

    public Integer getGnum2() {
        return this.gnum2;
    }
    
    public void setGnum2(Integer gnum2) {
        this.gnum2 = gnum2;
    }

    public Integer getGnum3() {
        return this.gnum3;
    }
    
    public void setGnum3(Integer gnum3) {
        this.gnum3 = gnum3;
    }

    public Integer getGstate() {
        return this.gstate;
    }
    
    public void setGstate(Integer gstate) {
        this.gstate = gstate;
    }

    public String getGmiaoshu() {
        return this.gmiaoshu;
    }
    
    public void setGmiaoshu(String gmiaoshu) {
        this.gmiaoshu = gmiaoshu;
    }

	public Teacher getDaoshi() {
		return daoshi;
	}

	public void setDaoshi(Teacher daoshi) {
		this.daoshi = daoshi;
	}

	public Teacher getJiangshi() {
		return jiangshi;
	}

	public void setJiangshi(Teacher jiangshi) {
		this.jiangshi = jiangshi;
	}

	public Fangxiang getFangxiang() {
		return fangxiang;
	}

	public void setFangxiang(Fangxiang fangxiang) {
		this.fangxiang = fangxiang;
	}
   
    







}