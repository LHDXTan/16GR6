package com.test.bean;

public class Professional implements java.io.Serializable {

	private Integer pid;
	private String pname;
	private Integer fid;
	private Integer jid;
	
	
	
	private Fangxiang fangxiang ;
	private Jieduan jieduan ;

	public Professional() {
	}

	public Professional(Integer pid) {
		this.pid = pid;
	}

	public Professional(Integer pid, String pname, Integer fid, Integer jid) {
		this.pid = pid;
		this.pname = pname;
		this.fid = fid;
		this.jid = jid;
	}

	public Integer getPid() {
		return this.pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public String getPname() {
		return this.pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public Integer getFid() {
		return this.fid;
	}

	public void setFid(Integer fid) {
		this.fid = fid;
	}

	public Integer getJid() {
		return this.jid;
	}

	public void setJid(Integer jid) {
		this.jid = jid;
	}

	public Fangxiang getFangxiang() {
		return fangxiang;
	}

	public void setFangxiang(Fangxiang fangxiang) {
		this.fangxiang = fangxiang;
	}

	public Jieduan getJieduan() {
		return jieduan;
	}

	public void setJieduan(Jieduan jieduan) {
		this.jieduan = jieduan;
	}

}