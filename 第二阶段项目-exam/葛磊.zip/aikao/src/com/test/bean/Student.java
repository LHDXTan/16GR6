package com.test.bean;

public class Student implements java.io.Serializable {

	private Integer sid;
	private String sno;
	private String sname;
	private String spwd;
	private String ssex;
	private String syear;
	private Integer gid;
	private String sbirthday;
	private String scard;
	private String szzmm;
	private String sprovice;
	private String scity;
	private String spro;
	private Integer fid;
	private Integer rid;

	
	private Roles role ;
	private Grade grade ;

	public Student() {
	}

	public Student(Integer sid) {
		this.sid = sid;
	}

	public Student(Integer sid, String sno, String sname, String spwd,
			String ssex, String syear, Integer gid, String sbirthday,
			String scard, String szzmm, String sprovice, String scity,
			String spro, Integer fid, Integer rid) {
		this.sid = sid;
		this.sno = sno;
		this.sname = sname;
		this.spwd = spwd;
		this.ssex = ssex;
		this.syear = syear;
		this.gid = gid;
		this.sbirthday = sbirthday;
		this.scard = scard;
		this.szzmm = szzmm;
		this.sprovice = sprovice;
		this.scity = scity;
		this.spro = spro;
		this.fid = fid;
		this.rid = rid;
	}

	public Integer getSid() {
		return this.sid;
	}

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	public String getSno() {
		return this.sno;
	}

	public void setSno(String sno) {
		this.sno = sno;
	}

	public String getSname() {
		return this.sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getSpwd() {
		return this.spwd;
	}

	public void setSpwd(String spwd) {
		this.spwd = spwd;
	}

	public String getSsex() {
		return this.ssex;
	}

	public void setSsex(String ssex) {
		this.ssex = ssex;
	}

	public String getSyear() {
		return this.syear;
	}

	public void setSyear(String syear) {
		this.syear = syear;
	}

	public Integer getGid() {
		return this.gid;
	}

	public void setGid(Integer gid) {
		this.gid = gid;
	}

	public String getSbirthday() {
		return this.sbirthday;
	}

	public void setSbirthday(String sbirthday) {
		this.sbirthday = sbirthday;
	}

	public String getScard() {
		return this.scard;
	}

	public void setScard(String scard) {
		this.scard = scard;
	}

	public String getSzzmm() {
		return this.szzmm;
	}

	public void setSzzmm(String szzmm) {
		this.szzmm = szzmm;
	}

	public String getSprovice() {
		return this.sprovice;
	}

	public void setSprovice(String sprovice) {
		this.sprovice = sprovice;
	}

	public String getScity() {
		return this.scity;
	}

	public void setScity(String scity) {
		this.scity = scity;
	}

	public String getSpro() {
		return this.spro;
	}

	public void setSpro(String spro) {
		this.spro = spro;
	}

	public Integer getFid() {
		return this.fid;
	}

	public void setFid(Integer fid) {
		this.fid = fid;
	}

	public Integer getRid() {
		return this.rid;
	}

	public void setRid(Integer rid) {
		this.rid = rid;
	}

	public Roles getRole() {
		return role;
	}

	public void setRole(Roles role) {
		this.role = role;
	}

	public Grade getGrade() {
		return grade;
	}

	public void setGrade(Grade grade) {
		this.grade = grade;
	}
	
	
	

}