package com.test.service;

import java.util.List;

import com.test.bean.Exam;
import com.test.bean.Student;
import com.test.dao.ExamDaoImpl;
import com.test.dao.IExamDao;
import com.test.vo.ExamScoreInfo;
import com.test.vo.PageBean;


public class ExamServiceImpl implements IExamService {

	IExamDao examdao = new ExamDaoImpl();
	
	public PageBean getGradeNames(PageBean pagebean) {
		return examdao.getGradeNames(pagebean);
	}

	public List examshitiList(Exam exam) {
		return examdao.examshitiList(exam);
	}

	@Override
	public List getmyScoreInfo(int scid) {
		return examdao.getmyScoreInfo(scid);
	}

	@Override
	public ExamScoreInfo getExamScore(int examid,Student student) {
		return examdao.getExamScore(examid,student);
	}

	
	
	
}
