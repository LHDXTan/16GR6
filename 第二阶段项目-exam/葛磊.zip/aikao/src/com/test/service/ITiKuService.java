package com.test.service;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;

public interface ITiKuService {

	
	public List getProfessionalList(DetachedCriteria dc);
	
	
}
