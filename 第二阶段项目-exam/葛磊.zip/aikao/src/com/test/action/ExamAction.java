package com.test.action;

import java.util.List;
import java.util.Random;

import org.apache.struts2.ServletActionContext;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;

import com.opensymphony.xwork2.ActionSupport;
import com.test.bean.Exam;
import com.test.bean.Fangxiang;
import com.test.bean.Grade;
import com.test.bean.Jieduan;
import com.test.bean.Professional;
import com.test.bean.Question;
import com.test.bean.Score;
import com.test.bean.Student;
import com.test.dao.ExamDaoImpl;
import com.test.dao.IExamDao;
import com.test.service.CommonServiceImpl;
import com.test.service.ExamServiceImpl;
import com.test.service.ICommonService;
import com.test.service.IExamService;
import com.test.vo.ExamScoreInfo;
import com.test.vo.ExamVo;
import com.test.vo.PageBean;


public class ExamAction extends ActionSupport {

	private ICommonService commonService = new CommonServiceImpl();
	private IExamService examService = new ExamServiceImpl();
	private PageBean exampagebean ;
	private PageBean updateQuestionbean ;
	private List fangxianglist ;
	private List jieduanlist ;
	private List professionallist ;
	private List shitiList ;
	private List allQuestion ;
	private Question question ;
	private int p ;
	private int qid ;
	private Exam exam ;
	private ExamVo examVo ;
	private String[] easy ;		
	private String[] normal ;	
	private String[] hard ;		
	private String[] checkedQid; 
	private String shiti ;		
	private String cmd ;		
	private String[] gradeId ;	
	private String[] examDate ;
	private Student student;
	

	public String examIndex(){
		
		setlistinfo();
		DetachedCriteria dcexam = DetachedCriteria.forClass(Exam.class);
		if(exam!=null){
			if(exam.getFid()!=0){
				dcexam.add(Restrictions.eq("fid", exam.getFid()));
			}
			if(exam.getJid()!=0){
				dcexam.add(Restrictions.eq("jid", exam.getJid()));
			}
			if(exam.getPid()!=0){
				dcexam.add(Restrictions.eq("pid", exam.getPid()));
			}
			if(exam.getEtype()!=0){
				dcexam.add(Restrictions.eq("etype", exam.getEtype()));
			}
			if(exam.getEstatus()!=0){
				dcexam.add(Restrictions.eq("estatus", exam.getEstatus()));
			}
		}
		exampagebean = commonService.queryPageInfo(p, dcexam,4);
		exampagebean = examService.getGradeNames(exampagebean);
		return "index";
	}
	

	public String getallFinishExam(){
		
		setlistinfo();
		DetachedCriteria dcexam = DetachedCriteria.forClass(Exam.class);
		dcexam.add(Restrictions.eq("estatus", 3));
		if(exam!=null){
			if(exam.getFid()!=0){
				dcexam.add(Restrictions.eq("fid", exam.getFid()));
			}
			if(exam.getJid()!=0){
				dcexam.add(Restrictions.eq("jid", exam.getJid()));
			}
			if(exam.getPid()!=0){
				dcexam.add(Restrictions.eq("pid", exam.getPid()));
			}
			if(exam.getEtype()!=0){
				dcexam.add(Restrictions.eq("etype", exam.getEtype()));
			}
		}
		exampagebean = commonService.queryPageInfo(p, dcexam,4);
		exampagebean = examService.getGradeNames(exampagebean);
		return "allFinishExam";
	}

	
	

	public String lookStudentInfo(){
		
		if(exam!=null && exam.getExamid()!=0){
			List gradeList = commonService.getObjectList(DetachedCriteria.forClass(Grade.class));
			ServletActionContext.getRequest().getSession().setAttribute("gradeList", gradeList);
			ExamScoreInfo examscoreinfo = examService.getExamScore(exam.getExamid(),student);
			ServletActionContext.getRequest().getSession().setAttribute("examscoreinfo", examscoreinfo);
		}
		return "examScoreList";
	}
	
	

	public String deleteExam(){
		
		if(exam!=null&&exam.getExamid()!=0){
			exam = (Exam) commonService.getobObjectById(Exam.class, exam.getExamid());
			commonService.deleteObject(exam);
		}
		exam = null ;
		return examIndex();
	}
	
	
	public String lookExamInfo(){
		
		if(exam!=null&&exam.getExamid()!=0){
			exam = (Exam) commonService.getobObjectById(Exam.class, exam.getExamid());
			ServletActionContext.getRequest().getSession().setAttribute("exam", exam);
			shitiList = examService.examshitiList(exam);
		}
		if(cmd!=null && cmd.equals("finishExam")){
			return "finishExaminfo";		
		}
		return "examinfo";
	}

	public String toChangeQuestion(){
		
		if(qid!=0){
			ServletActionContext.getRequest().getSession().setAttribute("qid", qid);
		}
		DetachedCriteria dc = DetachedCriteria.forClass(Question.class);
		if(question!=null){
			if(question.getQtype()!=null&&question.getQtype()!=0){
				dc.add(Restrictions.eq("qtype", question.getQtype()));
			}
			if(question.getDid()!=null&&question.getDid()!=0){
				dc.add(Restrictions.eq("did", question.getDid()));
			}
			if(question.getQtitle()!=null&&!question.getQtitle().equals("")&&!question.getQtitle().equals("0")){
				dc.add(Restrictions.like("qtitle", question.getQtitle(),MatchMode.ANYWHERE));
			}
		}
		updateQuestionbean = commonService.queryPageInfo(p, dc,15);
		return "allQuestion" ;
	}

	public String changeQuestion(){
		
		if(qid!=0){
			Exam e = (Exam) ServletActionContext.getRequest().getSession().getAttribute("exam");
			System.out.println(e.getExamid());
			int before_qid = (Integer) ServletActionContext.getRequest().getSession().getAttribute("qid");
			System.out.println(before_qid);
			if(e.getShiti()!=null&&!e.getShiti().equals("")){
				String[] shiti = e.getShiti().split(",");	
				System.out.println(shiti);
				for(int i = 0;i<shiti.length;i++){
					if(Integer.parseInt(shiti[i]) == before_qid){
						shiti[i] = Integer.toString(qid);
					}
				}
				String new_shiti = "";
				for(int i = 0;i<shiti.length;i++){			
					if(new_shiti.equals("")){
						new_shiti += ""+shiti[i];
					}else{
						new_shiti += ","+shiti[i];
					}
				}
				e.setShiti(new_shiti);
				commonService.updateObject(e);				
			}
		}
		cmd = "closeallQuestion";
		return "allQuestion";
	}
	

	public void setlistinfo(){
		
		DetachedCriteria dcfangxiang = DetachedCriteria.forClass(Fangxiang.class);
		fangxianglist = commonService.getObjectList(dcfangxiang);
		DetachedCriteria dcjieduan = DetachedCriteria.forClass(Jieduan.class);
		jieduanlist = commonService.getObjectList(dcjieduan);
		DetachedCriteria dcprofession = DetachedCriteria.forClass(Professional.class);
		professionallist = commonService.getObjectList(dcprofession);
	}

	/*
	 * 
	 * 
	 * 
	 * */

	public String selectQuestionForExam(){
		String checkShiti = (String) ServletActionContext.getRequest().getSession().getAttribute("checkShiti");
		if(checkShiti != null && !checkShiti.equals("") && checkShiti.equals("yes")){
			ServletActionContext.getRequest().getSession().setAttribute("checkQuestion","");
			ServletActionContext.getRequest().getSession().setAttribute("checkShiti", "no");
		}
		
		if(p<=0){ p = 1 ;}
		int up = 0;
		if(ServletActionContext.getRequest().getSession().getAttribute("up")!=null){
			up = (Integer)ServletActionContext.getRequest().getSession().getAttribute("up");
		}
		if(up!=0){
			p = up ;
		}
		setlistinfo();
		DetachedCriteria dc = DetachedCriteria.forClass(Question.class);
		updateQuestionbean = commonService.queryPageInfo(p, dc,15);
		ServletActionContext.getRequest().getSession().setAttribute("questionbean", updateQuestionbean);
		return "selectQuestionForExam" ;
	}

	public String xuantipage(){
		
		ServletActionContext.getRequest().getSession().setAttribute("up", p);
		DetachedCriteria dc = DetachedCriteria.forClass(Question.class);
		updateQuestionbean = commonService.queryPageInfo(p, dc,15);
		ServletActionContext.getRequest().getSession().setAttribute("questionbean", updateQuestionbean);
		String checkQuestion = (String) ServletActionContext.getRequest().getSession().getAttribute("checkQuestion");
		
		System.out.println("============="+checkQuestion);
		if(checkQuestion==null){
			ServletActionContext.getRequest().getSession().setAttribute("checkQuestion","");
			checkQuestion = "";
		}
		if(checkedQid!=null&&checkedQid.length!=0){
			if(checkQuestion!=null&&!checkQuestion.equals("")){
				for(String s:checkedQid){
					System.out.print(s+"\t");
				}
				
				String[] old_qid = checkQuestion.split(",");
				String is_ok = "";
				for(int i=0;i<checkedQid.length;i++){
					for(int j=0;j<old_qid.length;j++){
						if(checkedQid[i].equals(old_qid[j])){
							is_ok = "no";
						}
					}
					if(!is_ok.equals("no")){
						checkQuestion += ","+checkedQid[i];
						is_ok = "";
					}
				}
			}else{
				for(int i=0;i<checkedQid.length;i++){
					if(checkQuestion.equals("")){
						checkQuestion += checkedQid[i];
					}else{
						checkQuestion += ","+checkedQid[i];
					}
				}
			}
		}
		
		ServletActionContext.getRequest().getSession().setAttribute("checkQuestion",checkQuestion);
		checkQuestion = (String) ServletActionContext.getRequest().getSession().getAttribute("checkQuestion");
		if(checkQuestion!=null&&!checkQuestion.equals("")){
			ServletActionContext.getRequest().getSession().setAttribute("number", checkQuestion.split(",").length);
			cmd = "reload" ;
		}
		return "xuanti";
	}

	public String addExamBySelect(){
		
		String checkQuestion = (String) ServletActionContext.getRequest().getSession().getAttribute("checkQuestion");
		if(checkQuestion!=null&&!checkQuestion.equals("")){
			exam.setShiti(checkQuestion);
			exam.setEtype(2);
			exam.setEstatus(1);
			commonService.addObject(exam);
			p=1;
			exam = null ;
			ServletActionContext.getRequest().getSession().setAttribute("checkShiti", "no");
			cmd = "close";
			return selectQuestionForExam();
		}
		cmd = "noQuestion" ;
		return selectQuestionForExam();
	}
	
	
	/*
	 * 
	 * */

	public String suijiPage(){
		
		setlistinfo();
		return "suijiPage";
	}

	public String suijizujuan(){
		shiti = new String();
		int dan_easy = 0;
		if(easy!=null && !easy[0].equals("")){
			dan_easy = Integer.parseInt(easy[0]);
		}
		
		int dan_normal = 0;
		if(normal!=null&&!normal[0].equals("")){
			dan_normal = Integer.parseInt(normal[0]);
		}
		
		int dan_hard = 0;
		if(hard!=null&&!hard[0].equals("")){
			dan_hard = Integer.parseInt(hard[0]);
		}
		
		setshiti(1,1,dan_easy);		
		setshiti(1,2,dan_normal);
		setshiti(1,3,dan_hard);
		int duo_easy = 0;
		if(easy!=null && !easy[1].equals("")){
			duo_easy = Integer.parseInt(easy[1]);
		}
		
		int duo_normal = 0;
		if(normal!=null && !normal[1].equals("")){
			duo_normal = Integer.parseInt(normal[1]);
		}
		
		int duo_hard = 0;
		if(hard!=null && !hard[1].equals("")){
			duo_hard = Integer.parseInt(hard[1]);
		}
		
		setshiti(2,1,duo_easy);		
		setshiti(2,2,duo_normal);
		setshiti(2,3,duo_hard);
		
		exam.setEtype(2);
		exam.setEstatus(1);
		exam.setShiti(shiti);
		commonService.addObject(exam);		
		
		cmd="close";
		return suijiPage();
	}

	public void setshiti(int qtype,int did,int number){

		DetachedCriteria dc = DetachedCriteria.forClass(Question.class)
				.add(Restrictions.eq("qtype",qtype)).add(Restrictions.eq("did",did)).add(Restrictions.eq("pid", exam.getPid()));
		List questionlist = commonService.getObjectList(dc);
		
		int size = questionlist.size();
		if(size<=number){		
			number = size ;
		}
		for(int i=0;i<number;i++){
			int index = new Random().nextInt(size);
			Question ques = (Question) questionlist.get(index);
			if(shiti!=null&&!shiti.equals("")){			
				String timu[] = shiti.split(",");
				for(int j=0;j<timu.length;j++){
					if(!timu[j].equals("")){
						while(Integer.parseInt(timu[j])==ques.getQid()){	
							index = new Random().nextInt(number);
							ques = (Question) questionlist.get(index);
						}
					}
				}
			}
			if(shiti.equals("")){
				shiti += ques.getQid();
			}else{
				shiti += ","+ques.getQid();
			}
		}
	}
	
	
	/*
	 * 
	 * */

	public String toExam(){
		
		if(exam.getExamid()!=0){	
			ServletActionContext.getRequest().getSession().setAttribute("examid",exam.getExamid());
		}
		List gradeList = commonService.getObjectList(DetachedCriteria.forClass(Grade.class));
		ServletActionContext.getRequest().getSession().setAttribute("gradeList", gradeList);
		return "selectExamGrade";
	}

	public String setExamGradeAndDate(){
		
		List gradeList = commonService.getObjectList(DetachedCriteria.forClass(Grade.class));
		int examid = (Integer) ServletActionContext.getRequest().getSession().getAttribute("examid");
		Exam e = (Exam) commonService.getobObjectById(Exam.class, examid);
		String gid = "";		
		String date = "";		
		if(gradeId!=null&&examDate!=null){
			for(int i =0;i<gradeId.length;i++){
				if(gid.equals("")){
					gid += gradeId[i];
				}else{
					gid += ","+gradeId[i];
				}
				if(date.equals("")){
					date += examDate[i];
				}else{
					date += ","+examDate[i];
				}
			}
		}
		e.setEstartime(date);
		e.setGid(gid);
		e.setEstatus(2);
		commonService.updateObject(e);  
		cmd = "closethis";
		return "selectExamGrade" ;
	}
	

	public String examFinish(){
		
		if(exam!=null&&exam.getExamid()!=0){
			exam = (Exam) commonService.getobObjectById(Exam.class, exam.getExamid());
			exam.setEstatus(3);
			commonService.updateObject(exam);
			exam = null;
		}
		return examIndex();
	}
	
	
	public PageBean getExampagebean() {
		return exampagebean;
	}

	public void setExampagebean(PageBean exampagebean) {
		this.exampagebean = exampagebean;
	}

	public int getP() {
		return p;
	}

	public void setP(int p) {
		this.p = p;
	}

	public List getFangxianglist() {
		return fangxianglist;
	}

	public void setFangxianglist(List fangxianglist) {
		this.fangxianglist = fangxianglist;
	}

	public List getJieduanlist() {
		return jieduanlist;
	}

	public void setJieduanlist(List jieduanlist) {
		this.jieduanlist = jieduanlist;
	}

	public String getShiti() {
		return shiti;
	}


	public void setShiti(String shiti) {
		this.shiti = shiti;
	}


	public List getProfessionallist() {
		return professionallist;
	}

	public void setProfessionallist(List professionallist) {
		this.professionallist = professionallist;
	}

	public Exam getExam() {
		return exam;
	}

	public void setExam(Exam exam) {
		this.exam = exam;
	}


	public String[] getEasy() {
		return easy;
	}


	public void setEasy(String[] easy) {
		this.easy = easy;
	}


	public String[] getCheckedQid() {
		return checkedQid;
	}

	public void setCheckedQid(String[] checkedQid) {
		this.checkedQid = checkedQid;
	}

	public String[] getNormal() {
		return normal;
	}


	public void setNormal(String[] normal) {
		this.normal = normal;
	}


	public String[] getHard() {
		return hard;
	}


	public void setHard(String[] hard) {
		this.hard = hard;
	}


	public List getAllQuestion() {
		return allQuestion;
	}

	public void setAllQuestion(List allQuestion) {
		this.allQuestion = allQuestion;
	}

	public String getCmd() {
		return cmd;
	}


	public void setCmd(String cmd) {
		this.cmd = cmd;
	}

	public ExamVo getExamVo() {
		return examVo;
	}

	public void setExamVo(ExamVo examVo) {
		this.examVo = examVo;
	}

	public List getShitiList() {
		return shitiList;
	}

	public void setShitiList(List shitiList) {
		this.shitiList = shitiList;
	}

	public int getQid() {
		return qid;
	}

	public void setQid(int qid) {
		this.qid = qid;
	}

	public Question getQuestion() {
		return question;
	}

	public void setQuestion(Question question) {
		this.question = question;
	}

	public PageBean getUpdateQuestionbean() {
		return updateQuestionbean;
	}

	public void setUpdateQuestionbean(PageBean updateQuestionbean) {
		this.updateQuestionbean = updateQuestionbean;
	}

	public String[] getGradeId() {
		return gradeId;
	}

	public void setGradeId(String[] gradeId) {
		this.gradeId = gradeId;
	}

	public String[] getExamDate() {
		return examDate;
	}

	public void setExamDate(String[] examDate) {
		this.examDate = examDate;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}
	
	
	

}
