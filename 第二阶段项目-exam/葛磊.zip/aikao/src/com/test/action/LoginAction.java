package com.test.action;

import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.opensymphony.xwork2.ActionSupport;
import com.test.bean.Manager;
import com.test.bean.Roles;
import com.test.bean.Student;
import com.test.bean.Teacher;
import com.test.service.CommonServiceImpl;
import com.test.service.ICommonService;

public class LoginAction extends ActionSupport {
	ICommonService commonservice = new CommonServiceImpl();
	private List rolesList ;
	private String uname ;
	private String password ;
	private int roleid ;
	private Object obj ;

	public String allRoleList(){
		
		DetachedCriteria dc = DetachedCriteria.forClass(Roles.class);
		rolesList = commonservice.getObjectList(dc);
		return "login" ;
	}

	public String userLogin(){
		
		List loginList = null ;
		DetachedCriteria dc = null  ;
		if(roleid==1){
			dc = DetachedCriteria.forClass(Student.class).add(Restrictions.eq("sno", uname)).add(Restrictions.eq("spwd", password));
			loginList = commonservice.getObjectList(dc);
		}else if(roleid==2){
			dc = DetachedCriteria.forClass(Teacher.class).add(Restrictions.eq("tno", uname)).add(Restrictions.eq("tpwd", password));
			loginList = commonservice.getObjectList(dc);
		}else if(roleid==3){
			dc = DetachedCriteria.forClass(Manager.class).add(Restrictions.eq("mname", uname)).add(Restrictions.eq("mpwd", password));
			loginList = commonservice.getObjectList(dc);
		}

		if(loginList!=null&&loginList.size()!=0){
			obj = loginList.get(0);
			ServletActionContext.getRequest().getSession().setAttribute("loginUser", obj);
			return "index";
		}else{
			super.addActionError("登录失败");
			return allRoleList();
		}
		
	}

	public String logout(){
		
		ServletActionContext.getRequest().getSession().invalidate();
		return allRoleList();
	}

	public List getRolesList() {
		return rolesList;
	}


	public void setRolesList(List rolesList) {
		this.rolesList = rolesList;
	}


	public String getUname() {
		return uname;
	}


	public void setUname(String uname) {
		this.uname = uname;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}

	public int getRoleid() {
		return roleid;
	}

	public void setRoleid(int roleid) {
		this.roleid = roleid;
	}



	
	
	
}
