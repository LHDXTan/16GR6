package com.test.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.Buffer;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.test.bean.Diffcult;
import com.test.bean.Professional;
import com.test.bean.QType;
import com.test.bean.Question;
import com.test.service.CommonServiceImpl;
import com.test.service.ICommonService;

public class ImportDucument extends ActionSupport {

	
	ICommonService commonservice = new CommonServiceImpl();
	private File upfile ;
	private String upfileFileName ; 
	private String upfileContentType ;
		
	private int allCount = 0 ;
	private int saveCount = 0 ;
	public String uploadFile(){
		try {
			FileInputStream fis = new FileInputStream(upfile);
			HSSFWorkbook workbook = new HSSFWorkbook(fis); 	
			HSSFSheet sheet = workbook.getSheetAt(0);		
			Question questiondemo = new Question();
			
			allCount = sheet.getLastRowNum() ;
			for(int i=1;i<sheet.getLastRowNum()+1;i++){
				HSSFRow row = sheet.getRow(i);
				int qtid = 1;
				if(row.getCell(0).toString().equals("多选")){ qtid=2; }
				QType type = (QType)commonservice.getobObjectById(QType.class,qtid);
				questiondemo.setType(type);
				questiondemo.setQtitle(row.getCell(1).toString());
				questiondemo.setOptionA(row.getCell(2).toString());
				questiondemo.setOptionB(row.getCell(3).toString());
				questiondemo.setOptionC(row.getCell(4).toString());
				questiondemo.setOptionD(row.getCell(5).toString());
				questiondemo.setAnswer(row.getCell(6).toString());
				int did = 1;
				if(row.getCell(7).toString().equals("一般")){ did=2; }
				if(row.getCell(7).toString().equals("困难")){ did=3; }
				Diffcult diff = (Diffcult) commonservice.getobObjectById(Diffcult.class, did);
				questiondemo.setDiffcult(diff);
				questiondemo.setQutil(row.getCell(8).toString());
				float f = Float.valueOf(row.getCell(9).toString());
				int pid = (int)f ;
				Professional professional = (Professional) commonservice.getobObjectById(Professional.class, pid);
				questiondemo.setProfessional(professional);
				
				commonservice.addObject(questiondemo);	
				saveCount++;
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}catch (Exception e){
			super.addActionError("");
			return "success";
		}
		return "success";
	}
	
	
	private void up(){
		
		try {
			FileInputStream fis = new FileInputStream(upfile);
			String localpath = ServletActionContext.getServletContext().getRealPath("/")+"upload";
			File file = new File(localpath);
			if(!file.exists()){
				file.mkdirs();
			}
			localpath += "/"+upfileFileName;
			OutputStream os = new FileOutputStream(localpath);
			byte[] buffer = new byte[8096];
			int len = 0;
			while((len=fis.read(buffer))!=-1){
				os.write(buffer, 0, len);
			}
			os.flush();
			os.close();
			fis.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}



	public File getUpfile() {
		return upfile;
	}
	public void setUpfile(File upfile) {
		this.upfile = upfile;
	}
	public String getUpfileFileName() {
		return upfileFileName;
	}
	public void setUpfileFileName(String upfileFileName) {
		this.upfileFileName = upfileFileName;
	}
	public String getUpfileContentType() {
		return upfileContentType;
	}
	public void setUpfileContentType(String upfileContentType) {
		this.upfileContentType = upfileContentType;
	}


	public int getAllCount() {
		return allCount;
	}


	public void setAllCount(int allCount) {
		this.allCount = allCount;
	}


	public int getSaveCount() {
		return saveCount;
	}


	public void setSaveCount(int saveCount) {
		this.saveCount = saveCount;
	}
	
}
