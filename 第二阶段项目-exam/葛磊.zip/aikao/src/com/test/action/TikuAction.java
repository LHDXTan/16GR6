package com.test.action;

import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;


import com.opensymphony.xwork2.ActionSupport;
import com.test.bean.Diffcult;
import com.test.bean.Fangxiang;
import com.test.bean.Jieduan;
import com.test.bean.JishiQuestion;
import com.test.bean.Professional;
import com.test.bean.QType;
import com.test.bean.Question;
import com.test.service.CommonServiceImpl;
import com.test.service.ICommonService;
import com.test.service.ITiKuService;
import com.test.service.TiKuServiceImpl;
import com.test.vo.PageBean;

public class TikuAction extends ActionSupport {

	private ICommonService commonservice = new CommonServiceImpl();
	ITiKuService tikuServie = new TiKuServiceImpl();
	private List fangxiangList ;		
	private List difficultList ;		
	private List jieduanList ;			
	private Professional professional ;	
	private List questionList ;			
	private Question question ;			
	private JishiQuestion jishiquestion ;
	private int fid ;
	private int jid ;
	private int p ;		
	private int qtid ;		
	private PageBean questionPagebean ;
	private List expoetQuestion ;	
	private List courseInfoList ;	
	

	public String tikuIndex(){
		
		list();
		DetachedCriteria dc = DetachedCriteria.forClass(Professional.class);
		if(fid!=0){
			dc.add(Restrictions.eq("fid", fid));
		}
		if(jid!=0){
			dc.add(Restrictions.eq("jid", jid));
		}
		courseInfoList = tikuServie.getProfessionalList(dc);
		return "index";
	}

	public void list(){
		
		DetachedCriteria dc1 = DetachedCriteria.forClass(Fangxiang.class);
		fangxiangList = commonservice.getObjectList(dc1);
		DetachedCriteria dc2 = DetachedCriteria.forClass(Jieduan.class);
		jieduanList = commonservice.getObjectList(dc2);
	}

	public String professionalInfo(){
		
		if(professional!=null&&professional.getPid()!=0){
			professional = (Professional) commonservice.getobObjectById(Professional.class, professional.getPid());
			ServletActionContext.getRequest().getSession().setAttribute("pid", professional.getPid());
			ServletActionContext.getRequest().getSession().setAttribute("qtid",qtid);
			System.out.println(professional.getPid()+"  ==="+qtid);
			if(qtid==1){		
				DetachedCriteria dc_question = DetachedCriteria.forClass(JishiQuestion.class)
						.add(Restrictions.eq("pid", professional.getPid()));
				questionPagebean = commonservice.queryPageInfo(p,dc_question,4);
				return "jishiQList";
			}else{				
				DetachedCriteria dc_question = DetachedCriteria.forClass(Question.class)
						.add(Restrictions.eq("pid", professional.getPid()));
				questionPagebean = commonservice.queryPageInfo(p,dc_question,4);
				return "bishiQList";
			}
		}
		return tikuIndex();
	}

	public String addQuestion(){
		
		if(professional!=null&&professional.getPid()!=0){
			professional = (Professional) commonservice.getobObjectById(Professional.class, professional.getPid());
			DetachedCriteria dc = DetachedCriteria.forClass(Diffcult.class);
			difficultList = commonservice.getObjectList(dc);
		}
		if(qtid==1){
			return "addjishiQ";
		}else{
			return "addbishiQ";
		}
		
	}

	public String goaddQuestion(){
		
		if(question!=null){
			String[] optionA = question.getOptionA().split(",");
			for(int i=0;i<optionA.length;i++){
				
			}
			professional = (Professional) commonservice.getobObjectById(Professional.class, professional.getPid());
			question.setProfessional(professional);
			QType qtype = (QType) commonservice.getobObjectById(QType.class,question.getQtype());
			question.setType(qtype);		
			Diffcult d = (Diffcult) commonservice.getobObjectById(Diffcult.class,question.getDid());
			question.setDiffcult(d);
			commonservice.addObject(question);
		}
		return "closethis";
	}

	public String addjishiQuestion(){
		
		if(jishiquestion!=null){
			professional = (Professional) commonservice.getobObjectById(Professional.class, professional.getPid());
			jishiquestion.setProfessional(professional);
			Diffcult d = (Diffcult) commonservice.getobObjectById(Diffcult.class,jishiquestion.getDid());
			jishiquestion.setDiffcult(d);
			commonservice.addObject(jishiquestion);
		}
		return "closethis";
	}

	public String toUpdate(){
		
		DetachedCriteria dc = DetachedCriteria.forClass(Diffcult.class);
		professional = (Professional) commonservice.getobObjectById(Professional.class, professional.getPid());
		difficultList = commonservice.getObjectList(dc);
		if(qtid==1){		
			return "updatejishi";
		}else{				
			question =  (Question) commonservice.getobObjectById(Question.class, question.getQid());
			return "updatebishi";
		}
	}

	public String update(){
		
		if(qtid==1){
			
		}else{
			professional = (Professional) commonservice.getobObjectById(Professional.class, professional.getPid());
			question.setProfessional(professional);
			QType qtype = (QType) commonservice.getobObjectById(QType.class,question.getQtype());
			question.setType(qtype);		
			Diffcult d = (Diffcult) commonservice.getobObjectById(Diffcult.class,question.getDid());
			question.setDiffcult(d);
			commonservice.updateObject(question);
		}
		return "closethis";
	}

	public String deleteQuestion(){
		
		if(qtid==1){
			
		}else{
			question = (Question) commonservice.getobObjectById(Question.class, question.getQid());
			commonservice.deleteObject(question);
		}
		return professionalInfo();
	}

	public String exportQuestion(){
		
		DetachedCriteria dc = DetachedCriteria.forClass(Question.class)
											.add(Restrictions.eq("pid", professional.getPid()));
		expoetQuestion = commonservice.getObjectList(dc);
		return "export   ";
	}

	public String goBack(){
		
		p = 1 ;
		professional = new Professional();
		professional.setPid((Integer) ServletActionContext.getRequest().getSession().getAttribute("pid"));
		qtid = (Integer) ServletActionContext.getRequest().getSession().getAttribute("qtid");
		return professionalInfo();
	}
	
	public String loadshiti(){
		
		
		return null;
	}
	
	public List getFangxiangList() {
		return fangxiangList;
	}

	public void setFangxiangList(List fangxiangList) {
		this.fangxiangList = fangxiangList;
	}

	public List getJieduanList() {
		return jieduanList;
	}

	public void setJieduanList(List jieduanList) {
		this.jieduanList = jieduanList;
	}

	public int getFid() {
		return fid;
	}

	public void setFid(int fid) {
		this.fid = fid;
	}

	public int getJid() {
		return jid;
	}

	public void setJid(int jid) {
		this.jid = jid;
	}

	public Professional getProfessional() {
		return professional;
	}

	public void setProfessional(Professional professional) {
		this.professional = professional;
	}


	public List getQuestionList() {
		return questionList;
	}


	public void setQuestionList(List questionList) {
		this.questionList = questionList;
	}


	public PageBean getQuestionPagebean() {
		return questionPagebean;
	}


	public void setQuestionPagebean(PageBean questionPagebean) {
		this.questionPagebean = questionPagebean;
	}


	public int getP() {
		return p;
	}


	public void setP(int p) {
		this.p = p;
	}


	public int getQtid() {
		return qtid;
	}
	public void setQtid(int qtid) {
		this.qtid = qtid;
	}


	public List getDifficultList() {
		return difficultList;
	}


	public void setDifficultList(List difficultList) {
		this.difficultList = difficultList;
	}


	public Question getQuestion() {
		return question;
	}


	public void setQuestion(Question question) {
		this.question = question;
	}

	public List getExpoetQuestion() {
		return expoetQuestion;
	}

	public void setExpoetQuestion(List expoetQuestion) {
		this.expoetQuestion = expoetQuestion;
	}

	public List getCourseInfoList() {
		return courseInfoList;
	}

	public void setCourseInfoList(List courseInfoList) {
		this.courseInfoList = courseInfoList;
	}


	public JishiQuestion getJishiquestion() {
		return jishiquestion;
	}


	public void setJishiquestion(JishiQuestion jishiquestion) {
		this.jishiquestion = jishiquestion;
	}



	
	
	
}
