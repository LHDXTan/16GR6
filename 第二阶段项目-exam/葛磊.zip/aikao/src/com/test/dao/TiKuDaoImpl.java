package com.test.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;


import com.test.bean.Professional;
import com.test.bean.Question;
import com.test.gongju.HibernateSessionFactory;
import com.test.vo.CourseInfo;

public class TiKuDaoImpl implements ITiKuDao {
	public List getProfessionalList(DetachedCriteria dc){
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tr = session.beginTransaction();
		List courseInfoList = new ArrayList();
		List professional_list = dc.getExecutableCriteria(session).list();
		for(Object o:professional_list){
			Professional p = (Professional) o ;
			CourseInfo course = new CourseInfo();		
			course.setPid(p.getPid());
			course.setProname(p.getPname());
			String hql = "select j.jname from Jieduan j where j.jid="+p.getJid();
			List list_jieduan = session.createQuery(hql).list();
			course.setJname((String) list_jieduan.get(0));
			String hql1 = "select count(q.qid) from Question q where q.pid="+p.getPid();
			List list_question = session.createQuery(hql1).list();
			course.setBishiCount(new Long((Long) list_question.get(0)).intValue());
			String hql2 = "select count(j.jishiId) from JishiQuestion j where j.pid="+p.getPid();
			List list_jishi = session.createQuery(hql2).list();
			course.setJishiCount(new Long((Long)list_jishi.get(0)).intValue());
			courseInfoList.add(course);
		}
		tr.commit();
		HibernateSessionFactory.closeSession();
		return courseInfoList ;
	}
	
	
	

}
