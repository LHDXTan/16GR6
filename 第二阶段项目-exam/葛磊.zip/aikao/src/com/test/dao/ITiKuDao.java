package com.test.dao;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;

public interface ITiKuDao {
	
	public List getProfessionalList(DetachedCriteria dc);
	
	
}
