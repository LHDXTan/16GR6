package com.test.vo;

import com.test.bean.Exam;

public class ExamVo {

	private Exam exam ;
	private String kemu ;
	private String gradeNames ;
	
	public ExamVo() {
	}
	public Exam getExam() {
		return exam;
	}
	public void setExam(Exam exam) {
		this.exam = exam;
	}
	public String getGradeNames() {
		return gradeNames;
	}
	public void setGradeNames(String gradeNames) {
		this.gradeNames = gradeNames;
	}
	public String getKemu() {
		return kemu;
	}
	public void setKemu(String kemu) {
		this.kemu = kemu;
	}
	
	
	
}
