package com.test.vo;

import com.test.bean.Question;

public class QuesAndAnwser {

	private Question ques ;
	private String anwserLength ;	
	private String anwser ;			
	private String studentAnwser ; 
	private int istrue ;			
	
	
	public QuesAndAnwser() {
		
	}
	
	
	public Question getQues() {
		return ques;
	}
	public void setQues(Question ques) {
		this.ques = ques;
	}
	public String getAnwserLength() {
		return anwserLength;
	}
	public void setAnwserLength(String anwserLength) {
		this.anwserLength = anwserLength;
	}
	public String getAnwser() {
		return anwser;
	}
	public void setAnwser(String anwser) {
		this.anwser = anwser;
	}
	public String getStudentAnwser() {
		return studentAnwser;
	}
	public void setStudentAnwser(String studentAnwser) {
		this.studentAnwser = studentAnwser;
	}
	public int getIstrue() {
		return istrue;
	}
	public void setIstrue(int istrue) {
		this.istrue = istrue;
	}
	
	
}
