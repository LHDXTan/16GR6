package com.test.vo;

import java.util.List;

public class ExamScoreInfo {

	
	private List studentScorelist;	
	
	private int examid;
	private String kemu ;		
	private int total;			
	private int passNumber;		
	private float passRate;		
	
	
	
	public ExamScoreInfo(){
		
	}
	
	
	
	public String getKemu() {
		return kemu;
	}
	public void setKemu(String kemu) {
		this.kemu = kemu;
	}
	public List getStudentScorelist() {
		return studentScorelist;
	}
	public void setStudentScorelist(List studentScorelist) {
		this.studentScorelist = studentScorelist;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getPassNumber() {
		return passNumber;
	}
	public void setPassNumber(int passNumber) {
		this.passNumber = passNumber;
	}
	public float getPassRate() {
		return passRate;
	}
	public void setPassRate(float passRate) {
		this.passRate = passRate;
	}



	public int getExamid() {
		return examid;
	}



	public void setExamid(int examid) {
		this.examid = examid;
	}
	
	
	
	
}
