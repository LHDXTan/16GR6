package com.test.vo;

import java.util.ArrayList;
import java.util.List;

public class PageBean {

	private int p ;			
	private int count ;		
	private int pageSize ;	
	private int pageTotal ;	
	private List<Object> data ;		
	
	
	
	public PageBean() {
		
		pageSize = 4 ;
		data = new ArrayList<Object>();
	}
	public int getP() {
		return p;
	}
	public void setP(int up) {
		
		//����ҳ��
		if(up<=0){
			this.p=pageTotal;
		}else if(up>pageTotal){
			this.p = 1;
		}else{
			this.p = up ;
		}
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
		this.pageTotal = (int)Math.ceil(count*1.0/pageSize);
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public int getPageTotal() {
		return pageTotal;
	}
	public void setPageTotal(int pageTotal) {
		this.pageTotal = pageTotal;
	}
	public List getData() {
		return data;
	}
	public void setData(List data) {
		this.data = data;
	}
	
	//��������
	public void addData(Object obj){
		data.add(obj);
	}
	
	
}
