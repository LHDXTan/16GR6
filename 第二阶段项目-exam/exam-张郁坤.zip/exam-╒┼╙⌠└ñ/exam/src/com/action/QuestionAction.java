package com.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.beans.PageBean;
import com.daoimpl.BaseDaoImpl;
import com.google.gson.Gson;
import com.opensymphony.xwork2.ActionSupport;
import com.pojo.Question;
import com.pojo.Subject;

public class QuestionAction extends ActionSupport {
	private PageBean pb;
	private List<Subject> sublist = new ArrayList();
	private List<Subject> subsuslist = new ArrayList();
	private List<Subject> subjectlist;
	private List<Question> questionlist;
	private Subject sub;
	private Question que;
	private int page;
	private int rows;
	BaseDaoImpl base = new BaseDaoImpl();
	HttpServletRequest request = ServletActionContext.getRequest();
	HttpServletResponse response = ServletActionContext.getResponse();
	
	//修改机试试题
	public String updComputerQuestion() throws IOException{
		response.setContentType("text;charset=UTF-8");
		PrintWriter out = response.getWriter();
		Question q = (Question)base.getObjectById(Question.class, que.getQid());
		q.setContent(que.getContent());
		q.setHard(que.getHard());
		int flag = base.update(q);
		if(flag==1){
			out.print(1);
		} else {
			out.print(0);
		}
		return null;
	}
	
	//去修改机试试题页面
	public String toComputerUpdate(){
		que = (Question)base.getObjectById(Question.class, que.getSuid());
		return "toComputerQuestion";
	}
	
	//添加机试试题
	public String addComputerQuestion() throws IOException{
		int flag = 0;
		response.setContentType("text;charset=UTF-8");
		PrintWriter out = response.getWriter();
		if(!"".equals(que.getContent()) ){
			sub = (Subject)base.getObjectById(Subject.class, que.getSuid());
			que.setType("机试");
			que.setSubject(sub);
			que.setQtype(0);
			flag = base.add(que);
		}
		out.print(flag);
		return null;
	}
	
	//去机试添加试题页面
	public String toAddComputerQuestion(){
		sub = (Subject)base.getObjectById(Subject.class, que.getSuid());
		return "addComputerQuestion";
	}
	
	//获取机试试题列表
	public String selComputerTestQuestion(){
		int up = 1;		//默认显示第一页
		if(pb!=null){
			up = pb.getP();
			if(up>pb.getPagetotal()){
				up = pb.getPagetotal();
			}
		}
		pb = base.getComputerQuestion(sub,up);
		questionlist = pb.getQuestionlist();
		sub = (Subject)base.getObjectById(Subject.class, sub.getSuid());
		return "computerTest";
	}
	
	//查询试题、科目、方向
	public String selectSub(){
		sublist = base.getSusSelect();
		subsuslist = base.getSudSelect();
		String sql = null;
		if(!("0").equals(sub.getSudirec()) && !("0").equals(sub.getSustage())){
			sql = "from Subject where sudirec ='"+sub.getSudirec()+"' and sustage = '"+sub.getSustage()+"'";
		} else if(!("0").equals(sub.getSudirec())){
			sql = "from Subject where sudirec ='"+sub.getSudirec()+"'";
		} else if(!("0").equals(sub.getSustage())){
			sql = "from Subject where sustage ='"+sub.getSustage()+"'";
		} else if(("0").equals(sub.getSudirec()) || ("0").equals(sub.getSustage())){
			return "toSubjectAll";
		}
		subjectlist = base.getObjects(sql);
		return "sub";
	}
	
	//删除试题
	public String delQestion() throws IOException{
		response.setContentType("text;charset=UTF-8");
		PrintWriter out = response.getWriter();
		que = (Question)base.getObjectById(Question.class, que.getQid());
		int flag = base.delete(que);
		//修改题数
		int qtype = que.getQtype();
		sub = (Subject)base.getObjectById(Subject.class, que.getSuid());
		if(qtype==0){
			sub.setComputernub(sub.getComputernub()-1);
		} else {
			sub.setPennub(sub.getPennub()-1);
		}
		flag = base.update(sub);
		out.print(flag);
		return null;
	}
	
	//添加笔试试题
	public String addQuestion() throws IOException{
		int flag = 0;
		response.setContentType("text;charset=UTF-8");
		PrintWriter out = response.getWriter();
		if(!"".equals(que.getAnswer()) &&  !"".equals(que.getContent())
			&& !"".equals(que.getHard()) && !"".equals(que.getType())  ){
			sub = (Subject)base.getObjectById(Subject.class, que.getSuid());
			que.setSubject(sub);
			que.setQtype(1);
			flag = base.add(que);
		}
		out.print(flag);
		return null;
	}
	
	//去添加笔试页面
	public String toAdd(){
		if(que.getSuid()!=null){
			sub = (Subject)base.getObjectById(Subject.class, que.getSuid());
			return "addQuestion";
		}
		return null;
	}
	
	//笔试修改
	public String updQuestion() throws IOException{
		response.setContentType("text;charset=UTF-8");
		PrintWriter out = response.getWriter();
		Question q = (Question)base.getObjectById(Question.class, que.getQid());
		q.setAnswer(que.getAnswer());
		q.setCharpter(que.getCharpter());
		q.setContent(que.getContent());
		q.setHard(que.getHard());
		q.setOptionA(que.getOptionA());
		q.setOptionB(que.getOptionB());
		q.setOptionC(que.getOptionC());
		q.setOptionD(que.getOptionD());
		q.setType(que.getType());
		int flag = base.update(q);
		if(flag==1){
			out.print(1);
		} else {
			out.print(0);
		}	
		return null;
	}
	
	
	
	//去笔试修改页面
	public String toUpdate() throws IOException{
		que = (Question)base.getObjectById(Question.class, que.getSuid());
		request.setAttribute("s", que.getAnswer());
		return "toTestQuestion";
	}
	
	//获取笔试试题列表
	public String selQuestion(){
		int up = 1;		//默认显示第一页
		if(pb!=null){
			up = pb.getP();
			if(up>pb.getPagetotal()){
				up = pb.getPagetotal();
			}
		}
		pb = base.getPentQuestion(sub,up);
		questionlist = pb.getQuestionlist();
		sub = (Subject) base.getObjectById(Subject.class, sub.getSuid());
		return "pentest";
	}

	
	//获取科目
	public String selSubject(){
		subjectlist = base.getQuestionNub();
		if(subjectlist.size()!=0){
			sublist = base.getSusSelect();
			subsuslist = base.getSudSelect();
		}
		return "toSubject";
	}

	public List<Subject> getSubjectlist() {
		return subjectlist;
	}

	public void setSubjectlist(List<Subject> subjectlist) {
		this.subjectlist = subjectlist;
	}

	public List<Question> getQuestionlist() {
		return questionlist;
	}

	public void setQuestionlist(List<Question> questionlist) {
		this.questionlist = questionlist;
	}

	public Subject getSub() {
		return sub;
	}

	public void setSub(Subject sub) {
		this.sub = sub;
	}

	public Question getQue() {
		return que;
	}

	public void setQue(Question que) {
		this.que = que;
	}

	public List<Subject> getSublist() {
		return sublist;
	}

	public void setSublist(List<Subject> sublist) {
		this.sublist = sublist;
	}
	/**
	 * @return the subsuslist
	 */
	public List<Subject> getSubsuslist() {
		return subsuslist;
	}

	/**
	 * @param subsuslist the subsuslist to set
	 */
	public void setSubsuslist(List<Subject> subsuslist) {
		this.subsuslist = subsuslist;
	}

	public PageBean getPb() {
		return pb;
	}

	public void setPb(PageBean pb) {
		this.pb = pb;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getRows() {
		return rows;
	}

	public void setRows(int rows) {
		this.rows = rows;
	}


	
}
