package com.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.daoimpl.BaseDaoImpl;
import com.google.gson.Gson;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.pojo.Adminuser;
import com.pojo.Student;
import com.pojo.Teacher;

public class LoginAction extends ActionSupport {
	private String nam;
	private String pwd;
	private int role;
	HttpServletRequest request = ServletActionContext.getRequest();
	BaseDaoImpl base = new BaseDaoImpl();
	HttpServletResponse response = ServletActionContext.getResponse();
	
	public String juese(){		
		try {
			response.setCharacterEncoding("UTF-8");
			PrintWriter out = response.getWriter();
			List list = base.getObjects("from Juese");
			out.print(new Gson().toJson(list));
			out.flush();
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public String checkNam(){		
		try {
			response.setContentType("text;charset=UTF-8");
			PrintWriter out = response.getWriter();
			List list = base.getObjects("from adminuser where loginuser='"+nam+"'");
			List list2 = base.getObjects("from student where loginuser='"+nam+"'");
			List list3 = base.getObjects("from adminuser where loginuser='"+nam+"'");
			if(list.size()!=0 || list2.size()!=0 || list3.size()!=0){
				out.print("1");
			} else {
				out.print("0");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	//退出系统
	public String logout(){
		request.getSession().invalidate();
		return "out";
	}
	
	public String userLogin(){
		//HttpServletRequest request = ServletActionContext.getRequest();
		if(!"".equals(nam) && !"".equals(pwd)){
			List list = base.login(nam, pwd, role);
			if(list.size()==0){
				request.setAttribute("error", "账号或密码错误");
				return "error";
			} else {
				request.getSession().setAttribute("role", role);
				if("student".equals(list.get(1).toString())){
					Student stu = (Student)list.get(0);
					request.getSession().setAttribute("rolename", stu.getSname());
					request.getSession().setAttribute("student", stu);
				} else if("teacher".equals(list.get(1).toString())){
					Teacher tea = (Teacher)list.get(0);
					request.getSession().setAttribute("rolename", tea.getTname());
					request.getSession().setAttribute("teacher", tea);
				} else {
					Adminuser admin = (Adminuser)list.get(0);
					request.getSession().setAttribute("rolename", "管理员");
				}
				return "success";
			}
		}
		return null;
	}
	/**
	 * @return the nam
	 */
	public String getNam() {
		return nam;
	}
	/**
	 * @return the pwd
	 */
	public String getPwd() {
		return pwd;
	}
	/**
	 * @return the role
	 */
	public int getRole() {
		return role;
	}
	/**
	 * @param nam the nam to set
	 */
	public void setNam(String nam) {
		this.nam = nam;
	}
	/**
	 * @param pwd the pwd to set
	 */
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	/**
	 * @param role the role to set
	 */
	public void setRole(int role) {
		this.role = role;
	}
}
