package com.dao;

import java.util.List;

import net.sf.json.JSONArray;


import com.beans.PageBean;
import com.beans.RandomPaper;
import com.pojo.Question;

public interface PaperDao {
	
	//条件查询试卷
	public PageBean selectPaper(RandomPaper ran,int p);
	
	//试卷分页
	public PageBean getAllPaper(int p);
	
	//拼装json（选题组卷）
	public JSONArray choicePaperJson(List<Question> questionlist);
	
	//获取全部笔试题
	public PageBean getAllPentQuestion(int suid,int p);
}
