package com.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.daoimpl.BaseDaoImpl;
import com.daoimpl.ExamDaoImpl;
import com.daoimpl.PaperDaoImpl;
import com.opensymphony.xwork2.ActionSupport;
import com.pojo.Classes;
import com.pojo.Paper;
import com.pojo.Question;
import com.pojo.Score;
import com.pojo.Student;

public class ChengjiAction extends ActionSupport {
	private Student stu;
	private List list;
	private List<Question> questionlist;
	private Set<Question> questionset;
	private Paper paper;
	private Score score;
	private List<Paper> paperlist;
	private List<Score> scorelist;
	BaseDaoImpl base = new BaseDaoImpl();
	PaperDaoImpl pdi = new PaperDaoImpl();
	ExamDaoImpl edi = new ExamDaoImpl();
	HttpServletRequest request = ServletActionContext.getRequest();
	HttpServletResponse response = ServletActionContext.getResponse();
	
//	public String selPaper(){
//		List<Student> stulist = base.getObjects("from Student where sname = '"+stu.getSname()+"'");
//		if(stulist!=null){
//			stu = stulist.get(0);
//		}
//		String sql = "select p.* from paper p,Score s,student st where p.pId = s.pid and s.sid = st.sid and s.sid="+stu.getSid();
//		paperlist = edi.getStudent(sql);
//		return "toAllPaper";
//	}
	
	//
	public String lookStudentCj(){
		Student stu = (Student)request.getSession().getAttribute("student");
		scorelist = base.getObjects("from Score where sid = "+stu.getSid());
		return "paperQuestion";
	}
	
	//查看详情
	public String lookXiangqing(){
		if(score != null){
			List list = edi.getmyScoreInfo(score.getScid());
			request.getSession().setAttribute("scoreInfo", list);
		}
		return "scoreInfo";
	}
	
	//获取试卷里的试题（点击查看试卷）
	public String lookPaper(){
		scorelist = base.getObjects("from Score where pid="+paper.getPid());
		return "paperQuestion";
	}
	//全部试卷
	public String allChengjiPaper(){
		paperlist = base.getObjects("from Paper where pstate = 3");
		return "toAllPaper";
	}
	public List getList() {
		return list;
	}
	public void setList(List list) {
		this.list = list;
	}
	public List<Question> getQuestionlist() {
		return questionlist;
	}
	public void setQuestionlist(List<Question> questionlist) {
		this.questionlist = questionlist;
	}
	public Set<Question> getQuestionset() {
		return questionset;
	}
	public void setQuestionset(Set<Question> questionset) {
		this.questionset = questionset;
	}
	public Paper getPaper() {
		return paper;
	}
	public void setPaper(Paper paper) {
		this.paper = paper;
	}
	public List<Paper> getPaperlist() {
		return paperlist;
	}
	public void setPaperlist(List<Paper> paperlist) {
		this.paperlist = paperlist;
	}
	public List<Score> getScorelist() {
		return scorelist;
	}
	public void setScorelist(List<Score> scorelist) {
		this.scorelist = scorelist;
	}
	public Score getScore() {
		return score;
	}
	public void setScore(Score score) {
		this.score = score;
	}

	public Student getStu() {
		return stu;
	}

	public void setStu(Student stu) {
		this.stu = stu;
	}
	
	

}
