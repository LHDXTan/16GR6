package com.daoimpl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.beandao.HibernateSessionFactory;
import com.pojo.Paper;
import com.pojo.Question;
import com.pojo.Score;
import com.pojo.Student;
import com.vo.QuesAndAnwser;

public class ExamDaoImpl {
//	
//	public List getStudent(String sql){
//		Session session = HibernateSessionFactory.getSession();
//		Transaction tr = session.beginTransaction();
//		List list = session.createSQLQuery(sql).list();
//		List<Paper> x = new ArrayList<Paper>();
//		for(int i=0;i<list.size();i++){
//			Object[] o  = (Object[])list.get(i);
//			//[80, 笔试, JAVA基础, 1, 20.0, 20, 2, 10, 3, 1班, 2018-4-4 16:52]
//			Paper p = new Paper();
//			p.setPid(Integer.parseInt(o[0].toString()));
//			p.setPtype(o[1].toString());
//			p.setSuname(o[2].toString());
//			p.setPtitle(Integer.parseInt(o[3].toString()));
//			p.setPtime(Integer.parseInt(o[4].toString()));
//			p.setPtotal(Double.valueOf(o[5].toString()));
//			p.setPone(Integer.parseInt(o[6].toString()));
//			p.setPstate(Integer.parseInt(o[7].toString()));
//			p.setClassname(o[8].toString());
//			p.setExamtime(o[9].toString());
//			x.add(p);
//		}
//		tr.commit();
//		HibernateSessionFactory.closeSession();
//		return x;
//	}
	
	//获取成绩详情
	public List getmyScoreInfo(int scid) {
		List quesAnwserList = new ArrayList();
		Session session = HibernateSessionFactory.getSession();
		Transaction tr = session.beginTransaction();
		
		Score score = (Score) session.get(Score.class, scid);
		Paper paper = (Paper)session.get(Paper.class, score.getPid());
		ServletActionContext.getRequest().getSession().setAttribute("score", score);
		ServletActionContext.getRequest().getSession().setAttribute("paper", paper);
		
		String[] anwsers = score.getAnswer().split(",");		//答案数组
		Set<Question> questions = paper.getQuestion();		//试题
		int i = 0;
		for(Question que : questions){
			//用于页面显示的vo
			QuesAndAnwser quesVo = new QuesAndAnwser();
			//如果答案为空 交白卷  直接设置答案为空
			if(score.getAnswer().equals("")){
				quesVo.setQues(que);
				quesVo.setIstrue(0);
				quesVo.setStudentAnwser("未作答");
				quesVo.setAnwserLength("选"+que.getAnswer().length()+"项");
				quesVo.setAnwser(que.getAnswer());
				quesAnwserList.add(quesVo);
				continue ;	//结束本次循环
			}
			quesVo.setQues(que);
			//循环全部答案  如果答案编号和问题下标相同匹配到问题答案
			int count = 0 ;
			for(int j =0;j<anwsers.length;j++){
				String[] per = anwsers[j].split("_");
				if(Integer.parseInt(per[0])-1==i){		//按照题目顺序匹配答案和问题  下标比答案编号少1
					if(per[1].equals(que.getAnswer())){
						quesVo.setIstrue(1);			//1为表示回答正确
					}else{
						quesVo.setIstrue(0);
					}
					quesVo.setStudentAnwser(per[1]);
				}
				quesVo.setAnwserLength("选"+que.getAnswer().length()+"项");
				quesVo.setAnwser(que.getAnswer());
			}
			quesAnwserList.add(quesVo);
			i++;
		}	
		tr.commit();
		HibernateSessionFactory.closeSession();
		return quesAnwserList;
	}

	public Object getobObjectById(Class class1, int id) {
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tr = session.beginTransaction();
		
		Object obj = session.get(class1, id);
		
		tr.commit();
		HibernateSessionFactory.closeSession();
		return obj;
	}
	
	//获取试卷的问题列表
	public List examshitiList(Paper paper){
		
		Session session = HibernateSessionFactory.getSession();
		Transaction tr = session.beginTransaction();
		
		List<Question> list = new ArrayList<Question>();
		if(paper!=null){
			Set<Question> set = paper.getQuestion();
			for(Question q:set){
				list.add(q);
			}
		}
		
		tr.commit();
		HibernateSessionFactory.closeSession();
		return list;
		
	}

}
