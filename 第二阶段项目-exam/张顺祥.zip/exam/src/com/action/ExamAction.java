package com.action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.daoimpl.BaseDaoImpl;
import com.daoimpl.PaperDaoImpl;
import com.opensymphony.xwork2.ActionSupport;
import com.pojo.Classes;
import com.pojo.Paper;
import com.pojo.Paperinfo;
import com.pojo.Question;
import com.pojo.Student;

public class ExamAction extends ActionSupport {
	private List<Paper> paperlist;
	private Student stu;
	private Classes cla;
	private Paper paper;
	private List<Question> questionlist;
	private List<Paperinfo> info;
	BaseDaoImpl base = new BaseDaoImpl();
	PaperDaoImpl pdi = new PaperDaoImpl();
	HttpServletRequest request = ServletActionContext.getRequest();
	HttpServletResponse response = ServletActionContext.getResponse();
	
	public String questionList(){
		paper = (Paper)base.getObjectById(Paper.class, paper.getPid());
		info = base.getObjects("from Paperinfo where pid = "+paper.getPid());
		return "examIng";
	}
	
	public String allExamPaper(){
		Student stu = (Student)request.getSession().getAttribute("student");
		cla = (Classes)base.getObjectById(Classes.class, stu.getSclass());
		paperlist = base.getObjects("from Paper where classname = '"+cla.getClassname()+"'");
//		for(Paper p:paperlist){
//			String examtime = p.getExamtime();
//			//获取现在的时间
//			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
//			Date day = new Date();
//		    String nowtime = df.format(day);
//		    int x = pdi.compare_date(examtime, nowtime);
//		    if(x!=1){
//		    	System.out.println("考试中");
//		    	p.setPstate(2);
//		    	int flag = base.update(p);
//		    	System.out.println(flag);
//		    } else {
//		    	System.out.println("未开考");
//		    }
//		}
//		paperlist = base.getObjects("from Paper where classname = '"+cla.getClassname()+"' and pstate=2");
		return "toAllExamPaper";
	}
	public List<Paper> getPaperlist() {
		return paperlist;
	}
	public void setPaperlist(List<Paper> paperlist) {
		this.paperlist = paperlist;
	}
	public Student getStu() {
		return stu;
	}
	public void setStu(Student stu) {
		this.stu = stu;
	}
	public Classes getCla() {
		return cla;
	}
	public void setCla(Classes cla) {
		this.cla = cla;
	}
	public Paper getPaper() {
		return paper;
	}
	public void setPaper(Paper paper) {
		this.paper = paper;
	}
	
	
}
