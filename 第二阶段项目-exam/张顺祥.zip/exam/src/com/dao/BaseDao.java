package com.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.SQLQuery;

import com.beans.PageBean;
import com.beans.RandomPaper;
import com.pojo.Subject;

public interface BaseDao {
	
	public int add(Object obj);
	public int update(Object obj);	
	public int delete(Object obj);
	public Object getObjectById(Class clazz,Serializable id);
	public List getObjects(String hql);
	public List login(String nam,String pwd,int role);
	public List<Subject> getQuestionNub();
	public List<Subject> getSusSelect();
	public List<Subject> getSudSelect();	
	public PageBean getPentQuestion(Subject sub,int p);
	public PageBean getComputerQuestion(Subject sub,int p);
	public String fangXiang();
	//获取科目表的suid
	public int getSuid(RandomPaper ran);
	//通过suid获取到全部的难度的题/笔试题
	public List getPenQuestions(int suid);

}
