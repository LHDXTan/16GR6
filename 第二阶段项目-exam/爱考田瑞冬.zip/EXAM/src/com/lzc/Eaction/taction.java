package com.lzc.Eaction;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;

import com.lzc.basedao.BaseDaoImpl;
import com.lzc.basedao.HibernateSessionFactory;
import com.lzc.bean.Paper;
import com.lzc.bean.Paperinfo;
import com.lzc.bean.Question;
import com.lzc.bean.Subject;
import com.lzc.bean.listbean;
import com.lzc.bean.pagebean;
import com.lzc.beans.Classs;
import com.opensymphony.xwork2.Action;

public class taction implements Action {

	//封装中间表实体类
	private  Paperinfo paperinfo;
	//封装科目表实体类
	private  Subject   subject;
	private List<Subject[]> sub;
	private List<Subject> subs;
	//封装题库表实体类
	private  Question  question;
	private List<Question> ques;
	private List<Question[]> que;
	//封装班级实体类
	private List<Classs> classe;
	private Classs       cla;
	//封装试卷表实体类
	private  Paper paper;
	private List<Paper>  papers;
	private Integer num;//单选题，题数——简单
	private Integer num1;//单选题，题数——一般
	private Integer num2;//单选题，题数——困难
	
	private Integer nums;//多选题，题数——简单
	private Integer nums1;//多选题，题数——一般
	private Integer nums2;//多选题，题数——困难
	private BaseDaoImpl dao = new BaseDaoImpl();
	private pagebean page=new pagebean();
	public String id;//用于删除时接收题库ID
	public Integer id1;//接收添加/修改时的科目ID
	public Integer ss;//修改时接收题库的ID
	public Integer count;//
	private Query query;
	private String list;
	public String execute() throws Exception {
		
		return null;
	}

	//查询
  public String list(){
      String hql="select s from Subject s";
      subs=dao.getObjects(hql);
      String hql1="select su.suId,su.suName,su.sudirec,su.sustage,(CASE WHEN num1 IS null then '0' else num1 end),"
      		+ "(CASE WHEN num2 IS null then '0' else num2 end) as num2 from "
      		+ "(select tab1.suid,tab1.num num1,tab2.num num2 from(select count(pType)num,suid from Question where pType='笔试题'  group by suid) as tab1 "
      		+ "FULL  JOIN(select count(pType)num,suid  from Question where pType='机试题'  group by suid) as "
      		+ "tab2 on tab1.suid=tab2.suid)as tab3 right join Subject su on su.suId=tab3.suid";
      sub=dao.getObjects1(hql1);
      return "sub";
  }
  //查询考题表
  public String listqu() throws UnsupportedEncodingException{
	  String ss=new String(question.getpType().getBytes("ISO-8859-1"),"utf-8");
	  HttpServletRequest request2=ServletActionContext.getRequest();
  	  request2.getSession().setAttribute("st",ss);//试题类型
  	  request2.getSession().setAttribute("st1",subject.getSuName());//科目
  	//查询出总条数
  	String hql="select DISTINCT s.suId,q.qid,q.type,q.content,q.optionA,q.optionB,q.optionC,q.optionD,q.answer,q.hard,q.charpter,s.suName,q.pType from" +
	  		"  Question q,Subject s where  s.suName='"+subject.getSuName()+"' and q.suid=s.suId and q.pType='"+ss+"'";
  	int i=dao.getAllRowCount(hql);	
  	//查询结果集
  	String hql1="select DISTINCT s.suId,q.qid,q.type,q.content,q.optionA,q.optionB,q.optionC,q.optionD,q.answer,q.hard,q.charpter,s.suName,q.pType from" +
	  		"  Question q,Subject s where  s.suName='"+subject.getSuName()+"' and q.suid=s.suId and q.pType='"+ss+"'";
  	
  	//分页操作
  	if(count==null){
        page.setP(0);
        page.setCount(i);
        request2.getSession().setAttribute("count",0);
        request2.getSession().setAttribute("pb",page);
  		sub=dao.queryByPage(hql1,0,10);
  	}else{
  		page.setCount(i);
  		page.setP(count);
  		int x=10*(count-1);
        request2.getSession().setAttribute("count",count);
        request2.getSession().setAttribute("pb",page);
  		sub=dao.queryByPage(hql1, x,10);
  	}
      for(Object[] question:sub){
    	HttpServletRequest request1=ServletActionContext.getRequest();
    	request1.getSession().setAttribute("suid",question[0]);
    }
	  return "kt";

  }
  //添加试题前操作
  public String toadd(){
	  subject=(Subject) dao.getObjectById(Subject.class,id1);	  
	  HttpServletRequest request=ServletActionContext.getRequest();
  	  request.getSession().setAttribute("suid",subject.getSuId());
	  return "tkadds";
  }
  //添加试题
  public String  tkadd(){
	  HttpServletRequest request=ServletActionContext.getRequest();
  	  id1= (Integer) request.getSession().getAttribute("suid");
	  System.out.println(subject.getSuName());	  
	  question.setType(question.getType());
	  question.setContent(question.getContent());  
	  question.setOptionA(question.getOptionA());
	  question.setOptionB(question.getOptionB());
	  question.setOptionC(question.getOptionC());
	  question.setOptionD(question.getOptionD());
	  question.setHard(question.getHard());
	  question.setCharpter(question.getCharpter());	 
	  question.setAnswer(question.getAnswer());
      subject =(Subject) dao.getObjectById(Subject.class, id1);
      question.setSub(subject);
	  question.setpType(question.getpType());	  
	  dao.add(question);
	  return "tolist";
  }
  //删除试题
  public String  delete(){
	  String hql="delete q from Question q where q.qid=?";
	  Session session =HibernateSessionFactory.getSession();
	  query=session.createSQLQuery(hql);
	  query.setString(0,id);  
	  query.executeUpdate();    
	  return "tolist";
  }
  //修改前操作
  public String toupdate(){
	  System.out.println(id1);
	  System.out.println(ss);
	  subject=(Subject) dao.getObjectById(Subject.class,id1);
	  question=(Question) dao.getObjectById(Question.class,ss);
	  ques=dao.getObjects("from Question");
	  return "tkupdate";
	  
  }
  //修改试题
  public String update(){
	  HttpServletRequest request=ServletActionContext.getRequest();
  	  id1= (Integer) request.getSession().getAttribute("suid");
  	  System.out.println(id1);
  	  subject=(Subject) dao.getObjectById(Subject.class, id1);
  	  question.setSub(subject);
  	  dao.update(question);
	  return "tolist";
  }
  public String chaxunshijuan(){
	  HttpServletRequest request2=ServletActionContext.getRequest();
	  String ptype=request2.getParameter("ptype");
	  String type =request2.getParameter("type");
	  String hql1="select s from Subject s";
	  subs=dao.getObjects(hql1);
	//查询试卷
	  String  hql2="select p.pid from Paper p";
	  int i=dao.getAllRowCount(hql2);
	  String hql="select p.pid,p.ptype,p.suname,p.ptitle,p.pclass,p.pkksj,p.ptime,p.type from Paper p,Subject s where p.suname=s.suName and p.type ='"+type+"' and p.pType='"+ptype+"'";
	  papers=dao.getObjects1(hql);
	//分页操作
	  	if(count==null){
	        page.setP(0);
	        page.setCount(i);
	        request2.getSession().setAttribute("pb",page);
	        papers=dao.queryByPage(hql,0,10);
	  	}else{
	  		page.setCount(i);
	  		page.setP(count);
	  		int x=10*(count-1);
	        request2.getSession().setAttribute("pb",page);
	        papers=dao.queryByPage(hql, x,10);
	  	}
	  return "sjgl";
  }
  //试卷管理
  public String sjgl(){
	  HttpServletRequest request2=ServletActionContext.getRequest();
	  //方向，阶段，科目
	  String hql="select s from Subject s";
	  subs=dao.getObjects(hql);
	  //查询试卷
	  String  hql1="select p.pid from Paper p";
	  int i=dao.getAllRowCount(hql1);
	  String hql2="select p.pid,p.ptype,p.suname,p.ptitle,p.pclass,p.pkksj,p.ptime,p.type from Paper p";
//	  papers=dao.getObjects("from Paper");
	//分页操作
	  	if(count==null){
	        page.setP(0);
	        page.setCount(i);
	        request2.getSession().setAttribute("pb",page);
	        papers=dao.queryByPage(hql2,0,10);
	  	}else{
	  		page.setCount(i);
	  		page.setP(count);
	  		int x=10*(count-1);
	        request2.getSession().setAttribute("pb",page);
	        papers=dao.queryByPage(hql2, x,10);
	  	}
	 
	  return "sjgl";
  }
  
  //查看试卷
  public String chakan(){
	  HttpServletRequest request=ServletActionContext.getRequest();
	  request.getSession().setAttribute("pid",paper.getPid());
	  String hql="select DISTINCT b.suname,b.pTime,b.pTotal,q.qid,q.content,q.type,q.optionA,q.optionB,q.optionC,q.optionD from"
	  		      +" Paperinfo a left join Paper b on a.pId = b.pId left join Question q on a.qId = q.qId where b.pId='"+paper.getPid()+"'";
	  que=dao.getObjects1(hql);
	  for(Object[] s:que){
		  request.getSession().setAttribute("km",s[0]);
		  request.getSession().setAttribute("sj",s[1]);
		  request.getSession().setAttribute("zf",s[2]);
	  }
	  return "chakan";
  }
  //查看试卷
  public String chakans(){
	  HttpServletRequest request=ServletActionContext.getRequest();
	  Integer pid=(Integer)request.getSession().getAttribute("pids");//试卷的pid
	  String hql="select DISTINCT b.suname,b.pTime,b.pTotal,q.qid,q.content,q.type,q.optionA,q.optionB,q.optionC,q.optionD from"
	  		      +" Paperinfo a left join Paper b on a.pId = b.pId left join Question q on a.qId = q.qId where b.pId='"+pid+"'";
	  que=dao.getObjects1(hql);
	  for(Object[] s:que){
		  request.getSession().setAttribute("km",s[0]);
		  request.getSession().setAttribute("sj",s[1]);
		  request.getSession().setAttribute("zf",s[2]);
	  }
	  return "chakan";
  }
  //替换试题
  public String tihuanshiti(){
	  HttpServletRequest request=ServletActionContext.getRequest();
	  request.getSession().setAttribute("stid",paperinfo.getQid());
	  ques=dao.getObjects("from Question");
	  return "tihuan";
  }
  //替换试题
  public String tihuan(){
	  HttpServletRequest request=ServletActionContext.getRequest();
	  Integer i=  (Integer) request.getSession().getAttribute("stid");//原试题ID
	  Integer pid=(Integer)request.getSession().getAttribute("pid");//试卷的pid
	  request.getSession().setAttribute("pids",pid);
	  String hql="update Paperinfo set qid="+paperinfo.getQid()+" where qid="+i+" and pid="+pid+"";
	  dao.update(hql);
	  return "chakans";
  }
  //随机组卷
  public String sjzj(){
	  //方向，阶段，科目
	  subs=dao.getObjects("from Subject");
	  return "sjzj";
  }
  //随机抽取试题
  public String suijizujuan(){
	  
	 //生成试卷
	 paper.setPtype("笔试题");
	 paper.setSuname(subject.getSuName());
	 paper.setPtitle(paper.getPtitle());
	 paper.setPtotal(paper.getPtotal());
	 paper.setPtime(paper.getPtime());
	 paper.setPtotalNum(paper.getPtotalNum());
	 paper.setPone(paper.getPone());
	 paper.setType("未开考");//刚创建的试卷默认未开考
	 dao.add(paper);
    //单选/简单
	 String hql="select  top "+num+" q.qid, NewID() as random from Question q,Subject s where s.suName='"+subject.getSuName()+"' "
	 		+ "and s.sustage='"+subject.getSustage()+"' and s.sudirec='"+subject.getSudirec()+"' and type='单选' and hard='简单' and pType='笔试题'  order by random";
	 List<Object[]> o =dao.getObjects1(hql);
	 papers=dao.getObjects("from Paper p where p.ptitle='"+paper.getPtitle()+"'");
	 for(Object[] ss:o){
		 for(Paper paper:papers){
			 Integer xx=paper.getPid();
			 Paperinfo pi=new Paperinfo();
			 pi.setPid(xx);
			 Integer x=(Integer) ss[0];
			 pi.setQid(x);
			 dao.add(pi);
		 }
		 
	 }
	 //单选/一般
	 String hql1="select  top "+num1+" q.qId, NewID() as random from Question q,Subject s where s.suName='"+subject.getSuName()+"' "
	 		+ "and s.sustage='"+subject.getSustage()+"' and s.sudirec='"+subject.getSudirec()+"' and type='单选' and hard='一般' and pType='笔试题'  order by random";
	 List<Object[]> o1 =dao.getObjects1(hql1);
	 for(Object[] ss1:o1){
		 for(Paper paper:papers){
			 Integer xx=paper.getPid();
			 Paperinfo pi=new Paperinfo();
			 pi.setPid(xx);
			 Integer x=(Integer) ss1[0];
			 pi.setQid(x);
			 dao.add(pi);
		 }
		 
	 }
	 
	 //单选/困难
	 String hql2="select  top "+num2+" q.qId, NewID() as random from Question q,Subject s where s.suName='"+subject.getSuName()+"' "
	 		+ "and s.sustage='"+subject.getSustage()+"' and s.sudirec='"+subject.getSudirec()+"' and type='单选' and hard='困难' and pType='笔试题'  order by random";
	 List<Object[]> o2 =dao.getObjects1(hql2);
	 for(Object[] ss2:o2){
		 for(Paper paper:papers){
			 Integer xx=paper.getPid();
			 Paperinfo pi=new Paperinfo();
			 pi.setPid(xx);
			 Integer x=(Integer) ss2[0];
			 pi.setQid(x);
			 dao.add(pi);
		 }
		 
	 }
	 
	 //多选/简单
     String hql3="select  top "+nums+" q.qId, NewID() as random from Question q,Subject s where s.suName='"+subject.getSuName()+"' "
		 		+ "and s.sustage='"+subject.getSustage()+"' and s.sudirec='"+subject.getSudirec()+"' and type='多选' and hard='简单' and pType='笔试题'  order by random";
     List<Object[]> o3 =dao.getObjects1(hql3);
	 for(Object[] ss3:o3){
		 for(Paper paper:papers){
			 Integer xx=paper.getPid();
			 Paperinfo pi=new Paperinfo();
			 pi.setPid(xx);
			 Integer x=(Integer) ss3[0];
			 pi.setQid(x);
			 dao.add(pi);
		 }
		 
	 }
     
     //多选/一般
	 String hql4="select  top "+nums1+" q.qId, NewID() as random from Question q,Subject s where s.suName='"+subject.getSuName()+"' "
		 		+ "and s.sustage='"+subject.getSustage()+"' and s.sudirec='"+subject.getSudirec()+"' and type='多选' and hard='一般' and pType='笔试题'  order by random";
	 List<Object[]> o4 =dao.getObjects1(hql4);
	 for(Object[] ss4:o4){
		 for(Paper paper:papers){
			 Integer xx=paper.getPid();
			 Paperinfo pi=new Paperinfo();
			 pi.setPid(xx);
			 Integer x=(Integer) ss4[0];
			 pi.setQid(x);
			 dao.add(pi);
		 }
		 
	 }
	 
	 //多选/困难
	 String hql5="select  top "+nums2+" q.qId, NewID() as random from Question q,Subject s where s.suName='"+subject.getSuName()+"' "
		 		+ "and s.sustage='"+subject.getSustage()+"' and s.sudirec='"+subject.getSudirec()+"' and type='多选' and hard='困难' and pType='笔试题'  order by random";
	 List<Object[]> o5 =dao.getObjects1(hql5);
	 for(Object[] ss5:o5){
		 for(Paper paper:papers){
			 Integer xx=paper.getPid();
			 Paperinfo pi=new Paperinfo();
			 pi.setPid(xx);
			 Integer x=(Integer) ss5[0];
			 pi.setQid(x);
			 dao.add(pi);
		 }
		 
	 }
	  
	  return  "tosjgl";
  }
  //删除试卷
  public String deletesj(){
	  System.out.println(paper.getId());
	  String hql="delete p from Paper p where p.pid=?";
	  Session session =HibernateSessionFactory.getSession();
	  query=session.createSQLQuery(hql);
	  query.setString(0,paper.getId());  
	  query.executeUpdate(); 
	  return "tosjgl";  
  }
  //选题组卷
  public String xtzj(){
	  HttpServletRequest request2=ServletActionContext.getRequest();
	  //方向，阶段，科目
	  subs=dao.getObjects("from Subject");
	  //查询试题
	  String hql="select q.qid from Question q where q.pType='笔试题'";
	  int i=dao.getAllRowCount(hql);
	  String hql1="select q.qid,q.type,q.hard,q.content from Question q where q.pType='笔试题'";
//	  que=dao.getObjects1(hql1);
	//分页操作
	  	if(count==null){
	        page.setP(0);
	        page.setCount(i);
	        request2.getSession().setAttribute("count",0);
	        request2.getSession().setAttribute("pb",page);
	        ques=dao.queryByPage(hql1,0,10);
	  	}else{
	  		page.setCount(i);
	  		page.setP(count);
	  		int x=10*(count-1);
	        request2.getSession().setAttribute("count",count);
	        request2.getSession().setAttribute("pb",page);
	        ques=dao.queryByPage(hql1, x,10);
	  	}
	  return "xtzj";
  }
  //选题完毕创建试卷
  public String l(){
	     HttpServletRequest request=ServletActionContext.getRequest();
	     //生成试卷
		 paper.setPtype("笔试题");
		 paper.setSuname(subject.getSuName());//科目
		 paper.setPtitle(paper.getPtitle());//标题
		 paper.setPtotal(paper.getPtotal());//总分
		 paper.setPtime(paper.getPtime());//考试时长
		 paper.setPtotalNum(paper.getPtotalNum());//总提数
		 paper.setPone(paper.getPone());//每题分数
		 paper.setType("未开考");//刚创建的试卷默认未开考
		 dao.add(paper);
    String[] qid=	request.getParameterValues("qid");
    papers=dao.getObjects("from Paper p where p.ptitle='"+paper.getPtitle()+"'");	
    	for(int i=0;i<qid.length;i++){
    		for(Paper paper:papers){
			 Paperinfo pi=new Paperinfo();
			 pi.setPid(paper.getPid());
			 int x =Integer.parseInt(qid[i]);
			 pi.setQid(x);
			 dao.add(pi);
		 }
    }
    
	  return "tosjgl";
  } 
    //设置考试班级
	public String kaishi(){
		classe=dao.getObjects("from Classs");
		HttpServletRequest request=ServletActionContext.getRequest();
		request.getSession().setAttribute("pp",paper.getId());
		return "ksks";
	}
	//可以开始考试了
	public String stat(){
		HttpServletRequest request=ServletActionContext.getRequest();
	    String pid=(String) request.getSession().getAttribute("pp");
		String time=request.getParameter("times");
		System.out.println(time);
		String hql="update Paper set pclass='"+cla.getCname()+"',pkksj='"+time+"',type='考试中' where  pid="+pid+"";
		dao.update(hql);	
		return "tosjgl";
	}
   //结束考试
	public String finish(){
		String hql="update Paper set type='考试结束' where  pid="+paper.getId()+"";
		dao.update(hql);
		return "tosjgl";
	}
   //学生查看可以考试的试卷
	public String zaixiankaoshi(){
		 HttpServletRequest request2=ServletActionContext.getRequest();
		  //查询试卷
		  String  hql1="select p.pid from Paper p where p.type='考试中'";
		  int i=dao.getAllRowCount(hql1);
		  String hql2="select p.pid,p.ptype,p.suname,p.ptitle,p.pclass,p.pkksj,p.ptime,p.type from Paper p where p.type='考试中'";
		  papers=dao.getObjects("from Paper");
		//分页操作
		  	if(count==null){
		        page.setP(0);
		        page.setCount(i);
		        request2.getSession().setAttribute("pb",page);
		        papers=dao.queryByPage(hql2,0,10);
		  	}else{
		  		page.setCount(i);
		  		page.setP(count);
		  		int x=10*(count-1);
		        request2.getSession().setAttribute("pb",page);
		        papers=dao.queryByPage(hql2, x,10);
		  	}
		 
		return "zaixian";
	}
  //考试页面
	public String exam(){
		
		  HttpServletRequest request=ServletActionContext.getRequest();
		  String hqls="select DISTINCT b.suname,b.pTime,b.pkksj,b.pTotal,q.qid,q.content,q.type,q.optionA,q.optionB,q.optionC,q.optionD from"
	  		      +" Paperinfo a left join Paper b on a.pId = b.pId left join Question q on a.qId = q.qId where b.pId="+paper.getId()+"";
		  int i=dao.getAllRowCount(hqls);
		  request.getSession().setAttribute("count",i);
		  String hql="select DISTINCT b.suname,b.pTime,b.pTotal,b.pkksj,q.qid,q.content,q.type,q.optionA,q.optionB,q.optionC,q.optionD from"
		  		      +" Paperinfo a left join Paper b on a.pId = b.pId left join Question q on a.qId = q.qId where b.pId="+paper.getId()+"";
		  que=dao.getObjects1(hql);
		  request.getSession().setAttribute("list",que);
		  for(Object[] s:que){
			  request.getSession().setAttribute("km",s[0]);
			  request.getSession().setAttribute("sj",s[1]);
			  request.getSession().setAttribute("zf",s[2]);
			  request.getSession().setAttribute("kksj",s[3]);
		  }
		return "exam";
	}
    //成绩管理
    private String score;
	public String score(){
       String[] scores= score.split("_");
		for(int i=0;i<scores.length;i++){	
			System.out.println(scores[i]);
		}
		return null;
	}

//GET/SET 
public Paper getPaper() {
	return paper;
}
public void setPaper(Paper paper) {
	this.paper = paper;
}
public Paperinfo getPaperinfo() {
	return paperinfo;
}
public void setPaperinfo(Paperinfo paperinfo) {
	this.paperinfo = paperinfo;
}
public Question getQuestion() {
	return question;
}
public void setQuestion(Question question) {
	this.question = question;
}
public Subject getSubject() {
	return subject;
}
public void setSubject(Subject subject) {
	this.subject = subject;
}
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public Integer getId1() {
	return id1;
}
public void setId1(Integer id1) {
	this.id1 = id1;
}
public List<Subject[]> getSub() {
	return sub;
}
public void setSub(List<Subject[]> sub) {
	this.sub = sub;
}
public List<Subject> getSubs() {
	return subs;
}
public void setSubs(List<Subject> subs) {
	this.subs = subs;
}

public List<Question> getQues() {
	return ques;
}
public void setQues(List<Question> ques) {
	this.ques = ques;
}
public List<Question[]> getQue() {
	return que;
}

public void setQue(List<Question[]> que) {
	this.que = que;
}

public Query getQuery() {
	return query;
}
public void setQuery(Query query) {
	this.query = query;
}
public Integer getSs() {
	return ss;
}
public void setSs(Integer ss) {
	this.ss = ss;
}

public List<Paper> getPapers() {
	return papers;
}

public void setPapers(List<Paper> papers) {
	this.papers = papers;
}

public Integer getCount() {
	return count;
}

public void setCount(Integer count) {
	this.count = count;
}

public Integer getNum() {
	return num;
}

public void setNum(Integer num) {
	this.num = num;
}

public Integer getNums() {
	return nums;
}

public void setNums(Integer nums) {
	this.nums = nums;
}

public Integer getNum1() {
	return num1;
}

public void setNum1(Integer num1) {
	this.num1 = num1;
}

public Integer getNum2() {
	return num2;
}

public void setNum2(Integer num2) {
	this.num2 = num2;
}

public Integer getNums1() {
	return nums1;
}

public void setNums1(Integer nums1) {
	this.nums1 = nums1;
}

public Integer getNums2() {
	return nums2;
}

public void setNums2(Integer nums2) {
	this.nums2 = nums2;
}

public List<Classs> getClasse() {
	return classe;
}

public void setClasse(List<Classs> classe) {
	this.classe = classe;
}

public Classs getCla() {
	return cla;
}

public void setCla(Classs cla) {
	this.cla = cla;
}

public String getList() {
	return list;
}

public void setList(String list) {
	this.list = list;
}

public String getScore() {
	return score;
}

public void setScore(String score) {
	this.score = score;
}

//public List getLists() {
//	return list;
//}
//
//public void setLists(List lists) {
//	this.list = list;
//}




  
}
