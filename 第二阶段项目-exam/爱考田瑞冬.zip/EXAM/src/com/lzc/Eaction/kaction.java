package com.lzc.Eaction;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.lzc.basedao.BaseDaoImpl;
import com.lzc.beans.Classs;
import com.opensymphony.xwork2.Action;

public class kaction implements Action {
   private BaseDaoImpl dao = new BaseDaoImpl();
   
   private List<Classs> classe;
   private Classs cla;
	//设置考试班级
	public String kaishi(){
		classe=dao.getObjects("from Classs"); 
		return "ksks";
	}
	public String stat(){
		HttpServletRequest request=ServletActionContext.getRequest();
		String time=request.getParameter("times");
		System.out.println(time);
		System.out.println(cla.getCname());
		return null;
	}
	
	//get/set方法

	
	
	public List<Classs> getClasse() {
		return classe;
	}
	public void setClasse(List<Classs> classe) {
		this.classe = classe;
	}
	
	public Classs getCla() {
		return cla;
	}
	public void setCla(Classs cla) {
		this.cla = cla;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	
}
