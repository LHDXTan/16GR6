package com.lzc.Eaction;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Query;
import org.hibernate.Session;

import com.lzc.basedao.BaseDaoImpl;
import com.lzc.basedao.HibernateSessionFactory;
import com.lzc.bean.Paper;
import com.lzc.bean.Paperinfo;
import com.lzc.bean.Question;
import com.lzc.bean.Subject;
import com.lzc.beans.Adminuser;
import com.lzc.beans.Juese;
import com.lzc.beans.Student;
import com.lzc.beans.Teacher;
import com.opensymphony.xwork2.Action;

public class action implements Action {
	 private String username;
	 private String password;
     private Adminuser admin;
     private Student stu;
     private Teacher tea;
	 private Juese js;	 
	 private List<Adminuser> admins;
	 private List<Student> stus;
	 private List<Juese> jjj;
	 private List<Teacher> teas;
    /*****************************/	
	 private BaseDaoImpl dao = new BaseDaoImpl();
	public String execute() throws Exception {
		
		return null;
	}
	public String zhuxiao(){
			
			return "name";
	}
	//登录
	public String login() throws IOException{
		System.out.println(username);
		HttpServletResponse response=ServletActionContext.getResponse();
        PrintWriter out=response.getWriter();
		//学生角色
		if("1".equals(js.getJname())){
			stus=dao.getObjects("from Student where sname='"+username+"'");
			for(Student stu:stus){
				if(stu.getSname().equals(username)&&stu.getPassword().equals(password)||stu.getLoginuser().equals(username)&&stu.getPassword().equals(password)){
					HttpServletRequest request=ServletActionContext.getRequest();
					request.getSession().setAttribute("js1",stu.getSname());
					request.getSession().setAttribute("js2",js.getJname());
					return "login";
				}else{
//				HttpServletRequest request=ServletActionContext.getRequest();
//				request.getSession().setAttribute("ss","用户名或密码错误");
				out.print("用户名或密码错误");
				out.flush();
				out.close();
				return "name";
				}
				
			}
			
	}
		//讲师角色
		if("2".equals(js.getJname())){
		teas=dao.getObjects("from Teacher where tname='"+username+"'");
		for(Teacher tea:teas){
			if(tea.getTname().equals(username)&&tea.getPassword().equals(password)||tea.getLoginuser().equals(username)&&tea.getPassword().equals(password)){
				HttpServletRequest request=ServletActionContext.getRequest();
				request.getSession().setAttribute("js1",tea.getTname());
				request.getSession().setAttribute("js2",js.getJname());
				return "login";
			}else{
			HttpServletRequest request=ServletActionContext.getRequest();
			request.getSession().setAttribute("ss","用户名或密码错误");
			return "name";
			}
		
		}
	}
		
	//管理员角色
     if("3".equals(js.getJname())){
	  admins=dao.getObjects("from Adminuser where loginuser='"+username+"'");
	  for(Adminuser admin:admins){
			if(admin.getLoginuser().equals(username)&&admin.getPassword().equals(password)){
				HttpServletRequest request=ServletActionContext.getRequest();
				request.getSession().setAttribute("js2",js.getJname());
				request.getSession().setAttribute("js1",admin.getLoginuser());
				return "login";		
			}else{	
				HttpServletRequest request=ServletActionContext.getRequest();
				request.getSession().setAttribute("ss","用户名或密码错误");
				return "name";
			}
		
	     }
		
	}
        HttpServletRequest request=ServletActionContext.getRequest();
		request.getSession().setAttribute("ss","用户名或密码错误");
		return  "name";
	
}
   

	
	//get/set方法
	public Adminuser getAdmin() {
		return admin;
	}
	public void setAdmin(Adminuser admin) {
		this.admin = admin;
	}
	public Student getStu() {
		return stu;
	}
	public void setStu(Student stu) {
		this.stu = stu;
	}
	public Teacher getTea() {
		return tea;
	}
	public void setTea(Teacher tea) {
		this.tea = tea;
	}
	public Juese getJs() {
		return js;
	}
	public void setJs(Juese js) {
		this.js = js;
	}
	public List<Adminuser> getAdmins() {
		return admins;
	}
	public void setAdmins(List<Adminuser> admins) {
		this.admins = admins;
	}
	public List<Student> getStus() {
		return stus;
	}
	public void setStus(List<Student> stus) {
		this.stus = stus;
	}
	public List<Teacher> getTeas() {
		return teas;
	}
	public void setTeas(List<Teacher> teas) {
		this.teas = teas;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public List<Juese> getJjj() {
		return jjj;
	}
	public void setJjj(List<Juese> jjj) {
		this.jjj = jjj;
	}

  
	
	
	
}
