package com.lzc.bean;

public class listbean {
	
	private String pType;//试题类别，笔试or机试
	
	
	public listbean(String pType) {
		this.pType = pType;
	}
	public String getpType() {
		return pType;
	}
	public void setpType(String pType) {
		this.pType = pType;
	}

	
	
	
}
