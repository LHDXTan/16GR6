package com.lzc.bean;

import java.util.ArrayList;
import java.util.List;

public class pagebean {
     private int pagesize;
     private int pagetotal;
     private int p;
     private int count;
     private List data;
     
     public pagebean(){
    	 pagesize=10;
    	 data = new ArrayList();
     }

	public int getPagesize() {
		return pagesize;
	}

	

	public int getPagetotal() {
		return pagetotal;
	}

	public void setPagetotal(int pagetotal) {
		this.pagetotal = pagetotal;
	}

	public int getP() {
		return p;
	}

	

	public int getCount() {
		return count;
	}

	

	public List getData() {
		return data;
	}

	public void setData(Object obj) {
		data.add(obj);
	}
	
     public void setPagesize(int pagesize){
    	 this.pagesize=pagesize; 
     }
  
     public void setCount(int count){
    	 this.count=count;
    	 pagetotal=(int)(Math.ceil(count*1.0/pagesize));
     }
 
     public void setP(int up){
    	 if(up<1)p=1;
    	 else if(up>pagetotal)p=pagetotal;
    	 else p=up;
     }


}
