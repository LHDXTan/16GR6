package com.lzc.bean;

/**
 * Paperinfo entity. @author MyEclipse Persistence Tools
 */

public class Paperinfo implements java.io.Serializable {

	// Fields试卷信息表

	private Integer piid;//主键
	private Integer qid;//考题表ID
	private Integer pid;//试卷表ID
    
	// Constructors

	/** default constructor */
	public Paperinfo() {
	}

	/** full constructor */
	public Paperinfo(Integer piid, Integer qid, Integer pid) {
		this.piid = piid;
		this.qid = qid;
		this.pid = pid;
	}

	// Property accessors

	public Integer getPiid() {
		return this.piid;
	}

	public void setPiid(Integer piid) {
		this.piid = piid;
	}

	public Integer getQid() {
		return this.qid;
	}

	public void setQid(Integer qid) {
		this.qid = qid;
	}

	public Integer getPid() {
		return this.pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

}