package com.lzc.beans;

/**
 * Adminuser entity. @author MyEclipse Persistence Tools
 */

public class Adminuser implements java.io.Serializable {

	// Fields

	private Integer aid;//管理员id
	private String loginuser;//管理员账号
	private String password;//管理员密码
	private Integer jid;//角色id
    private Juese  js;
	// Constructors

	/** default constructor */
	public Adminuser() {
	}

	/** full constructor */
	public Adminuser(Integer aid, String loginuser, String password, Integer jid) {
		this.aid = aid;
		this.loginuser = loginuser;
		this.password = password;
		this.jid = jid;
	}

	// Property accessors

	public Integer getAid() {
		return this.aid;
	}

	public void setAid(Integer aid) {
		this.aid = aid;
	}

	public String getLoginuser() {
		return this.loginuser;
	}

	public void setLoginuser(String loginuser) {
		this.loginuser = loginuser;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getJid() {
		return this.jid;
	}

	public void setJid(Integer jid) {
		this.jid = jid;
	}

	public Juese getJs() {
		return js;
	}

	public void setJs(Juese js) {
		this.js = js;
	}

}