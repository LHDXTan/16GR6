package com.lzc.beans;

/**
 * Class entity. @author MyEclipse Persistence Tools
 */

public class Classs implements java.io.Serializable {

	// Fields

	private Integer cid;//ID
	private String cname;//班级名称
	private String sudirec;//班级方向
	private String bzr;//班主任
	private Integer js;//角色ID

	// Constructors

	/** default constructor */
	public Classs() {
	}

	/** full constructor */
	public Classs(Integer cid, String cname, String sudirec, String bzr,
			Integer js) {
		this.cid = cid;
		this.cname = cname;
		this.sudirec = sudirec;
		this.bzr = bzr;
		this.js = js;
	}

	// Property accessors

	public Integer getCid() {
		return this.cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	public String getCname() {
		return this.cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getSudirec() {
		return this.sudirec;
	}

	public void setSudirec(String sudirec) {
		this.sudirec = sudirec;
	}

	public String getBzr() {
		return this.bzr;
	}

	public void setBzr(String bzr) {
		this.bzr = bzr;
	}

	public Integer getJs() {
		return this.js;
	}

	public void setJs(Integer js) {
		this.js = js;
	}

}