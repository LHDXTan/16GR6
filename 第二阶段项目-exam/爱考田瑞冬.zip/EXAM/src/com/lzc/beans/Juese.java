package com.lzc.beans;

import java.util.HashSet;
import java.util.Set;

/**
 * Juese entity. @author MyEclipse Persistence Tools
 */

public class Juese implements java.io.Serializable {

	// Fields

	private Integer jid;//角色id
	private String jname;//角色名称
    private Set<Adminuser> admin=new HashSet();
    private Set<Student> stu=new HashSet();
    private Set<Teacher> tea=new HashSet();
	// Constructors

	/** default constructor */
	public Juese() {
	}

	/** full constructor */
	public Juese(Integer jid, String jname) {
		this.jid = jid;
		this.jname = jname;
	}

	// Property accessors

	public Integer getJid() {
		return this.jid;
	}

	public void setJid(Integer jid) {
		this.jid = jid;
	}

	public String getJname() {
		return this.jname;
	}

	public void setJname(String jname) {
		this.jname = jname;
	}

	public Set<Adminuser> getAdmin() {
		return admin;
	}

	public void setAdmin(Set<Adminuser> admin) {
		this.admin = admin;
	}

	public Set<Student> getStu() {
		return stu;
	}

	public void setStu(Set<Student> stu) {
		this.stu = stu;
	}

	public Set<Teacher> getTea() {
		return tea;
	}

	public void setTea(Set<Teacher> tea) {
		this.tea = tea;
	}

}