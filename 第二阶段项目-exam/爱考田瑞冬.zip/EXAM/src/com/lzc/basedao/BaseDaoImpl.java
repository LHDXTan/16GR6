package com.lzc.basedao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.management.Query;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.lzc.bean.Subject;
import com.lzc.bean.pagebean;
import com.lzc.beans.Student;




public class BaseDaoImpl  implements IBaseDao{

	//添加
	public void add(Object obj) {
		Session  session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		try{
			session.save(obj);
			tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
		
		HibernateSessionFactory.closeSession();
	} 
	

	//删除
	public void delete(Object obj) {
		Session  session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		try{
			session.delete(obj);
			tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
		
		HibernateSessionFactory.closeSession();	}

	//通过ID查询
	public Object getObjectById(Class clazz, Serializable id) {
		Session  session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		Object obj = null;
		try{
			obj = session.get(clazz, id);
			tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
		
		HibernateSessionFactory.closeSession();
		return obj;
	}

	//查询
	public List getObjects(String hql) {
		Session  session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		List result = new ArrayList();
		try{
			result = session.createQuery(hql).list();
			tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
		
		HibernateSessionFactory.closeSession();
		return result;
	}
	//查询
		public List getObjects1(String hql) {
			Session  session = HibernateSessionFactory.getSession();
			Transaction tx = session.beginTransaction();
			List result = new ArrayList();
			try{
				result = session.createSQLQuery(hql).list();
				tx.commit();
			}catch(Exception e){
				tx.rollback();
				e.printStackTrace();
			}
			
			HibernateSessionFactory.closeSession();
			return result;
		}
	//修改	
	public int update(String hql) {
					Session  session = HibernateSessionFactory.getSession();
					Transaction tx = session.beginTransaction();
					int  i=0;
					try{
					    session.createSQLQuery(hql).executeUpdate();
						tx.commit();
					}catch(Exception e){
						tx.rollback();
						e.printStackTrace();
					}
					
					HibernateSessionFactory.closeSession();
					
					return i;
				}
	
		
	//修改
	public void update(Object obj) {
		Session  session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		try{
			session.update(obj);
			tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
		
		HibernateSessionFactory.closeSession();
	}
	
	//获取查询的总条数
	public int getAllRowCount(String hql)
    {
        Session session = HibernateSessionFactory.getSession();
        Transaction tx = session.beginTransaction();
        List result = new ArrayList();
        int allRows = 0;
        try
        {
            
             result =session.createSQLQuery(hql).list();
            
             allRows =result.size();
            
            tx.commit();
            
        }
        catch (Exception e)
        {
            if(tx != null)
            {
                tx.rollback();
            }
            
            e.printStackTrace();
        }
      
        
        return allRows;
    }
	//通过分页获取结果集
	public List queryByPage(String hql, int offset, int pageSize)
    {
		Session session = HibernateSessionFactory.getSession();
        Transaction tx = session.beginTransaction();
        List result = new ArrayList(); 
        try
        {    
            org.hibernate.Query query = session.createSQLQuery(hql).setFirstResult(offset).setMaxResults(pageSize);
            
            result = query.list();
            
            tx.commit();
            
        }
        catch (Exception e)
        {
            if(tx != null)
            {
                tx.rollback();
            }
            
            e.printStackTrace();
        } 
        return result;
    }

}


