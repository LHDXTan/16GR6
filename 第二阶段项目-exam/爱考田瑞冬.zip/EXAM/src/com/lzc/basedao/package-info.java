/**
 * 
 */
/**
 * @author Administrator
 *
 */
package com.lzc.basedao;