package com.Spring.bean;

import java.util.Date;

public class text_1 {
private String name;
private Date now;

public String say1() {
	return name+"-----"+now;
	
}

public void setName(String name) {
	this.name = name;
}

public void setNow(Date now) {
	this.now = now;
}

}
