package com.Spring.text;

import java.util.Date;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.Spring.bean.text;
import com.Spring.bean.text_1;


@SuppressWarnings("deprecation")
public class Beandemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Resource re=new ClassPathResource("applicationContext.xml");
		BeanFactory bf=new XmlBeanFactory(re);
//���Դ���		
		ApplicationContext appContext=new ClassPathXmlApplicationContext("applicationContext.xml");	
	    Date now =(Date)appContext.getBean("now");
	    System.out.println(now);
	    System.out.println("------------------------------");
	    
	    
//text  ���캯��ע��	    
	    text t=(text)bf.getBean("user");
	    t.say();
	    System.out.println(t);
	    System.out.println("------------------------------");

//text1 ����ע��
	
	    text_1 t1=(text_1) bf.getBean("user1");
	    String a=t1.say1();
	    System.out.println(a);
	    System.out.println("------------------------------");
	    
//

	}

}
