package com.Spring.bean;

import java.util.Date;

public class text {
 private String name;
 private Date date;
 
 public text(String name,Date date){
	 this.name=name;
	 this.date=date;
	 
 }
 
 public void say(){
	System.out.println(name+"---"+date); 

 }

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public Date getDate() {
	return date;
}

public void setDate(Date date) {
	this.date = date;
}


}
