package com.tsinghuait.demo.dao;

import java.util.List;

import com.tsinghuait.demo.vo.Hemps;

public interface IBaseDao {

	public List getAllList();

	public void saveAdd(Hemps emp);

	public void todel(Hemps emp);

	public Hemps toupdate(Hemps emp);

}