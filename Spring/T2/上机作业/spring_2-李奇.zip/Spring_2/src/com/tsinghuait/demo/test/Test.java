package com.tsinghuait.demo.test;

import java.util.List;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.tsinghuait.demo.dao.IBaseDao;
import com.tsinghuait.demo.vo.Hemps;

public class Test {

	public static void main(String[] args) {
		Resource rs = new ClassPathResource("applicationContext.xml");
		BeanFactory bf = new XmlBeanFactory(rs);
		IBaseDao dao = (IBaseDao) bf.getBean("bdao");
		
		List<Hemps> list = dao.getAllList();
		
		for(Hemps e:list){
			System.out.println(e.getEname());
		}
		
		
	}
}
