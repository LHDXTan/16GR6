package com.tsinghuait.demo.action;

import java.util.ArrayList;
import java.util.List;

import com.tsinghuait.demo.dao.IBaseDao;

public class HempsAction {
	private List list= new ArrayList();
	private IBaseDao bdao;
	
	
	public String getAllList()throws Exception{
		list = bdao.getAllList();
		return "tolist";
	}


	public List getList() {
		return list;
	}


	public void setList(List list) {
		this.list = list;
	}


	public IBaseDao getBdao() {
		return bdao;
	}


	public void setBdao(IBaseDao bdao) {
		this.bdao = bdao;
	}
	
}
