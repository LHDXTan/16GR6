package com.tsinghuait.demo.vo;

import java.math.BigDecimal;
import java.util.Date;


/**
 * Hemps entity. @author MyEclipse Persistence Tools
 */

public class Hemps  implements java.io.Serializable {


    // Fields    

     private Integer empid;
     private String ename;
     private String esex;
     private Date birthday;
     private Integer did;
     private Integer score;


    // Constructors

    /** default constructor */
    public Hemps() {
    }

    
    /** full constructor */
    public Hemps(String ename, String esex, Date birthday, Integer did, Integer score) {
        this.ename = ename;
        this.esex = esex;
        this.birthday = birthday;
        this.did = did;
        this.score = score;
    }

   
    // Property accessors

    public Integer getEmpid() {
        return this.empid;
    }
    
    public void setEmpid(Integer empid) {
        this.empid = empid;
    }

    public String getEname() {
        return this.ename;
    }
    
    public void setEname(String ename) {
        this.ename = ename;
    }

    public String getEsex() {
        return this.esex;
    }
    
    public void setEsex(String esex) {
        this.esex = esex;
    }

    public Date getBirthday() {
        return this.birthday;
    }
    
    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public Integer getDid() {
        return this.did;
    }
    
    public void setDid(Integer did) {
        this.did = did;
    }

    public Integer getScore() {
        return this.score;
    }
    
    public void setScore(Integer score) {
        this.score = score;
    }
   








}