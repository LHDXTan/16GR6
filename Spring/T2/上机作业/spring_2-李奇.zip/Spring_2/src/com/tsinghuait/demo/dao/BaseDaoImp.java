package com.tsinghuait.demo.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.tsinghuait.demo.vo.Hemps;

public class BaseDaoImp extends HibernateDaoSupport implements IBaseDao {

		/* (non-Javadoc)
		 * @see com.tsinghuait.demo.dao.IBaseDao#getAllList()
		 */
		public List getAllList(){
			String hql="select e from Hemps e";
			return super.getHibernateTemplate().find(hql);
		}
		
		/* (non-Javadoc)
		 * @see com.tsinghuait.demo.dao.IBaseDao#saveAdd(com.tsinghuait.demo.vo.Hemps)
		 */
		public void saveAdd(Hemps emp){
			super.getHibernateTemplate().save(emp);
		}
		
		
		/* (non-Javadoc)
		 * @see com.tsinghuait.demo.dao.IBaseDao#todel(com.tsinghuait.demo.vo.Hemps)
		 */
		public void todel(Hemps emp){
			super.getHibernateTemplate().delete(emp);
		}
		
		
		/* (non-Javadoc)
		 * @see com.tsinghuait.demo.dao.IBaseDao#toupdate(com.tsinghuait.demo.vo.Hemps)
		 */
		public Hemps toupdate(Hemps emp){
			return (Hemps) super.getHibernateTemplate().get(Hemps.class, emp.getEmpid());
		}
		
		
		
		
		
		
}
